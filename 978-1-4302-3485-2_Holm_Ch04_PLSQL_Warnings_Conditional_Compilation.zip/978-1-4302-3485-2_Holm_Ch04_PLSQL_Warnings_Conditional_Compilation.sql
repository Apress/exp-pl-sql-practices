--------------------------------------------------------
--  Expert PL/SQL Practices Published by Apress
--  Demo Code
--  Not mmeant for production use
--  Author: Torben Holm 
-- -----------------------------------------------------
-- Examine the value of plsql_warnings - if you are allowed to do SHOR PARAMETER
-- -----------------------------------------------------
show parameter plsql_warnings

-- -----------------------------------------------------
-- Examine the value of plsql_warnings
-- -----------------------------------------------------
SELECT DBMS_WARNING.GET_WARNING_SETTING_STRING FROM DUAL;

-- -----------------------------------------------------
-- Enable all warnings
-- -----------------------------------------------------
alter session set plsql_warnings='ENABLE:ALL';

-- -----------------------------------------------------
-- Enable severe and performance warnings and disable informational warnings
-- -----------------------------------------------------
alter session set plsql_warnings='ENABLE:SEVERE,ENABLE:PERFORMANCE, DISABLE:INFORMATIONAL';

-- -----------------------------------------------------
-- Enable severe warnings at the session level:
-- -----------------------------------------------------
EXEC DBMS_WARNING.SET_WARNING_SETTING_STRING('ENABLE:SEVERE', 'SESSION');

-- -----------------------------------------------------
-- Create the demo table T1
-- -----------------------------------------------------
CREATE TABLE T1 (
KEY VARCHAR2(10) CONSTRAINT PK_T1 PRIMARY KEY,
VALUE VARCHAR2(10))
/

-- -----------------------------------------------------
-- Add some rows to the T1 table
-- -----------------------------------------------------
insert into t1 select rownum, substr(text,1,10) from all_source where rownum < 10000;

-- -----------------------------------------------------
-- Enable severe and performance PL/SQL warnings.
-- -----------------------------------------------------
alter session set plsql_warnings='ENABLE:SEVERE, ENABLE:PERFORMANCE';

-- -----------------------------------------------------
-- Create the GET_T1_KEY function that will return 
-- the VALUE for a given key. 
-- The parameter type is of the wrong data type
-- -----------------------------------------------------
CREATE OR REPLACE FUNCTION GET_T1_KEY (P_KEY NUMBER) RETURN VARCHAR2 IS
l_value T1.VALUE%TYPE;
BEGIN
  SELECT VALUE INTO l_value FROM T1 WHERE KEY = P_KEY;
  RETURN l_value;
EXCEPTIONS
   WHEN NO_ROWS_FOUND THEN
   RETURN 'No value found';
END;
/
-- -----------------------------------------------------
-- Test the function
-- -----------------------------------------------------
set timeing on
var txt varchar2(10);
exec :txt := GET_T1_KEY(1); 

-- -----------------------------------------------------
-- Create the GET_T1_KEY function that will return the 
-- VALUE for a given key.
-- The parameter type is of the right data type
-- and AUTHID DEFINER is set
-- -----------------------------------------------------
CREATE OR REPLACE FUNCTION GET_T1_KEY (P_KEY VARCHAR2) RETURN VARCHAR2 
  AUTHID DEFINER
IS
 L_value T1.VALUE%TYPE;
BEGIN
   SELECT VALUE INTO l_value FROM T1 WHERE KEY = P_KEY;
   RETURN l_value;
EXCEPTIONS
   WHEN NO_ROWS_FOUND THEN
   RETURN 'No value found';
END;
/
-- -----------------------------------------------------
-- Test the function
-- -----------------------------------------------------
set timeing on
var txt varchar2(10);
exec :txt := GET_T1_KEY('1'); 
-- -----------------------------------------------------
-- Examine what the different in executeion plan is
-- Remember to GRANT the PLUSTRACE role
-- -----------------------------------------------------
set autotrace on
--
select value from T1 where key = '1';
-- Examine executeionplan
select value from T1 where key = 1;
-- Examine executeionplan

-- -----------------------------------------------------
-- Determine a warning�s category 
-- -----------------------------------------------------
SELECT DBMS_WARNING.GET_CATEGORY(7204) FROM DUAL;

-- -----------------------------------------------------
-- Promoting Warnings to Errors 
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Create the GET_T1_KEY function that will return the 
-- VALUE for a given key.
-- The parameter type is of the wrong data type
-- and AUTHID DEFINER is set.
-- -----------------------------------------------------
CREATE OR REPLACE FUNCTION GET_T1_KEY (P_KEY NUMBER) RETURN VARCHAR2
  AUTHID DEFINER
IS
 L_value T1.VALUE%TYPE;
BEGIN
   SELECT VALUE INTO l_value FROM T1 WHERE KEY = P_KEY;
   RETURN l_value;
EXCEPTIONS
  WHEN NO_ROWS_FOUND THEN
  RETURN 'No value found';
END;
/
-- -----------------------------------------------------
-- Promote warning 7204 to become an error
-- -----------------------------------------------------
alter session set plsql_warnings='DISABLE:ALL, ERROR:7204';
-- -----------------------------------------------------
-- Recompile the function again
-- -----------------------------------------------------
alter function GET_T1_KEY compile;
-- -----------------------------------------------------
-- Try to execute the function
-- -----------------------------------------------------
exec :txt := get_t1_key(1);
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Ignoring Warnings
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Prepare envirionment
alter session set plsql_warnings='ENABLE:ALL';
-- -----------------------------------------------------
-- Create the GET_T1_KEY function that will return the 
-- VALUE for a given key.
-- The parameter type is of the wrong data type
-- and have unreacthable code
-- AUTHID DEFINER is set.
-- -----------------------------------------------------
CREATE OR REPLACE FUNCTION GET_T1_KEY (P_KEY NUMBER) RETURN VARCHAR2
  AUTHID DEFINER
IS
  l_value T1.VALUE%TYPE;
  l_1 NUMBER :=1;
  l_2 NUMBER :=2;
BEGIN
  IF l_1 = l_2 THEN
    SELECT VALUE INTO l_value FROM T1 WHERE KEY = P_KEY;
    RETURN l_value;
  END IF;
END;
/
-- -----------------------------------------------------
-- Promote warning 7204 to become an error
-- And ignore warning 6010
-- -----------------------------------------------------
alter session set plsql_warnings='ENABLE:ALL, ERROR:7204, DISABLE:6010';

-- -----------------------------------------------------
-- Examint ehat options a stored procedure has been 
-- compiled with
-- -----------------------------------------------------
col plsql_warnings for a40
SELECT NAME, PLSQL_WARNINGS FROM USER_PLSQL_OBJECT_SETTINGS
/
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Compilation and Warnings
-- -----------------------------------------------------
-- -----------------------------------------------------

-- Compile reusing the current settings
ALTER FUNCTION GET_T1_KEY COMPILE REUSE SETTINGS;

-- Compile using specifick warning settings
ALTER FUNCTION GET_T1_KEY COMPILE PLSQL_WARNINGS='ENABLE:ALL, DISABLE:6010,ERROR: 7204';

-- -----------------------------------------------------
-- Create Logon trigger to set session warnings
-- must be created as SYS or a user with CREATE DATABASE
-- TRIGGER rights
-- -----------------------------------------------------
CREATE OR REPLACE TRIGGER dev_logon_trigger
AFTER LOGON ON ACME.SCHEMA
BEGIN
  EXECUTE IMMEDIATE q'"ALTER SESSION SET PLSQL_WARNINGS='ENABLE:SEVERE,ENABLE:PERFORMANCE,ERROR:7204'"';
END;
/
-- Reconnect

-- -----------------------------------------------------
-- Examine the session settings after logon
-- -----------------------------------------------------
SELECT DBMS_WARNING.GET_WARNING_SETTING_STRING FROM DUAL;

-- -----------------------------------------------------
-- Recompile a schema. Remember to set reuse_settings=true
-- -----------------------------------------------------
exec DBMS_UTILITY.COMPILE_SCHEMA (schema=>'ACME', reuse_settings=>true);

-- =====================================================
-- Conditional Compilation
-- =====================================================

CREATE OR REPLACE PROCEDURE LEVEL2 AS
 $IF $$TIMING_ON $THEN
 $ELSIF NOT $$TIMING_ON $THEN
 $ELSE
    $ERROR ' The PLSQL_CCFLAG TIMING_ON, Must be set to either FALSE or TRUE before compileing procedure ' ||  $$PLSQL_UNIT||'.' 
    $END
 $END
 $IF $$TIMING_ON $THEN
    L_start_time TIMESTAMP;
 $END
 BEGIN
 DBMS_APPLICATION_INFO.SET_MODULE($$PLSQL_UNIT, 'RUN');
 $IF $$TIMING_ON $THEN
    L_START_TIME:=CURRENT_TIMESTAMP;
 $END
 -- -----------------------------------------------
 -- Application logic is left out
 -- -----------------------------------------------
 $IF $$TIMING_ON $THEN
   LOGIT (P_PG=>$$PLSQL_UNIT, P_START_TIME=>l_start_time, P_STOP_TIME=>CURRENT_TIMESTAMP);
 $END
 DBMS_APPLICATION_INFO.SET_MODULE(NULL,NULL);
 END LEVEL2;
/
ALTER SESSION SET plsql_ccflags='TIMING_ON:TRUE';

col plsql_ccflags for a80 wrap
select NAME, PLSQL_CCFLAGS FROM USER_PLSQL_OBJECT_SETTINGS;


CALL DBMS_PREPROCESSOR.PRINT_POST_PROCESSED_SOURCE('PROCEDURE', 'ACME','LEVEL2');
-- -----------------------------------------------
-- DDL for the procedure PRINT_SOURCE
-- -----------------------------------------------
CREATE OR REPLACE PROCEDURE PRINT_SOURCE (P_OBJECT_TYPE VARCHAR2, P_SCHEMA_NAME,  VARCHAR2, P_OBJECT_NAME VARCHAR2)  IS
   l_source_lines DBMS_PREPROCESSOR.source_lines_t;
BEGIN
   l_source_lines := DBMS_PREPROCESSOR.GET_POST_PROCESSED_SOURCE(P_OBJECT_TYPE, P_SCHEMA_NAME, P_OBJECT_NAME);
   FOR I IN l_source_lines.FIRST .. l_source_lines.LAST LOOP
      IF TRIM(SUBSTR(l_source_lines (i),1, length(l_source_lines (i))-1)) IS NOT NULL THEN
         DBMS_OUTPUT.PUT_LINE(RPAD(I,4, ' ')||REPLACE(l_source_lines(i), CHR(10),''));
      END IF;
   END LOOP;
END;
/

set serveroutput on
exec PRINT_SOURCE ('PROCEDURE','ACME','LEVEL2');

CREATE OR REPLACE PROCEDURE LEVEL2 (TIMING_ON BOOLEAN := FALSE) AS
  l_start_time TIMESTAMP;
BEGIN
  DBMS_APPLICATION_INFO.SET_MODULE('LEVEL2' ,NULL);
  IF TIMING_ON THEN
      l_start_time:=CURRENT_TIMESTAMP;
  END IF;
 -- -----------------------------------------------
 -- Application logic is left out
 -- -----------------------------------------------
 IF TIMING_ON THEN
     LOGIT (P_PG=>'LEVEL2', P_START_TIME=>l_start_time, P_STOP_TIME=>CURRENT_TIMESTAMP);
 END IF;
  DBMS_APPLICATION_INFO.SET_MODULE(NULL,NULL);
END LEVEL2;
/

SELECT * FROM USER_OBJECT_SIZE WHERE NAME = 'LEVEL2';

CREATE OR REPLACE PROCEDURE LEVEL2 AS
$IF $$TIMING_ON $THEN
    l_start_time TIMESTAMP;
$END
  BEGIN
  DBMS_APPLICATION_INFO.SET_MODULE($$PLSQL_UNIT ,NULL);
   $IF $$TIMING_ON $THEN
       l_start_time:=CURRENT_TIMESTAMP;
   $END
   -- -----------------------------------------------
   -- Application logic is left out
   -- ----------------------------------------------
  $IF $$TIMING_ON $THEN
     LOGIT (P_PG=>$$PLSQL_UNIT, P_START_TIME=>l_start_time, P_STOP_TIME=>CURRENT_TIMESTAMP);
  $END
  DBMS_APPLICATION_INFO.SET_MODULE(NULL,NULL);
END LEVEL2;
/
-- ------------------------------------
-- Invalidations
-- ------------------------------------
CREATE OR REPLACE PROCEDURE LEVEL1 AS
BEGIN
    LEVEL2;
END;
/
SELECT OBJECT_NAME, STATUS FROM USER_OBJECTS WHERE OBJECT_NAME IN ('LEVEL1','LEVEL2');


-- ------------------------------------
-- Controlling Compilation
-- ------------------------------------
CREATE TABLE CC_FLAGS (
OWNER         VARCHAR2(30),
OBJECT_TYPE   VARCHAR2(30),
OBJECT_NAME   VARCHAR2(30),
CCFLAGS       VARCHAR2(4000));

INSERT INTO CC_FLAGS (OWNER, OBJECT_TYPE, OBJECT_NAME, CCFLAGS) VALUES('ACME' , 'PROCEDURE', 'LEVEL2', 'TIMING_ON:FALSE');
INSERT INTO CC_FLAGS (OWNER, OBJECT_TYPE, OBJECT_NAME, CCFLAGS) VALUES('ACME' , 'PROCEDURE', 'LEVEL1', '');

BEGIN
  FOR I IN (SELECT * FROM CC_FLAGS) LOOP
   EXECUTE IMMEDIATE 'ALTER ' ||I.OBJECT_TYPE||' '||I.OWNER||'.'||I.OBJECT_NAME||' COMPILE PLSQL_CCFLAGS='''||I.CCFLAGS||'''';
 END LOOP;
END;
/
-- ------------------------------------
-- Inquiry Variables
-- ------------------------------------
CREATE OR REPLACE PACKAGE TIMING AS
   TIMING_ON CONSTANT BOOLEAN := FALSE;
END;
/
CREATE OR REPLACE PROCEDURE LEVEL2 AS
  $IF TIMING.TIMING_ON $THEN
     L_START_TIME TIMESTAMP;
  $END
BEGIN
  DBMS_APPLICATION_INFO.SET_MODULE($$PLSQL_UNIT ,NULL);
  $IF TIMING.TIMING_ON $THEN
     L_START_TIME:=CURRENT_TIMESTAMP;
  $END
  -- -----------------------------------------------
  -- Application logic is left out
  -- -----------------------------------------------
  $IF TIMING.TIMING_ON $THEN
    LOGIT (P_PG=>$$PLSQL_UNIT, P_START_TIME=>L_START_TIME, P_STOP_TIME=>CURRENT_TIMESTAMP);
  $END
  DBMS_APPLICATION_INFO.SET_MODULE(NULL,NULL);
END LEVEL2;
/

BEGIN
  dbms_output.put_line('PLSQL Unit     : ' ||$$PLSQL_UNIT);
  dbms_output.put_line('PLSQL CCFLAGS  : ' ||$$PLSQL_CCFLAGS);
  dbms_output.put_line('PLSQL Warnings : ' ||$$PLSQL_Warnings);
  dbms_output.put_line('Optimize Level : ' ||$$PLSQL_OPTIMIZE_LEVEL);
  dbms_output.put_line('Line: ' ||$$PLSQL_LINE);
  dbms_output.put_line('PLSCOPE setting: ' ||$$PLSCOPE_SETTING);
  dbms_output.put_line('PLSQL code type: ' ||$$PLSQL_CODE_TYPE);
  dbms_output.put_line('NLS length semantics: ' ||$$NLS_LENGTH_SEMANTICS);
 END;
/
