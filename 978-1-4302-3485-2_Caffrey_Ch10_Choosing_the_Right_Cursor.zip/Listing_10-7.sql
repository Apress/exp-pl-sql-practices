DECLARE
        v_test NUMBER := 0;
BEGIN
        SELECT user_id INTO v_test FROM all_users WHERE username = �SYS�;
END;
/
