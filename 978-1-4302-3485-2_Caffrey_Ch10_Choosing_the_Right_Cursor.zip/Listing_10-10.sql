import java.sql.*;
import java.io.*;
import oracle.jdbc.driver.*;
class ProdConRefCursor 
{
public static void main (String args [ ])
throws SQLException, ClassNotFoundException 
{
   String query  = "BEGIN " + "product_pkg.get_concepts( ?, ?); " + "end;";
   DriverManager.registerDriver 
        (new oracle.jdbc.driver.OracleDriver());
Connection conn =
       DriverManager.getConnection 
       ("jdbc:oracle:thin:@proximo-dev:1521:mozartora112dev", "mktg", "mktg");
   Statement trace = conn.createStatement();
   CallableStatement  cstmt = conn.prepareCall(query);
   cstmt.setInt(1, 37);
   cstmt.registerOutParameter(2 ,OracleTypes.CURSOR);
   cstmt.execute();
   ResultSet rset = (ResultSet)cstmt.getObject(2);
   for(int i = 0;  rset.next(); i++ )
        System.out.println( "rset " + rset.getString(1) );
rset.close();
}
}
