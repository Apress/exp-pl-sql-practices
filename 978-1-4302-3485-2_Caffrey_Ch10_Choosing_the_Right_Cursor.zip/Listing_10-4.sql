DECLARE
   prod_cursor sys_refcursor;
BEGIN
IF ( input_param = 'C' ) 
THEN
      OPEN prod_cursor FOR
         SELECT * FROM prod_concepts 
           WHERE  concept_type = 'COLLATERAL'
             AND concept_dt    < TO_DATE( '01-JAN-2003', �DD-MON-YYYY�);
ELSE
      OPEN prod_cursor FOR
         SELECT * FROM prod_concepts 
          WHERE  concept_category = 'ADVERTISING';
END IF;
LOOP
       FETCH prod_cursor BULK COLLECT INTO .... LIMIT 500;
       ...procedural code to process results here...
       EXIT WHEN prod_cursor%NOTFOUND;
END LOOP;
   CLOSE prod_cursor;
END;
