CREATE OR REPLACE PROCEDURE refresh_store_feed AS
   TYPE prod_array     IS TABLE OF store_products%ROWTYPE  INDEX BY BINARY_INTEGER;
   l_prod              prod_array;
   CURSOR c IS
      SELECT  product
         FROM  listed_products@some_remote_site;
   BEGIN
   OPEN C;
   LOOP
   FETCH C BULK COLLECT INTO l_prod LIMIT 100;
   FOR i IN 1 .. l_csi.COUNT
   LOOP
      /*    ... do some procedural code here that cannot be done in SQL to l_csi(i) ... */
   END LOOP;
      FORALL i IN 1 .. l_csi.COUNT
         INSERT INTO store_products (product) VALUES (l_prod(i));
   EXIT WHEN c%NOTFOUND;
   END LOOP;
   CLOSE C;
   END;
   /
