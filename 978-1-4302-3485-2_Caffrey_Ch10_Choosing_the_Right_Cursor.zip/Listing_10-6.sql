BEGIN
   FOR x IN (SELECT * FROM dual) LOOP ... END LOOP;
END;





DECLARE
   CURSOR c IS SELECT * FROM dual;
BEGIN
   OPEN c;
   LOOP
      FETCH c INTO �
      EXIT WHEN c%NOTFOUND;
       �
   END LOOP;
   CLOSE c;
END;





BEGIN
   SELECT *INTO ...FROM dual;
END;





DECLARE
   CURSOR c IS SELECT * FROM dual;
   l_rec dual%ROWTYPE;
BEGIN
   OPEN c;
   FETCH c INTO l_rec;
      IF (SQL%NOTFOUND) 
      THEN
         RAISE NO_DATA_FOUND;
      END IF;
   FETCH c INTO l_rec;
      IF (SQL%FOUND) 
      THEN 
         RAISE TOO_MANY_ROWS;
      END IF;
   CLOSE c;
END;
