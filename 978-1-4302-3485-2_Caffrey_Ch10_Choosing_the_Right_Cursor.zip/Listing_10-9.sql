CREATE OR REPLACE PACKAGE product_pkg
AS
-- In Package Specification, declare the cursor variable type
TYPE my_cv IS REF CURSOR;

PROCEDURE get_concepts ( ip_input    IN  NUMBER,
                         op_rc      OUT  my_cv);

END product_pkg;

CREATE OR REPLACE PACKAGE BODY product_pkg
AS
-- In Package Body procedure, declare the cursor variable using the type declared in the package specification

PROCEDURE get_concepts (ip_input    IN  NUMBER,
                        op_rc      OUT  my_cv)
IS
    BEGIN
       IF ( ip_input = 1 ) 
       THEN
          OPEN op_rc FOR
             SELECT * FROM prod_concepts 
             WHERE  concept_type  = 'COLLATERAL'
                  AND concept_dt  < TO_DATE( '01-JAN-2003', �DD-MON-YYYY�);
       ELSE
          OPEN op_rc FOR
             SELECT * FROM prod_concepts 
              WHERE  concept_category = 'ADVERTISING';
       END IF;
    END get_concepts;

END product_pkg;
