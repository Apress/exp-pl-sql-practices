ALTER SESSION SET SQL_TRACE = true;

BEGIN
    FOR i IN 1 .. 2000 LOOP
        FOR x IN ( SELECT /*+ implicit cursor query goes here */ * FROM dual )
        LOOP
            NULL;
        END LOOP;
    END LOOP;
END;
/

DECLARE
    TYPE rc_type IS REF CURSOR;
    rc rc_type;
BEGIN
    FOR i IN 1 .. 2000 LOOP
        OPEN rc FOR SELECT /*+ REF cursor query goes here */ * FROM dual;
        CLOSE rc;
    END LOOP;
END;
/
