DECLARE
            lv_ref_cursor   SYS_REFCURSOR;
            lv_col_cnt      NUMBER;
            lv_desc_tab     DBMS_SQL.DESC_TAB;
BEGIN
            OPEN lv_rcursor FOR SELECT * FROM prod_concepts;
  
            DBMS_SQL.DESCRIBE_COLUMNS
            ( cur_id      => DBMS_SQL.TO_CURSOR_NUMBER(lv_ref_cursor),
              col_cnt     => lv_col_cnt,
              desc_tab    => lv_desc_tab );
 
           FOR i IN 1 .. lv_col_cnt
           LOOP
                   DBMS_OUTPUT.PUT_LINE( lv_desc_tab(i).col_name );
           END LOOP;
END;
/
