PROCEDURE get_concepts (ip_input         IN  NUMBER,
                        ip_con_type      IN  VARCHAR2,
                        ip_con_dt        IN  DATE,
                        ip_con_cat       IN  VARCHAR2,
                        op_rc           OUT  my_cv)
IS
    BEGIN
       IF ( ip_input = 1 ) 
       THEN
       OPEN op_rc FOR
             �SELECT * FROM prod_concepts 
               WHERE concept_type  = ��||ip_con_type||��
                    AND concept_dt < ��||ip_con_dt||��� ;
       ELSE
          OPEN op_rc FOR
             �SELECT * FROM prod_concepts 
              WHERE  concept_category = ��||ip_con_cat||��� ;
       END IF;
    END get_concepts;





CREATE OR REPLACE
    PROCEDURE get_concepts (ip_input         IN  NUMBER,
                            ip_con_type      IN  VARCHAR2,
                            ip_con_dt        IN  DATE,
                            ip_con_cat       IN  VARCHAR2,
                            op_rc           OUT  sys_refcursor )
    IS
        BEGIN
           IF ( ip_input = 1 )
          THEN
                   DBMS_OUTPUT.PUT_LINE(
                'SELECT * FROM prod_concepts
                  WHERE concept_type  = ''' ||ip_con_type|| '''
                       AND concept_dt < ''' || to_char(ip_con_dt, 'dd-mon-yyyy' ) ||'''' );
          ELSE
                   DBMS_OUTPUT.PUT_LINE(
                'SELECT * FROM prod_concepts
                 WHERE  concept_category = ''' || ip_con_cat||'''' );
          END IF;
       END get_concepts;
   /





SQL> variable x refcursor
SQL> exec get_concepts( ip_input => 2, ip_con_type => null, ip_con_dt => null, ip_con_cat => '''||admin_pkg.change_app_passwd( ''INJECTED'' ) --', op_rc => :x );







