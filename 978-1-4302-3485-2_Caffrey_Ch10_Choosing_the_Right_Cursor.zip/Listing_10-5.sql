CREATE FUNCTION f_get_name (ip_emp_id IN NUMBER) RETURN VARCHAR2
AS
lv_ename emp.ename%TYPE;
BEGIN
   SELECT ename INTO lv_ename FROM emp WHERE emp_id = f_get_name.ip_emp_id; 
   RETURN lv_ename;
END;
