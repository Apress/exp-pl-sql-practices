CREATE FUNCTION f_get_name (ip_emp_id IN NUMBER) RETURN VARCHAR2
AS
CURSOR c IS SELECT ename FROM emp WHERE emp_id = f_get_name.ip_emp_id;
lv_ename emp.ename%TYPE;
BEGIN
   OPEN c;
   FETCH c INTO lv_ename;
      IF (SQL%NOTFOUND) THEN
         RAISE NO_DATA_FOUND;
      ENDIF;
   FETCH c INTO lv_ename;
      IF (SQL%FOUND) THEN 
         RAISE TOO_MANY_ROWS;
      ENDIF;
   CLOSE c;
   RETURN lv_ename;
END;
