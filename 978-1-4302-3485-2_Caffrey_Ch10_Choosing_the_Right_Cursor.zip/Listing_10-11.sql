PROCEDURE get_concepts (ip_input    IN  NUMBER,
                        ip_con_type IN  VARCHAR2,
                        ip_con_dt   IN  DATE,
                        ip_con_cat  IN  VARCHAR2,
                     op_rc         OUT  my_cv)
IS
    lv_query VARCHAR2 (512) DEFAULT �SELECT * FROM prod_concepts�;
    BEGIN
         IF ( ip_con_type IS NOT NULL )
            lv_query := lv_query ||
            �  WHERE concept_type LIKE ��%��||:ip_con_type||��%�� �;
         ELSE
            lv_query := lv_query ||
            � WHERE (1 = 1 OR :ip_con_type IS NULL) �;
         END IF;
         IF ( ip_con_dt IS NOT NULL )
            lv_query := lv_query ||
            �  AND  concept_dt < :ip_con_dt �;
         ELSE
            lv_query := lv_query ||
            �  AND (1 = 1 OR :ip_con_dt IS NULL) �;
         END IF;
         IF ( ip_con_cat IS NOT NULL )
            lv_query := lv_query ||
            �  AND concept_category LIKE ��%��||:ip_con_cat||��%�� �;
         ELSE
            lv_query := lv_query ||
            �  AND (1 = 1 OR :ip_con_cat IS NULL) �;
         END IF;
            OPEN op_rc FOR
                lv_query USING ip_con_type, ip_con_dt, ip_con_cat;
       
    END get_concepts;
