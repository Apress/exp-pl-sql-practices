@bulk_setup empty

set echo on
declare
  l_row hardware%rowtype;
begin
  for i in 1 .. 100 loop
    l_row.aisle := 1;
    l_row.item  := i;
    insert into hardware values l_row;
  end loop;
end;
/

set echo off
