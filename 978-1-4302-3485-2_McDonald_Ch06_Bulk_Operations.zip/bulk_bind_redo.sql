@bulk_setup empty

connect 

set echo on
set serverout on
declare
  type t_row_list is table of hardware.descr%type
     index by pls_integer;
  l_rows t_row_list;

  l_redo1 int;
  l_redo2 int;
  l_redo3 int;
  
begin
  select value
  into   l_redo1
  from   v$mystat m, v$statname s
  where  s.statistic# = m.statistic#
  and    s.name = 'redo size';
  
  for i in 1 .. 1000 loop
     l_rows(i) := rpad('x',50);
     insert into hardware ( descr )  values ( l_rows(i) ); 
  end loop;
  
  select value
  into   l_redo2
  from   v$mystat m, v$statname s
  where  s.statistic# = m.statistic#
  and    s.name = 'redo size';
  
  forall i in 1 .. l_rows.count
     insert into hardware ( descr )  values ( l_rows(i) ); 

  select value
  into   l_redo3
  from   v$mystat m, v$statname s
  where  s.statistic# = m.statistic#
  and    s.name = 'redo size';

  dbms_output.put_line('Row at a time: '||(l_redo2-l_redo1));
  dbms_output.put_line('Bulk bind:     '||(l_redo3-l_redo2));

end;
/
  
