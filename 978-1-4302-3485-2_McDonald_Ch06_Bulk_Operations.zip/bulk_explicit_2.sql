set echo on
declare
  cursor c_tool_list is
    select descr
    from   hardware
    where  aisle = 1
    and    item between 1 and 500;

  type t_descr_list is table of c_tool_list%rowtype;
  l_descr_list t_descr_list;

begin
  open c_tool_list;
  fetch c_tool_list bulk collect into l_descr_list;
  close c_tool_list;
end;
/
set echo off