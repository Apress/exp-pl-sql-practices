@@bulk_setup.sql populate

set echo on
create or replace
package PKG1 is

 procedure open_cur(rc in out sys_refcursor);
 
 procedure fetch_cur(rc in out sys_refcursor, p_row out hardware.item%type);

end;
/

create or replace
package body PKG1 is

 procedure open_cur(rc in out sys_refcursor) is
 begin
   open rc for select item from hardware;
 end;
 
 procedure fetch_cur(rc in out sys_refcursor, p_row out hardware.item%type) is
 begin
   fetch rc into p_row;
 end;

end;
/
set echo off

rem
rem Testing
rem

--variable rc refcursor
--exec pkg1.open_cur(:rc)

--variable n number
--exec     pkg1.fetch_cur(:rc,:n);

--variable n number
--begin
--  for i in 1 .. 1000 loop
--     pkg1.fetch_cur(:rc,:n);
--  end loop;
--end;
--/

