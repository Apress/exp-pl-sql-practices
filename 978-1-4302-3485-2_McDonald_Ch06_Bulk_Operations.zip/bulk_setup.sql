set termout off
drop table HARDWARE purge;

create table HARDWARE
  ( aisle  NUMBER(5),
    item   NUMBER(12),
    descr  CHAR(50),
    stocked DATE
  );
  
insert /*+ APPEND */ into  HARDWARE
select trunc(rownum/1000)+1 aisle,
       rownum item,
       'Description '||rownum descr,
       to_date('01-JAN-2011','dd-mon-yyyy')+rownum/86400
from 
  ( select 1 from dual connect by level <= 1000),
  ( select 1 from dual connect by level <= 1000)
where nvl('&1','x') = 'populate';

commit;

exec dbms_stats.gather_table_stats(user,'HARDWARE');

begin
  if nvl('&1','x') = 'populate' then 
    execute immediate 'create index HARDWARE_IX on HARDWARE ( aisle, item )';
  end if;
end;
/

undefine 1
set termout on
