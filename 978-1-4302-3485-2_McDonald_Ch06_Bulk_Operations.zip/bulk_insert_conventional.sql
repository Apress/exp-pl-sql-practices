@@bulk_setup empty

set echo on
set timing on
declare
  l_now date := sysdate;
begin
 for i in 1 .. 100000 loop
   insert into HARDWARE 
   values (i/1000, i, to_char(i), l_now);
 end loop;
end;
/

