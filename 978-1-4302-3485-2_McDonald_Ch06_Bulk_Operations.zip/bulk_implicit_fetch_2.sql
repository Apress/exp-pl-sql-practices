set echo on
select banner from v$version where rownum = 1;
select value from v$parameter where name = 'plsql_optimize_level';

begin
  for i in (
    select descr
    from   hardware
    where  aisle = 1
    and    item between 1 and 500 )
  loop
     null;
  end loop;
end;
/
set echo off