@bulk_setup empty

set echo on
set serverout on
declare
  l_descr hardware.descr%type;
begin
  select descr
  into   l_descr
  from   hardware
  where  aisle = 0
  and    item = 0;
  dbms_output.put_line('Item was found');
exception
  when no_data_found then
    dbms_output.put_line('Invalid item specified');
end;
/
set echo off

