set echo on
set timing on
declare
  type t_va is varray(1000) of number;
  type t_nt is table of number;
  type t_aa is table of number index by pls_integer;
  
  va t_va;
  nt t_nt;
  aa t_aa;
begin
  for i in 1 .. 10000 loop
 
    select rownum
    --
    -- Comment in the collection type you want to test
    --
    bulk collect into va
    --bulk collect into nt
    --bulk collect into aa
 
    from dual
    connect by level <= 1000 ;
  end loop;
end;
/
set echo off
