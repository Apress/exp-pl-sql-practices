@@bulk_setup empty
set timing off
set echo on
alter table hardware 
  add constraint 
  hardware_chk check ( item > 0 );
  
begin
  insert into hardware ( item )  values (1);
  insert into hardware ( item ) values (-1);
  insert into hardware ( item ) values (2);
  insert into hardware ( item ) values (3);
  insert into hardware ( item ) values (4);
  insert into hardware ( item ) values (-2);
end;
/
set echo off
