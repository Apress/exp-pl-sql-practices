set echo on
declare
  cursor c_tool_list is
    select descr
    from   hardware
    where  aisle = 1
    and    item between 1 and 500;

  l_descr hardware.descr%type;
begin
  open c_tool_list;
  loop
    fetch c_tool_list into l_descr;
    exit when c_tool_list%notfound;
  end loop;
  close c_tool_list;
end;
/
set echo off
