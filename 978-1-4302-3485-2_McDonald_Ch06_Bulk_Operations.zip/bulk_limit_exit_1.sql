@bulk_setup populate

set echo on
set serverout on
declare
  cursor c_tool_list is
    select descr
    from   hardware
    where  aisle = 1
    and    item between 1 and 25;

  l_descr hardware.descr%type;
begin
  open c_tool_list;
  loop
    fetch c_tool_list into l_descr;
    exit when c_tool_list%notfound;
    dbms_output.put_line('Fetched '||l_descr);
  end loop;
  close c_tool_list;
end;
/
set echo off
