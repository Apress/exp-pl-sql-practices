@@bulk_setup empty

set echo on
alter table hardware 
  add constraint 
  hardware_chk check ( item > 0 );


exec DBMS_ERRLOG.CREATE_ERROR_LOG('HARDWARE'); 
desc ERR$_HARDWARE

insert 
into HARDWARE ( item )
with SRC_ROWS as 
  ( select -3 + rownum  x from dual
    connect by level <= 6 )
select x
from SRC_ROWS
log errors reject limit unlimited;
  
set lines 100
col item format a5
col ORA_ERR_MESG$ format a60


select 
 item
,ora_err_number$
,ora_err_mesg$
from err$_HARDWARE;

