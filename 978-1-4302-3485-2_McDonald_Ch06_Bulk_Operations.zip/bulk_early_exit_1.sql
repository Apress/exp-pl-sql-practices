@bulk_setup populate

set echo on
set timing on
declare
  cursor c_might_exit_early is
    select aisle, item
    from   hardware
    where  item between 400000 and 400050
      or   descr like '%10000%';
begin
  for i in c_might_exit_early 
  loop  
    if c_might_exit_early%rowcount = 40 then
       exit;
    end if;
  end loop;
end;
/
set echo off
set timing off
