@bulk_setup populate

set echo on
set serverout on
declare
  cursor c_tool_list is
    select descr
    from   hardware
    where  aisle = 1
    and    item between 1 and 25;
  type t_descr_list is table of c_tool_list%rowtype;
  l_descr_list t_descr_list;
begin
  open c_tool_list;
  loop
    fetch c_tool_list
    bulk collect into l_descr_list limit 10;
    exit when c_tool_list%notfound;
     for i in 1 .. l_descr_list.count loop
      dbms_output.put_line('Fetched '||l_descr_list(i).descr);
    end loop;
  end loop;
  close c_tool_list;
end;
/
set echo off
