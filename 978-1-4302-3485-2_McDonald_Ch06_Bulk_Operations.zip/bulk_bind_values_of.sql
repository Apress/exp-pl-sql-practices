@bulk_setup populate

set echo on
set serverout on
declare
  type t_input_row is record ( 
     item   hardware.item%type,
     descr  hardware.descr%type,
     status varchar2(3)
     );
  
  type t_input_list is 
     table of t_input_row 
     index by pls_integer;
  
  src t_input_list;

  type t_target_indices is 
     table of pls_integer 
     index by pls_integer;

  ind_new  t_target_indices;
  ind_upd  t_target_indices;

begin
  for i in 1 .. 100 loop
     src(i).item   := i;
     src(i).descr  := 'Item '||i;
     src(i).status :=  case when mod(i,5) = 0 then 'NEW' else 'UPD' end;
  end loop;
  
  
  for i in 1 .. 100 loop
     if src(i).status = 'NEW' then
        ind_new(ind_new.count) := i;
     else
        ind_upd(ind_upd.count) := i;
     end if;
  end loop;

  forall i in values of ind_new
     insert into hardware ( aisle, item) 
     values (1, src(i).item);
  dbms_output.put_line(sql%rowcount||' rows inserted');

  forall i in values of ind_upd
     update hardware 
     set descr = src(i).descr
     where aisle = 1
     and item = src(i).item;
  dbms_output.put_line(sql%rowcount||' rows updated');

end;
/

set echo off
