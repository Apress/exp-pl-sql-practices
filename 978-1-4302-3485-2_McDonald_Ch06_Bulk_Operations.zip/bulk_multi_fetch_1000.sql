set echo on
variable rc refcursor
exec pkg1.open_cur(:rc)

select to_char(systimestamp,'HH24:MI:SS.FF') started from dual;
set termout off
set echo off
variable n number
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 
exec for i in 1 .. 1000 loop pkg1.fetch_cur(:rc,:n); end loop; 

set echo on
set termout on
select  to_char(systimestamp,'HH24:MI:SS.FF') ended from dual;
set echo off