@bulk_setup empty

set echo on
declare
  type t_row_list is table of hardware%rowtype;
  l_row t_row_list := t_row_list();
begin
  for i in 1 .. 100 loop
    l_row.extend;
    l_row(i).aisle := 1;
    l_row(i).item  := i;
  end loop;

  forall i in 1 .. 100
    insert into hardware values l_row(i);
end;
/

set echo off
