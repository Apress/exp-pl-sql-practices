@bulk_setup empty
connect 
set echo on

declare
  type t_list is table of hardware.descr%type;
  l_rows t_list := t_list();
  l_now timestamp;
  l_redo1 int;
  l_redo2 int;
  l_redo3 int;
begin

  select value
  into   l_redo1
  from   v$mystat m, v$statname s
  where  s.statistic# = m.statistic#
  and    s.name = 'redo size';

  for i in 1 .. 1000000 loop
     l_rows.extend;
     l_rows(i) := i;
  end loop;

  l_now := systimestamp;
  forall i in 1 .. l_rows.count 
    insert into hardware ( descr )  values (l_rows(i));
  dbms_output.put_line('Elapsed = '||(systimestamp-l_now));

  select value
  into   l_redo2
  from   v$mystat m, v$statname s
  where  s.statistic# = m.statistic#
  and    s.name = 'redo size';

  execute immediate 'truncate table hardware';

  dbms_output.put_line('Redo conventional = '||(l_redo2-l_redo1));

  l_now := systimestamp;
  forall i in 1 .. l_rows.count 
    insert /*+ APPEND_VALUES */ into hardware ( descr ) values (l_rows(i));
  dbms_output.put_line('Elapsed = '||(systimestamp-l_now));

  select value
  into   l_redo3
  from   v$mystat m, v$statname s
  where  s.statistic# = m.statistic#
  and    s.name = 'redo size';

  dbms_output.put_line('Redo direct load = '||(l_redo3-l_redo2));

end;
/
commit;
set echo off
