set echo on
variable rc refcursor
exec pkg2.open_cur(:rc)
variable the_data varchar2(4000);

select to_char(systimestamp,'HH24:MI:SS.FF') started from dual;
set termout off
set echo off

exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;
exec declare n pkg2.t_num_list; begin :the_data := null; pkg2.fetch_cur(:rc,n); for i in 1 .. n.count loop :the_data := :the_data||n(i); end loop; end;

set echo on
set termout on
select  to_char(systimestamp,'HH24:MI:SS.FF') ended from dual;
set echo off
