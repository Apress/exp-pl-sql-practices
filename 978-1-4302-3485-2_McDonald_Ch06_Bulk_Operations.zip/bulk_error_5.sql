@@bulk_setup empty

set echo on
alter table hardware 
  add constraint 
  hardware_chk check ( item > 0 );

drop table ERRS purge;

create table ERRS 
  ( error_index   number(6), 
    error_code    number(6), 
    item          number );


set serverout on
declare
  type t_list is table of hardware.item%type;
  l_rows t_list := t_list(1,-1,2,3,4,-2);

  bulk_bind_error exception;
  pragma exception_init(bulk_bind_error,-24381);

  type t_err_list is table of ERRS%rowtype index by pls_integer;
  l_err_list t_err_list;

begin
  forall i in 1 .. l_rows.count save exceptions
    insert into hardware ( item ) values (l_rows(i));

exception
  when bulk_bind_error then
    for i in 1 .. sql%bulk_exceptions.count loop
       l_err_list(i).error_index := sql%bulk_exceptions(i).error_index;
       l_err_list(i).error_code := sql%bulk_exceptions(i).error_code;
       l_err_list(i).item := l_rows(sql%bulk_exceptions(i).error_index);
    end loop;
    forall i in 1 .. l_err_list.count
       insert into ERRS values l_err_list(i);

end;
/

select * from errs;

set echo off

