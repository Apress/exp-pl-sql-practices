@bulk_setup empty
set echo on
declare
  type t_num_list is table of hardware.item%type 
    index by pls_integer;

  val t_num_list;
  
  dense_val t_num_list;
  idx       pls_integer;
  
begin

  val(10) := 10;
  val(12) := 20;
  
  idx := val.first;
  while idx is not null loop
     dense_val(dense_val.count) := val(idx);
     idx := val.next(idx);
  end loop;
  
  FORALL i IN dense_val.first .. dense_val.last
     insert into hardware ( item ) 
     values (dense_val(i));
 
end;
/


set echo off
