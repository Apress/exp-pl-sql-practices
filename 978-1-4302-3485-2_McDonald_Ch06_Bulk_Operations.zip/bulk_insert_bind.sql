@@bulk_setup empty

set timing on
declare
  l_now date := sysdate;

  type t_rows is table of hardware%rowtype;
 
  l_rows t_rows := t_rows();
begin
 l_rows.extend(100000);
 for i in 1 .. 100000 loop
   l_rows(i).aisle := i/1000;
   l_rows(i).item := i;
   l_rows(i).descr := to_char(i);
   l_rows(i).stocked := l_now;
 end loop;

 forall i in 1 .. 100000
   insert into hardware values l_rows(i);

end;
/
