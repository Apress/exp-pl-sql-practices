set timing on
set echo on
declare
  cursor c_tool_list is
    select descr d1
    from   hardware;

  l_descr hardware.descr%type;
begin
  open c_tool_list;
  loop
    fetch c_tool_list into l_descr;
    exit when c_tool_list%notfound;
  end loop;
  close c_tool_list;
end;
/

declare
  cursor c_tool_list is
    select descr d2
    from   hardware;

  type t_descr_list is table of c_tool_list%rowtype;
  l_descr_list t_descr_list;

begin
  open c_tool_list;
  fetch c_tool_list bulk collect into l_descr_list;
  close c_tool_list;
end;
/
set echo off
