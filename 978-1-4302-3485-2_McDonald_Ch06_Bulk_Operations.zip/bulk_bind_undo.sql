@bulk_setup empty

connect 

set echo on
set serverout on
declare
  type t_row_list is table of hardware.descr%type
     index by pls_integer;
  l_rows t_row_list;

  l_stat1 int;
  l_stat2 int;
  l_stat3 int;
  
begin
  select value
  into   l_stat1
  from   v$mystat m, v$statname s
  where  s.statistic# = m.statistic#
  and    s.name = 'undo change vector size';
  
  for i in 1 .. 1000 loop
     l_rows(i) := rpad('x',50);
     insert into hardware ( descr )  values ( l_rows(i) ); 
  end loop;
  
  select value
  into   l_stat2
  from   v$mystat m, v$statname s
  where  s.statistic# = m.statistic#
  and    s.name = 'undo change vector size';
  
  forall i in 1 .. l_rows.count
     insert into hardware ( descr )  values ( l_rows(i) ); 

  select value
  into   l_stat3
  from   v$mystat m, v$statname s
  where  s.statistic# = m.statistic#
  and    s.name = 'undo change vector size';

  dbms_output.put_line('Row at a time: '||(l_stat2-l_stat1));
  dbms_output.put_line('Bulk bind:     '||(l_stat3-l_stat2));

end;
/
  
