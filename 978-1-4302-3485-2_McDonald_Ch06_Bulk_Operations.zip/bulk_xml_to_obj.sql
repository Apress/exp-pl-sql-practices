set echo on

create or replace
type COMING_FROM_XML as object
   ( COL1 int,
     COL2 int)
/



declare
  source_xml xmltype;
  target_obj coming_from_xml;
begin
  source_xml :=
     xmltype('<DEMO>
                <COL1>10</COL1>
                <COL2>20</COL2>
              </DEMO>');
  source_xml.toObject(target_obj);
end;
/

set echo off
