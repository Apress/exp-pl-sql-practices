set echo on
set serverout on
declare
  type t_descr_list is table of hardware.descr%type;
  l_descr_list t_descr_list;
begin
  select descr
  bulk collect
  into   l_descr_list
  from   hardware
  where  aisle = 0
  and    item = 0;
  dbms_output.put_line('Item was found');
exception
  when no_data_found then
    dbms_output.put_line('Invalid item specified');
end;
/
set echo off