set echo on
declare
  l_descr hardware.descr%type;
begin
  select descr
  into   l_descr
  from   hardware
  where  aisle = 1
  and    item = 1;
end;
/
set echo off
