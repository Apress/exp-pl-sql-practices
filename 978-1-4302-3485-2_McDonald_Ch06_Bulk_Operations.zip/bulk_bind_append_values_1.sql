@bulk_setup empty

set echo on
insert /*+ APPEND_VALUES */ 
into HARDWARE ( item ) values (1);

select item from HARDWARE;
commit;
select item from HARDWARE;

set echo off
