@bulk_setup populate

set echo on
set timing on
declare
  cursor c_might_exit_early is
    select aisle, item
    from   hardware
    where  item between 400000 and 400050
      or   descr like '%10000%';
  type t_rows is table of c_might_exit_early%rowtype;
  l_rows t_rows;
  
  l_row_cnt pls_integer := 0;
  
begin
  open c_might_exit_early;
  <<cursor_loop>>
  loop  
    fetch c_might_exit_early
    bulk collect into l_rows limit 20;

    for i in 1 .. l_rows.count
    loop
       l_row_cnt := l_row_cnt + 1;
       if l_row_cnt = 40 then 
          exit cursor_loop;
       end if;
    end loop;
  
    exit when c_might_exit_early%notfound;
  end loop;
  close c_might_exit_early;
end;
/
set echo off
set timing off
