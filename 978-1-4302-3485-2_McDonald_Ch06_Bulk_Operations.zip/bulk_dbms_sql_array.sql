@@bulk_setup.sql populate

set echo on
set serverout on
declare
  l_cursor   int  := dbms_sql.open_cursor;
  l_num_row  dbms_sql.number_table;
  l_exec     int;
  l_fetched_rows    int;
begin
 dbms_sql.parse(
         l_cursor,
         'select item from hardware where item <= 1200',
         dbms_sql.native);
 dbms_sql.define_array(l_cursor,1,l_num_row,500,1);
 l_exec := dbms_sql.execute(l_cursor);
 loop
     l_fetched_rows := dbms_sql.fetch_rows(l_cursor);
     dbms_sql.column_value(l_cursor, 1, l_num_row);
     dbms_output.put_line('Fetched '||l_fetched_rows||' rows');
     exit when l_fetched_rows < 500;
  end loop;
  dbms_sql.close_cursor(l_cursor);
end;
/
set echo off
