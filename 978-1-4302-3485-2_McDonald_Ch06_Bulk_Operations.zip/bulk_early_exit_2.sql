@bulk_setup populate

set echo on
set timing on
declare
  cursor c_might_exit_early is
    select aisle, item
    from   hardware
    where  item between 400000 and 400050
      or   descr like '%10000%';
  l_row c_might_exit_early%rowtype;
begin
  open c_might_exit_early;
  loop  
    fetch c_might_exit_early 
    into l_row;
    exit when c_might_exit_early%notfound;

    if c_might_exit_early%rowcount = 40 then
       exit;
    end if;
  
  end loop;
  close c_might_exit_early;
end;
/
set echo off
set timing off
