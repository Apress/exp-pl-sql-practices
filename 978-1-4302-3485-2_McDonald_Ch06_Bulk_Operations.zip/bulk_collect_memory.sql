@@bulk_setup populate

set echo on
set timing off
set serverout on
declare
  type t_row_list is table of hardware.descr%type;
  l_rows t_row_list;

  l_pga_ceiling  number(10);
  
  type t_fetch_sizes is table of pls_integer;
  l_fetch_sizes t_fetch_sizes := t_fetch_sizes(5,10,50,100,500,1000,10000,100000,1000000);
  
  rc      sys_refcursor;
begin
  select value
  into   l_pga_ceiling
  from   v$mystat m, v$statname s
  where  s.statistic# = m.statistic#
  and    s.name = 'session pga memory max';
  
  dbms_output.put_line('Initial PGA: '||l_pga_ceiling);
  
  for i in 1 .. l_fetch_sizes.count 
  loop
    open rc for select descr from hardware;
    loop
       fetch rc bulk collect into l_rows limit l_fetch_sizes(i);
       exit when rc%notfound;
    end loop;
    close rc;
    
    select value
    into   l_pga_ceiling
    from   v$mystat m, v$statname s
    where  s.statistic# = m.statistic#
    and    s.name = 'session pga memory max';

    dbms_output.put_line('Fetch size: '||l_fetch_sizes(i));
    dbms_output.put_line('- PGA Max: '||l_pga_ceiling);
    
  end loop;
  
end;
/
set echo off
