@@bulk_setup empty

set termout off
rem
rem we trying to minimize any spurious delays by ensuring that
rem extent allocation, log file switches etc wont get in the way
rem but of course, we can't really control what is setup on your
rem own database
rem
alter table hardware storage ( next 100m );
alter system switch logfile;
alter system checkpoint;
set termout on

disconnect
connect

set echo on
set serverout on
declare
  type t_row_list is table of hardware.descr%type;
  l_rows t_row_list;

  l_start_of_run timestamp;
  
  l_pga_ceiling  number(10);
  
  type t_bulk_sizes is table of pls_integer;
  l_bulk_sizes t_bulk_sizes := t_bulk_sizes(10,100,1000,10000,100000,1000000);
  
  tot_rows pls_integer := 10000000;
  
begin
  select value
  into   l_pga_ceiling
  from   v$mystat m, v$statname s
  where  s.statistic# = m.statistic#
  and    s.name = 'session pga memory max';
  
  dbms_output.put_line('Initial PGA: '||l_pga_ceiling);
  
  for i in 1 .. l_bulk_sizes.count 
  loop
    
    execute immediate 'truncate table hardware';

    l_start_of_run := systimestamp;
    
    l_rows := t_row_list();
    l_rows.extend(l_bulk_sizes(i));
    for j in 1 .. l_bulk_sizes(i)
    loop
       l_rows(j) := rpad('x',50);
    end loop;
    
    for iter in 1 .. tot_rows / l_bulk_sizes(i) loop
      forall j in 1 .. l_bulk_sizes(i)
        insert into hardware ( descr )  values (l_rows(j));
    end loop;

    select value
    into   l_pga_ceiling
    from   v$mystat m, v$statname s
    where  s.statistic# = m.statistic#
    and    s.name = 'session pga memory max';

    dbms_output.put_line('Bulk size: '||l_bulk_sizes(i));
    dbms_output.put_line('- Elapsed: '||( systimestamp - l_start_of_run));
    dbms_output.put_line('- PGA Max: '||l_pga_ceiling);
    
  end loop;
  
end;
/
