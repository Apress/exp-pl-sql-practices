@@bulk_setup empty

set echo on
alter table hardware 
  add constraint 
  hardware_chk check ( item > 0 );

set serverout on
declare
  type t_list is table of hardware.item%type;
  l_rows t_list := t_list(1,-1,2,3,4,-2);

  bulk_bind_error exception;
  pragma exception_init(bulk_bind_error,-24381);

begin
  forall i in 1 .. l_rows.count save exceptions
    insert into hardware ( item ) values (l_rows(i));

exception
  when bulk_bind_error then
    dbms_output.put_line(
       'There were '||sql%bulk_exceptions.count||' errors in total');
    for i in 1 .. sql%bulk_exceptions.count loop
       dbms_output.put_line(
          'Error '||i||' occurred at array index:'||
           sql%bulk_exceptions(i).error_index);
       dbms_output.put_line('- error code:'||
           sql%bulk_exceptions(i).error_code);
       dbms_output.put_line('- error text:'||
           sqlerrm(-sql%bulk_exceptions(i).error_code));
    end loop;

end;
/
select item from hardware;
set echo off

