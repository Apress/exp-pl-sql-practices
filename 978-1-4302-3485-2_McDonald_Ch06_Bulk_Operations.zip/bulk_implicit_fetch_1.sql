set echo on
begin
  for i in (
    select descr
    from   hardware
    where  aisle = 1
    and    item between 1 and 500 )
  loop
     null;
  end loop;
end;
/
set echo off
