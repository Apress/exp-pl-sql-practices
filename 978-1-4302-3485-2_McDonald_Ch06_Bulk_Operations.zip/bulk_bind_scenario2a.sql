@bulk_setup empty

set timing off
set echo on
declare
  type t_num_list is table of hardware.item%type index by pls_integer;

  val t_num_list;
begin

  val(10) := 10;
--  val(11) := 20;
  val(12) := 20;
  
  FORALL i IN val.first .. val.last
     insert into hardware ( item ) values (val(i));
 
end;
/

set echo off
