rem @@bulk_setup.sql populate

set echo on
create or replace
package PKG2 is

 type t_num_list is table of hardware.item%type index by pls_integer;
 
 procedure open_cur(rc in out sys_refcursor);
 
 procedure fetch_cur(rc in out sys_refcursor, p_rows out t_num_list);

end;
/

create or replace
package body PKG2 is

 procedure open_cur(rc in out sys_refcursor) is
 begin
   open rc for select item from hardware;
 end;
 
 procedure fetch_cur(rc in out sys_refcursor, p_rows out t_num_list) is
 begin
   fetch rc bulk collect into p_rows limit 1000;
 end;

end;
/
set echo off
