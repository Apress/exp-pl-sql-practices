@@bulk_setup empty
set timing off
set echo on
alter table hardware 
  add constraint 
  hardware_chk check ( item > 0 );

declare
  type t_list is table of hardware.item%type;
  l_rows t_list := t_list(1,-1,2,3,4,-2);
begin
  forall i in 1 .. l_rows.count 
    insert into hardware ( item ) values (l_rows(i));
end;
/
select count(*) from HARDWARE;
set echo off