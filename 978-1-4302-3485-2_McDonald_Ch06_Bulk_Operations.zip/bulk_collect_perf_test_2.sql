set echo on

select value
from   v$mystat m, v$statname s
where  s.statistic# = m.statistic#
and    s.name = 'session pga memory max';

alter session set plsql_optimize_level = 2;

set timing on
begin
  for i in ( 
    select descr d3
    from   hardware )
  loop
    null;
  end loop;
end;
/

select value
from   v$mystat m, v$statname s
where  s.statistic# = m.statistic#
and    s.name = 'session pga memory max';

set echo off
