set serveroutput on size 1000000
ALTER SESSION SET PLSQL_CCFLAGS = 'DBC:TRUE';

CREATE OR REPLACE 
PROCEDURE assert (condition_IN IN BOOLEAN
                 ,msg_IN  IN VARCHAR2 := null
                 ,module_IN IN VARCHAR2 := null)
IS
  ASSERTFAIL_C CONSTANT INTEGER := -20999;
  BEGIN
    IF NOT NVL(condition_IN,FALSE) -- assertfail on null
    THEN
      RAISE_APPLICATION_ERROR -- per doc ASSERTFAIL accepts 2048
              ( ASSERTFAIL_C, 'ASSERTFAIL:'||SUBSTR(module_IN,1,30)||':'
                ||SUBSTR (msg_IN,1,2046) ); -- fill 2048 with msg
   END IF;
END assert;
/
CREATE OR REPLACE PUBLIC SYNONYM assert FOR assert;
GRANT EXECUTE ON assert TO PUBLIC;

CREATE OR REPLACE PACKAGE DBC_example
AS
  -- example test procedures/functions
  PROCEDURE proc01 (p1 varchar2);
  FUNCTION  func01 (p1 varchar2) RETURN NUMBER;
  FUNCTION  odd  (p1 number) RETURN BOOLEAN;
  FUNCTION  even (p1 number) RETURN BOOLEAN;
  PROCEDURE proc02;
  
  ----------------------------------------------------------
  -- SLPA declarations (standard local packaged assertion)
  ----------------------------------------------------------
  ASSERTFAIL     EXCEPTION;
  ASSERTFAIL_C   CONSTANT INTEGER := -20999;
  PRAGMA EXCEPTION_INIT(ASSERTFAIL, -20999);
  ----------------------------------------------------------
END DBC_example;
/


CREATE OR REPLACE PACKAGE BODY DBC_example
AS
  -- package name for assertfail msg
  PKGNAME_C      CONSTANT VARCHAR2(20) := $$PLSQL_UNIT;  -- NOTE 10g construct  
  -- foreward declare assert so all module implementations can reference it
  PROCEDURE assert (condition_IN IN BOOLEAN
                   ,msg_IN       IN VARCHAR2 := NULL
                   ,module_IN    IN VARCHAR2 := NULL);
  PROCEDURE assertpre (condition_IN IN BOOLEAN
                      ,msg_IN       IN VARCHAR2 := NULL
                      ,module_IN    IN VARCHAR2 := NULL);
  PROCEDURE assertpost(condition_IN IN BOOLEAN
                      ,msg_IN       IN VARCHAR2 := NULL
                      ,module_IN    IN VARCHAR2 := NULL);

  ----------------------------------------------------------
  -- test/example procedures and functions
  ----------------------------------------------------------
  PROCEDURE proc01 (p1 varchar2)
  IS
    --  local module name for assert calls
    l_module VARCHAR2(30) := 'PROC01';
  BEGIN
    -- enforce NOT NULL inputs precondition
    assert(p1 IS NOT NULL,'p1 NOT NULL', l_module); 
    -- procedure logic
    null;
    -- a very bad postcondition!
    assert(FALSE,'Boo hoo on you');  -- assertfail w/out passing module
  END proc01;

  FUNCTION  func01 (p1 varchar2) RETURN NUMBER
  IS
    l_return NUMBER;
    l_module VARCHAR2(30) := 'FUNC01';
  BEGIN
    -- preconditions
    assertpre(p1 IS NOT NULL,'p1 NOT NULL',l_module);
    null;
    -- postcondition check and return
    assertpost(l_return IS NOT NULL, 'RETURN NOT NULL',l_module);
    RETURN l_return;
  END func01;
  
  FUNCTION  odd (p1 number) RETURN BOOLEAN
  IS
    l_return BOOLEAN;
    l_module VARCHAR2(30) := 'ODD';
  BEGIN
    -- preconditions
    assertpre(p1 IS NOT NULL,'p1 NOT NULL',l_module);
    assertpre(p1 = TRUNC(p1), 'p1 INTEGER',l_module);
    -- function logic: returns TRUE if p1 ODD
    l_return := MOD(p1,2)=1;
    -- postcondition check and return
    assertpost(l_return IS NOT NULL, 'RETURN NOT NULL',l_module);
    RETURN l_return;
  END odd; 

  FUNCTION  even (p1 number) RETURN BOOLEAN
  IS
    l_return BOOLEAN;
    l_module VARCHAR2(30) := 'EVEN';
  BEGIN
    -- preconditions
    assertpre(p1 IS NOT NULL,'p1 NOT NULL',l_module);
    assertpre(p1 = TRUNC(p1), 'p1 INTEGER',l_module);
    -- function logic: returns TRUE if p1 EVEN
    l_return := p1/2 = TRUNC(p1/2);
    -- postcondition check and return
    assertpost(l_return IS NOT NULL, 'RETURN NOT NULL',l_module);
    assertpost(NOT(l_return AND odd(p1)),'NOT(EVEN AND ODD)',l_module);
    assertpost(l_return OR odd(p1),'EVEN OR ODD',l_module);
    RETURN l_return;
  END even; 

  PROCEDURE proc02
  IS
    l_module VARCHAR2(30) := 'PROC02';
  BEGIN
    -- conditional precondition assertion
    $IF $$DBC $THEN
    assertpre(FALSE,'Assert FALSE precondition',l_module);
    $END
    
    -- procedure logic
    null;
  END proc02;
  ----------------------------------------------------------
  -- standard local packaged assertion procedure
  ----------------------------------------------------------
  PROCEDURE assert (condition_IN IN BOOLEAN
                   ,msg_IN       IN VARCHAR2 := NULL
                   ,module_IN    IN VARCHAR2 := NULL)
  IS
    l_assertmsg VARCHAR2(2048) := 'ASSERTFAIL:'||SUBSTR(PKGNAME_C,1,30)||'.'; -- assertmsg prefix
  BEGIN
    -- test the asserted condition
    IF NOT NVL(condition_IN,FALSE)   -- fail on null input
    THEN
      -- finish initializing assertmsg
      l_assertmsg := l_assertmsg || SUBSTR(NVL(module_IN,'?MODULE?')||':'||msg_IN,1,2046);
      -- raise the standardized exception
      RAISE_APPLICATION_ERROR (ASSERTFAIL_C, l_assertmsg, FALSE); -- FALSE
    END IF;
  END assert;
  
  -- assert for preconditions
  PROCEDURE assertpre (condition_IN IN BOOLEAN
                      ,msg_IN       IN VARCHAR2 := NULL
                      ,module_IN    IN VARCHAR2 := NULL)
  IS
  BEGIN
     assert (condition_IN,'Pre:'||msg_IN,module_IN);
  END assertpre;
  
  -- assert for postconditions
  PROCEDURE assertpost(condition_IN IN BOOLEAN
                      ,msg_IN       IN VARCHAR2 := NULL
                      ,module_IN    IN VARCHAR2 := NULL)
  IS
  BEGIN
     assert (condition_IN,'Post:'||msg_IN,module_IN);
  END assertpost;
  
BEGIN
  assert(TRUE); -- pkg initilization token
END DBC_example;
/
show errors

-----------------------------------
-- test proc01 and func01 with
-- null and non-null inputs
-----------------------------------
execute DBC_example.proc01(null);
execute DBC_example.proc01('VALUE');

declare
  n number;
begin
  n := DBC_example.func01(null);
end;
/

declare
  n number;
begin
  n := DBC_example.func01('VALUE');
end;
/

------------------------------------------
-- test script for odd/even functions
-- (postcondition regression testing)
------------------------------------------
begin
  for i in 1..10
  loop
    -- test odd against known results
    if DBC_example.odd(i) then
       dbms_output.put_line(i||' is ODD');
    end if;
    
    -- separately test the even function
    if DBC_example.even(i) then
       dbms_output.put_line(i||' is EVEN');
    end if;
  end loop;
end;
/

begin
  if DBC_example.odd(1.1) then
    dbms_output.put_line('1.1 is ODD');
  end if;
end;
/
begin
  if DBC_example.even(1.1) then
    dbms_output.put_line('1.1 is EVEN');
  end if;
end;
/

---------------------------------
-- test proc02 conditional 
-- precondition assertion
-- using PLSQL_CCFLAGS
---------------------------------
execute DBC_example.proc02
ALTER SESSION SET PLSQL_CCFLAGS = 'DBC:FALSE';
ALTER PACKAGE DBC_example COMPILE BODY;
execute DBC_example.proc02