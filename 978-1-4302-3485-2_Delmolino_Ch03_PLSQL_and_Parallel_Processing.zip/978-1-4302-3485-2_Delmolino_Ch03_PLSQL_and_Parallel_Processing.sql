create or replace package map_reduce_type as
  type key_value_pair is record (
    key_item    varchar2(32),
    value_item  number
  );
  type key_value_pairs is table of key_value_pair;
end map_reduce_type;
/

create or replace package map_letter_count as
  function result_set (p_input in varchar2) 
    return map_reduce_type.key_value_pairs pipelined;
end map_letter_count;
/

create or replace package body map_letter_count as

  function result_set (p_input in varchar2)
    return map_reduce_type.key_value_pairs pipelined is
    
    l_key_value_pair map_reduce_type.key_value_pair;
    
    begin
      
      for i in 1..length(p_input) loop
      
        l_key_value_pair.key_item := substr(p_input,i,1);
        l_key_value_pair.value_item := 1;

        pipe row(l_key_value_pair);
        
      end loop;    
      
      return;
      
    end result_set;

end map_letter_count;
/

select * from table(
map_letter_count.result_set('Hello, world!')
);

create or replace package map_letter_count as
  function result_set (p_documents in sys_refcursor) 
    return map_reduce_type.key_value_pairs pipelined;
end map_letter_count;
/

create table documents 
as 
select rownum doc_id, column_name text 
from dba_tab_columns 
where rownum <= 10;

create or replace package body map_letter_count as

  function result_set (p_documents in sys_refcursor)
    return map_reduce_type.key_value_pairs pipelined is
    
    type document_type is record (
      doc_id number,
      text   varchar2(4000)
    );
    l_document       document_type;
    l_key_value_pair map_reduce_type.key_value_pair;
    
    begin
    
      fetch p_documents into l_document;
      loop
        exit when p_documents%notfound;
                
        for i in 1..length(l_document.text) loop
      
           l_key_value_pair.key_item := substr(l_document.text,i,1);
           l_key_value_pair.value_item := 1;

           pipe row(l_key_value_pair);
        
        end loop;
        
        fetch p_documents into l_document;
        
      end loop;
      
      return;
      
    end result_set;

end map_letter_count;
/

select * from table(
map_letter_count.result_set(
cursor(select doc_id, text from documents)
)
);
 
drop table documents;
create table documents 
as 
select rownum doc_id, column_name text from dba_tab_columns;

select count(*)
from
(
select * from table(
map_letter_count.result_set(
cursor(select doc_id, text from documents)
)
)
);

select * from v$pq_sesstat;

select count(*)
from
(
select /*+ parallel */ * from table(
map_letter_count.result_set(
cursor(select doc_id, text from documents)
)
)
);

create or replace package map_letter_count as
  function result_set (p_documents in sys_refcursor) 
    return map_reduce_type.key_value_pairs pipelined
      parallel_enable (partition p_documents by any);
end map_letter_count;
/
 
create or replace package body map_letter_count as

  function result_set (p_documents in sys_refcursor)
    return map_reduce_type.key_value_pairs pipelined
    parallel_enable (partition p_documents by any) is
    
    type document_type is record (
      doc_id number,
      text   varchar2(4000)
    );
    l_document       document_type;
    l_key_value_pair map_reduce_type.key_value_pair;
    
    begin
    
      fetch p_documents into l_document;
      loop
        exit when p_documents%notfound;
                
        for i in 1..length(l_document.text) loop
      
           l_key_value_pair.key_item := substr(l_document.text,i,1);
           l_key_value_pair.value_item := 1;

           pipe row(l_key_value_pair);
        
        end loop;
        
        fetch p_documents into l_document;
        
      end loop;
      
      return;
      
    end result_set;

end map_letter_count;
/

select count(*)
from
(
select /*+ parallel */ * from table(
map_letter_count.result_set(
cursor(select doc_id, text from documents)
)
)
);

create or replace package reduce_letter_count is
  function result_set (p_key_value_pairs in sys_refcursor) 
    return map_reduce_type.key_value_pairs pipelined
      parallel_enable (partition p_key_value_pairs by any);
end reduce_letter_count;
/

create or replace package body reduce_letter_count as

  function result_set (p_key_value_pairs in sys_refcursor) 
    return map_reduce_type.key_value_pairs pipelined
      parallel_enable (partition p_key_value_pairs by any) is
    
    l_in1_key_value_pair map_reduce_type.key_value_pair;
    l_out_key_value_pair map_reduce_type.key_value_pair;
    
    begin
    
      fetch p_key_value_pairs into l_in1_key_value_pair;
      l_out_key_value_pair.key_item := l_in1_key_value_pair.key_item;
      l_out_key_value_pair.value_item := 0;

      loop
        exit when p_key_value_pairs%notfound;
        
        if l_out_key_value_pair.key_item = l_in1_key_value_pair.key_item 
        then
           
          l_out_key_value_pair.value_item := 
            l_out_key_value_pair.value_item + 
            l_in1_key_value_pair.value_item;
        
        else
                
          pipe row(l_out_key_value_pair);
          
          l_out_key_value_pair.key_item := l_in1_key_value_pair.key_item;
          l_out_key_value_pair.value_item := 1;
           
        end if;

        fetch p_key_value_pairs into l_in1_key_value_pair;
        
      end loop;
      
      pipe row(l_out_key_value_pair);
        
      return;
      
    end result_set;

end reduce_letter_count;
/

create or replace package single_map_letter_count as
  function result_set (p_input in varchar2) 
    return map_reduce_type.key_value_pairs pipelined;
end single_map_letter_count;
/

create or replace package body single_map_letter_count as

  function result_set (p_input in varchar2)
    return map_reduce_type.key_value_pairs pipelined is
    
    l_key_value_pair map_reduce_type.key_value_pair;
    
    begin
      
      for i in 1..length(p_input) loop
      
        l_key_value_pair.key_item := substr(p_input,i,1);
        l_key_value_pair.value_item := 1;

        pipe row(l_key_value_pair);
        
      end loop;    
      
      return;
      
    end result_set;

end single_map_letter_count;
/

select * from table(
reduce_letter_count.result_set(
cursor(select * from table(
single_map_letter_count.result_set('Hello, world!')
))))
order by key_item;
 
create or replace package map_reduce_type as
  type key_value_pair is record (
    key_item    varchar2(32),
    value_item  number
  );
  type key_value_pairs is table of key_value_pair;
  type key_value_pair_cursor is ref cursor
    return key_value_pair;
end map_reduce_type;
/
	
create or replace package reduce_letter_count is

  function result_set 
      (p_key_value_pairs in map_reduce_type.key_value_pair_cursor) 
    return map_reduce_type.key_value_pairs pipelined
      parallel_enable (
        partition p_key_value_pairs by range(key_item)
        );

end reduce_letter_count;
/
 
create or replace package body reduce_letter_count as

  function result_set 
      (p_key_value_pairs in map_reduce_type.key_value_pair_cursor) 
    return map_reduce_type.key_value_pairs pipelined
      parallel_enable (
        partition p_key_value_pairs by range(key_item)
        ) is
    
    l_in1_key_value_pair map_reduce_type.key_value_pair;
    l_out_key_value_pair map_reduce_type.key_value_pair;
    
    begin
    
      fetch p_key_value_pairs into l_in1_key_value_pair;
      l_out_key_value_pair.key_item := l_in1_key_value_pair.key_item;
      l_out_key_value_pair.value_item := 0;

      loop
        exit when p_key_value_pairs%notfound;
        
        if l_out_key_value_pair.key_item = l_in1_key_value_pair.key_item 
        then
           
          l_out_key_value_pair.value_item := 
            l_out_key_value_pair.value_item + 
            l_in1_key_value_pair.value_item;
        
        else
                
          pipe row(l_out_key_value_pair);
          
          l_out_key_value_pair.key_item := l_in1_key_value_pair.key_item;
          l_out_key_value_pair.value_item := 1;
           
        end if;

        fetch p_key_value_pairs into l_in1_key_value_pair;
        
      end loop;
      
      pipe row(l_out_key_value_pair);
        
      return;
      
    end result_set;

end reduce_letter_count;
/

select * from table(
reduce_letter_count.result_set(
cursor(select * from table(
single_map_letter_count.result_set('Hello, world!')
))))
order by key_item;

create or replace package reduce_letter_count is

  function result_set 
      (p_key_value_pairs in map_reduce_type.key_value_pair_cursor) 
    return map_reduce_type.key_value_pairs pipelined
      parallel_enable (
        partition p_key_value_pairs by range(key_item))
        order p_key_value_pairs by (key_item);

end reduce_letter_count;
/
 
create or replace package body reduce_letter_count as

  function result_set 
      (p_key_value_pairs in map_reduce_type.key_value_pair_cursor) 
    return map_reduce_type.key_value_pairs pipelined
      parallel_enable (
        partition p_key_value_pairs by range(key_item))
        order p_key_value_pairs by (key_item)
        is
    
    l_in1_key_value_pair map_reduce_type.key_value_pair;
    l_out_key_value_pair map_reduce_type.key_value_pair;
    
    begin
    
      fetch p_key_value_pairs into l_in1_key_value_pair;
      l_out_key_value_pair.key_item := l_in1_key_value_pair.key_item;
      l_out_key_value_pair.value_item := 0;

      loop
        exit when p_key_value_pairs%notfound;
        
        if l_out_key_value_pair.key_item = l_in1_key_value_pair.key_item 
        then
           
          l_out_key_value_pair.value_item := 
            l_out_key_value_pair.value_item + 
            l_in1_key_value_pair.value_item;
        
        else
                
          pipe row(l_out_key_value_pair);
          
          l_out_key_value_pair.key_item := l_in1_key_value_pair.key_item;
          l_out_key_value_pair.value_item := 1;
           
        end if;

        fetch p_key_value_pairs into l_in1_key_value_pair;
        
      end loop;
      
      pipe row(l_out_key_value_pair);
        
      return;
      
    end result_set;

end reduce_letter_count;
/

select * from table(
reduce_letter_count.result_set(
cursor(select * from table(
single_map_letter_count.result_set('Hello, world!')
))))
order by key_item;

drop table documents;
create table documents 
as 
select rownum doc_id, column_name text from dba_tab_columns;

select /*+ parallel */ * from table(
reduce_letter_count.result_set(
cursor(select /*+ parallel */ * from table(
map_letter_count.result_set(cursor(select * from documents))
))))
order by key_item;

select    /*+ parallel */
          letter key_item, 
          count(*) value_item
from
(
select    substr(d.text,c.i,1) letter
from      documents d,
          (select level i from dual connect by level <= 30) c
)
where     letter is not null
group by  letter
order by  letter;
