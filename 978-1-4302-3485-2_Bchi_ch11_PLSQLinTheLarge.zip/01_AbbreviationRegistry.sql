-----------------------------------------------------------------------------
--  Expert PL/SQL Practices, published by Apress, ISBN 978-1-4302-3485-2   --
--  Demo code for chapter 11, PL/SQL Programming in the Large              --
--  Not meant for production use.                                          --
--  Author: Martin B�chi                                                   --
-----------------------------------------------------------------------------


-----------------------------------------------------------------------------
-- CLEANUP FROM PREVIOUS RUN
-----------------------------------------------------------------------------
declare
  l_cnt                      pls_integer;
begin
  select count(*)
  into   l_cnt
  from   user_tables
  where  table_name = 'ABBR_REG';
  if l_cnt = 1 then
    execute immediate 'drop table abbr_reg';
  end if;
end;
/


-----------------------------------------------------------------------------
-- GENERATE PL/SCOPE IN SESSION
-----------------------------------------------------------------------------
alter session set plscope_settings="IDENTIFIERS:ALL";


-----------------------------------------------------------------------------
-- CREATE TABLE OF ABBREVIATIONS
-----------------------------------------------------------------------------
create table abbr_reg(
  abbr                    varchar2(30)  primary key  -- Abbreviation, e.g., ABBR
 ,text                    varchar2(100) not null     -- Abbreviated text, e.g., ABBREVIATION
 ,descn                   varchar2(400)              -- Description, explain concept
) organization index;
create unique index abbr_reg#u#1 on abbr_reg(text);


-----------------------------------------------------------------------------
-- CREATE PACKAGE TO MANAGE AND CHECK ABBREVIATIONS
-----------------------------------------------------------------------------
create or replace package abbr_reg#
is
  ------------------------------------------------------------------------------
  -- Registry of abbreviations for SQL and PL/SQL identifier parts, such as
  -- ABBR for ABBREVIATION and REG for REGISTRY. All identifiers must be made up
  -- of registered abbreviations separated by underscores, e.g. abbr_reg.
  -- Contains also terms not to be abbreviated.
  ------------------------------------------------------------------------------

  ------------------------------------------------------------------------------
  -- Insert an abbreviation into the registry.
  ------------------------------------------------------------------------------
  procedure ins_abbr(
    i_abbr                    varchar2
   ,i_text                    varchar2
   ,i_descn                   varchar2 := null
  );

  ------------------------------------------------------------------------------
  -- Check whether only registered abbreviations are used as identifier parts.
  ------------------------------------------------------------------------------
  procedure chk_abbr;
end abbr_reg#;
/

create or replace package body abbr_reg#
is
  procedure ins_abbr(
    i_abbr                    varchar2
   ,i_text                    varchar2
   ,i_descn                   varchar2
  )
  is
  begin
    insert into abbr_reg(abbr, text, descn)
    values(upper(trim(i_abbr)), upper(trim(i_text)), i_descn);
  end ins_abbr;

  ------------------------------------------------------------------------------
  procedure chk_ident(
    i_ident                  varchar2
   ,i_loc                    varchar2
  )
  is
    l_start_pos              pls_integer := 1;
    l_end_pos                pls_integer := 1;
    l_abbr_cnt               pls_integer;
    l_part                   varchar2(30);
    c_ident_len     constant pls_integer := length(i_ident);
  begin
    while l_start_pos < c_ident_len loop
      -- DETERMINE NEXT PART --
      while     l_end_pos <= c_ident_len
            and substr(i_ident, l_end_pos, 1) not in ('_', '#', '$')
      loop
        l_end_pos := l_end_pos + 1;
      end loop;
      l_part := upper(substr(i_ident, l_start_pos, l_end_pos - l_start_pos));
      
      -- CHECK WHETHER THE PART IS A REGISTERED ABBREVIATION --
      select count(*)
      into   l_abbr_cnt
      from   abbr_reg
      where  abbr = l_part;

      if l_abbr_cnt = 0 then
        dbms_output.put_line('Unregistered part ' || l_part || ' in ident ' || i_ident
                             || ' at ' || i_loc || '.');
      end if;
      
      -- INIT VARIABLES FOR NEXT LOOP --
      l_end_pos := l_end_pos + 1;
      l_start_pos := l_end_pos;
    end loop;
  end chk_ident;

  ------------------------------------------------------------------------------
  procedure chk_abbr
  is
  begin
    -- PL/SQL USING PL/SCOPE --
    for c in (
      select name
            ,object_type
            ,object_name
            ,line
      from   user_identifiers
      where  usage = 'DECLARATION'
      order by object_name, object_type, line
    ) loop
      chk_ident(
        i_ident => c.name
       ,i_loc   => c.object_type || ' ' || c.object_name || ' at line ' || c.line
      ); 
    end loop;
    
    -- OTHER ITEMS: USER_OBJECTS, USER_TAB_COLUMNS, ... --
    -- ...
  end chk_abbr;
  
end abbr_reg#;
/


-----------------------------------------------------------------------------
-- SAMPLE PL/SCOPE DATA
-----------------------------------------------------------------------------
column name format a30
select name
      ,type
      ,object_type
      ,object_name
      ,line
from   user_identifiers
where  usage = 'DECLARATION'
order by object_type, object_name, line;


-----------------------------------------------------------------------------
-- TURN OFF PL/SCOPE GENERATION IN SESSION
-----------------------------------------------------------------------------
alter session set plscope_settings="IDENTIFIERS:NONE";
