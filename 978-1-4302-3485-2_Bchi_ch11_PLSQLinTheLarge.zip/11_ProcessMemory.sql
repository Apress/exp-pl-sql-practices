-----------------------------------------------------------------------------
--  Expert PL/SQL Practices, published by Apress, ISBN 978-1-4302-3485-2   --
--  Demo code for chapter 11, PL/SQL Programming in the Large              --
--  Not meant for production use.                                          --
--  Author: Martin B�chi                                                   --
-----------------------------------------------------------------------------


-----------------------------------------------------------------------------
-- OVERALL MEMORY
-----------------------------------------------------------------------------
column sid format 9999
column username format a8
select se.sid
      ,se.username
      ,round(pr.pga_used_mem / power(1024, 2))     pga_used_mb
      ,round(pr.pga_alloc_mem / power(1024, 2))    pga_alloc_mb
      ,round(pr.pga_freeable_mem / power(1024, 2)) pga_freeable_mb
      ,round(pr.pga_max_mem / power(1024, 2))      pga_max_mb
from   v$session se
      ,v$process pr
where  se.paddr = pr.addr
   and se.type != 'BACKGROUND'
order by pr.pga_alloc_mem desc;


-----------------------------------------------------------------------------
-- PROCEDURE TO PRINT DETAILED MEMORY USAGE
-----------------------------------------------------------------------------
create or replace procedure print_session_mem
is
begin
  dbms_output.put_line('Category  Allocated KB     Used KB  Max all KB');
  dbms_output.put_line('----------------------------------------------');
  for c in (
    select pm.*
    from   v$session        se
          ,v$process        pr
          ,v$process_memory pm
    where  se.sid   = sys_context('userenv', 'sid')
       and se.paddr = pr.addr
       and pr.pid   = pm.pid
  ) loop
    dbms_output.put_line(rpad(c.category, 10)
                      || to_char(round(c.allocated     / 1024), '999G999G999')
                      || to_char(round(c.used          / 1024), '999G999G999')
                      || to_char(round(c.max_allocated / 1024), '999G999G999'));
  end loop;
end print_session_mem; 
/
set serveroutput on 
exec print_session_mem


-----------------------------------------------------------------------------
-- ALLOCATE MEMORY FOR COLLECTION AND PRINT MEMORY USAGE
-----------------------------------------------------------------------------
create or replace package mem#
is
  type t_char1000_tab is table of varchar2(1000) index by pls_integer;
  g_list                     t_char1000_tab;
end mem#;
/

exec print_session_mem
begin
  select lpad('x', 1000, 'x')
  bulk collect into mem#.g_list
  from   dual
  connect by level <= 100000;
end;
/
exec print_session_mem
exec mem#.g_list.delete
exec print_session_mem
exec dbms_session.free_unused_user_memory
exec print_session_mem


-----------------------------------------------------------------------------
-- PRINT MEMORY USAGE IN SESSION BY PL/SQL UNIT
-----------------------------------------------------------------------------
begin
  select lpad('x', 1000, 'x')
  bulk collect into mem#.g_list
  from   dual
  connect by level < 100000;
end;
/
declare
  l_owner_names             dbms_session.lname_array;
  l_unit_names              dbms_session.lname_array;
  l_unit_types              dbms_session.integer_array;
  l_used_amounts            dbms_session.integer_array;
  l_free_amounts            dbms_session.integer_array;
begin
  dbms_session.get_package_memory_utilization(
    owner_names  => l_owner_names 
   ,unit_names   => l_unit_names  
   ,unit_types   => l_unit_types  
   ,used_amounts => l_used_amounts
   ,free_amounts => l_free_amounts
  );
  for i in 1..l_owner_names.count loop
    dbms_output.put_line(
      case l_unit_types(i)
        when  7 then 'PROCEDURE   '
        when  8 then 'FUNCTION    '
        when  9 then 'PACKAGE     '
        when 11 then 'PACKAGE BODY'
        else         'TYPE     ' || lpad(l_unit_types(i), 3)
      end || ' '
    || rpad(l_owner_names(i) || '.' || l_unit_names(i), 26)
    || ' uses ' || to_char(round(l_used_amounts(i) / 1024), '999G999G999')
    || ' KB and has ' || to_char(round(l_free_amounts(i) / 1024), '999G999G999')
    || ' KB free.');
  end loop;
end;
/


-----------------------------------------------------------------------------
-- HPROF FOR UGA ALLOCATION AND DE-ALLOCATION
-----------------------------------------------------------------------------
create or replace directory hprof_dir as '/tmp';
begin
  dbms_hprof.start_profiling(
    location    => 'HPROF_DIR'
   ,filename    => 'hprofuga'
   ,profile_uga => true
  );
end;
/
declare
  procedure alloc
  is
  begin
    select lpad('x', 1000, 'x')
    bulk collect into mem#.g_list
    from   dual
    connect by level < 100000;
  end alloc;
  procedure dealloc
  is
  begin
   mem#.g_list.delete;
   dbms_session.free_unused_user_memory;
  end dealloc;
begin
  alloc;
  dealloc;
end;
/
exec dbms_hprof.stop_profiling

declare
  l_run_num                  pls_integer;
begin
  l_run_num := dbms_hprof.analyze(
    location    => 'HPROF_DIR'
   ,filename    => 'hprofuga'
   ,profile_uga => true
   ,profile_pga => false
  );
  dbms_output.put_line(l_run_num);
end;
/

!$ORACLE_HOME/bin/plshprof -uga -output /tmp/hprofuga /tmp/hprofuga