-----------------------------------------------------------------------------
--  Expert PL/SQL Practices, published by Apress, ISBN 978-1-4302-3485-2   --
--  Demo code for chapter 11, PL/SQL Programming in the Large              --
--  Not meant for production use.                                          --
--  Author: Martin B�chi                                                   --
-----------------------------------------------------------------------------


-----------------------------------------------------------------------------
-- CLEANUP FROM PREVIOUS RUN
-----------------------------------------------------------------------------
declare
  procedure drop_user(
    i_username               varchar2
  )
  is
    l_cnt                    pls_integer;
  begin
    select count(*)
    into   l_cnt
    from   dba_users
    where  username = i_username;
    if l_cnt = 1 then
      execute immediate 'drop user ' || i_username || ' cascade';
    end if;
  end drop_user;
begin
  drop_user('K');
  drop_user('X');
end;
/

-- EXECUTE AS DVOWNER
connect dvowner/ava1_owner
declare
  c_rule_set_name  varchar2(90)  := 'Modularization within schema check';
  c_rule_name      varchar2(90)  := 'CHKUSER';
  l_cnt            pls_integer;
begin
  select count(*)
  into   l_cnt
  from   dvsys.dba_dv_rule_set_rule
  where  rule_set_name = c_rule_set_name
     and rule_name     = c_rule_name;
  if l_cnt = 1 then
    dvsys.dbms_macadm.delete_rule_from_rule_set(
      rule_set_name => c_rule_set_name
     ,rule_name     => c_rule_name
    );
  end if;
  --
  select count(*)
  into   l_cnt
  from   dvsys.dba_dv_rule
  where  name = c_rule_name;
  if l_cnt = 1 then
    dvsys.dbms_macadm.delete_rule(
      rule_name => c_rule_name
    );
  end if;
  --
  select count(*)
  into   l_cnt
  from   dvsys.dba_dv_command_rule
  where  command       = 'EXECUTE'
     and object_owner  = 'K'
     and rule_set_name = c_rule_set_name
     and object_name   = '%';
  if l_cnt = 1 then
    dvsys.dbms_macadm.delete_command_rule(
      command         => 'EXECUTE'
     ,object_owner    => 'K'
     ,object_name     => '%'
    );
  end if;
  --
  select count(*)
  into   l_cnt
  from   dvsys.dba_dv_rule_set
  where  rule_set_name = c_rule_set_name;
  if l_cnt = 1 then
    dvsys.dbms_macadm.delete_rule_set(
      rule_set_name   => c_rule_set_name
    );
  end if;
  commit;
end;
/
connect / as sysdba

-----------------------------------------------------------------------------
-- CREATE USERS
-----------------------------------------------------------------------------
create user k identified by pwd account lock;
create user x identified by pwd account lock;


-----------------------------------------------------------------------------
-- PROCEDURE TO CHECK VALIDITY OF CALL
-----------------------------------------------------------------------------
create or replace function x.valid_call
return pls_integer
is
  c_lf              constant varchar2(1)    := chr(10);    -- UNIX
  c_intf_like       constant varchar2(8)    := '%\_INTF#'; -- Interface unit suffix
  c_owner_like      constant varchar2(5)    := '% K.%';    -- Schema to be checked
  c_module_sep      constant varchar2(1)    := '_';        -- Separator of module prefix
  c_head_line_cnt   constant pls_integer    := 4;          -- Ignored lines in call stack
  l_call_stack               varchar2(4000);               -- Call stack
  l_sol                      pls_integer;                  -- Start pos of current line
  l_eol                      pls_integer;                  -- End pos of current line
  l_callee                   varchar2(200);                -- Called unit
  l_caller                   varchar2(200);                -- Calling unit
  l_res                      boolean;                      -- Valid call?
begin
  l_call_stack := dbms_utility.format_call_stack;
  l_sol := instr(l_call_stack, c_lf, 1, c_head_line_cnt);
  l_eol := instr(l_call_stack, c_lf, l_sol + 1);
  l_callee := substr(l_call_stack, l_sol, l_eol - l_sol);
  -- ONLY CALLS TO NON INTERFACE UNITS OF K MAY BE INVALID --
  if l_callee like c_owner_like and l_callee not like c_intf_like escape '\' then
    l_callee := substr(l_callee, instr(l_callee, '.') + 1);
    -- FIND TOPMOST CALLER OF SCHEMA K, IF ANY, AND CHECK FOR SAME MODULE PREFIX --
    loop
      l_sol := l_eol + 1;
      l_eol := instr(l_call_stack, c_lf, l_sol + 1);
      l_caller := substr(l_call_stack, l_sol, l_eol - l_sol);
      if l_caller like c_owner_like then
        l_caller := substr(l_caller, instr(l_caller, '.') + 1);
        l_res := substr(l_callee, 1, instr(l_callee, c_module_sep))
                 = substr(l_caller, 1, instr(l_caller, c_module_sep));
      end if;
      exit when l_eol = 0 or l_res is not null;
    end loop;
  end if;
  return case when not l_res then 0 else 1 end;
end valid_call;
/


-----------------------------------------------------------------------------
-- GIVE DB VAULT PRIVILEGE TO EXECUTE CHECK FUNCTION
-----------------------------------------------------------------------------
grant execute on x.valid_call to dvsys;


-----------------------------------------------------------------------------
-- CONFIGURE DATABASE VAULT RULES
-----------------------------------------------------------------------------
-- EXECUTE AS DVOWNER
connect dvowner/ava1_owner
declare
  c_rule_set_name  varchar2(90)  := 'Modularization within schema check';
  c_rule_name      varchar2(90)  := 'CHKUSER';
begin
  -- RULE SET: CHECK RULES AND FLAG VIOLATIONS
  dvsys.dbms_macadm.create_rule_set(
    rule_set_name   => c_rule_set_name
   ,description     => null
   ,enabled         => dvsys.dbms_macutl.g_yes
   ,eval_options    => dvsys.dbms_macutl.g_ruleset_eval_all
   ,audit_options   => dvsys.dbms_macutl.g_ruleset_audit_off
   ,fail_options    => dvsys.dbms_macutl.g_ruleset_fail_show
   ,fail_message    => 'Modularization check failed'
   ,fail_code       => -20002
   ,handler_options => dvsys.dbms_macutl.g_ruleset_handler_off
   ,handler         => null
  );
  -- RULE: CHECK WHETHER CALL IS VALID
  dvsys.dbms_macadm.create_rule(
    rule_name => c_rule_name
   ,rule_expr => 'X.VALID_CALL = 1'
  );
  -- ADD RULE TO RULE SET
  dvsys.dbms_macadm.add_rule_to_rule_set(
    rule_set_name => c_rule_set_name
   ,rule_name     => c_rule_name
  );
  -- MATCH CRITERIA: EXECUTE RULE SET ON PL/SQL EXECUTE OF OBJECTS OWNED BY USER K
  dvsys.dbms_macadm.create_command_rule(
    command         => 'EXECUTE'
   ,rule_set_name   => c_rule_set_name
   ,object_owner    => 'K'
   ,object_name     => '%'
   ,enabled         => dvsys.dbms_macutl.g_yes
  );
  commit;
end;
/
connect / as sysdba


-----------------------------------------------------------------------------
-- EXAMPLE 1: CALL (ANY FORMAT) WITHIN SAME MODULE M1 OK
-----------------------------------------------------------------------------
create or replace procedure k.m1_1 is begin null; end;
/
-- Static PL/SQL call
create or replace procedure k.m1_2 is begin m1_1; end;
/
exec k.m1_2
-- Native dynamic PL/SQL call
create or replace procedure k.m1_2 is begin execute immediate 'begin m1_1; end;'; end;
/
exec k.m1_2
-- Dynamic SQL with dbms_sql
create or replace procedure k.m1_2
is
  l_cur                      pls_integer;
  l_res                      pls_integer;
begin
  l_cur := dbms_sql.open_cursor;
  dbms_sql.parse(l_cur, 'begin m1_1; end;', dbms_sql.native);
  l_res := dbms_sql.execute(l_cur);
  dbms_sql.close_cursor(l_cur);
exception
  when others then
    if l_cur is not null then
      dbms_sql.close_cursor(l_cur);
    end if;
    raise;
end m1_2;
/
exec k.m1_2


-----------------------------------------------------------------------------
-- EXAMPLE 2: CALL (ANY FORMAT) FROM MODULE M2 TO M1 NOT OK
-----------------------------------------------------------------------------
-- Static PL/SQL call
create or replace procedure k.m2_3 is begin m1_1; end;
/
exec k.m2_3
-- Native dynamic PL/SQL call
create or replace procedure k.m2_3 is begin execute immediate 'begin m1_1; end;'; end;
/
exec k.m2_3
-- Dynamic SQL with dbms_sql
create or replace procedure k.m2_3
is
  l_cur                      pls_integer;
  l_res                      pls_integer;
begin
  l_cur := dbms_sql.open_cursor;
  dbms_sql.parse(l_cur, 'begin m1_1; end;', dbms_sql.native);
  l_res := dbms_sql.execute(l_cur);
  dbms_sql.close_cursor(l_cur);
exception
  when others then
    if l_cur is not null then
      dbms_sql.close_cursor(l_cur);
    end if;
    raise;
end m2_3;
/
exec k.m2_3
