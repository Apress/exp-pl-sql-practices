-----------------------------------------------------------------------------
--  Expert PL/SQL Practices, published by Apress, ISBN 978-1-4302-3485-2   --
--  Demo code for chapter 11, PL/SQL Programming in the Large              --
--  Not meant for production use.                                          --
--  Author: Martin B�chi                                                   --
-----------------------------------------------------------------------------


-----------------------------------------------------------------------------
-- SQL KEYWORDS, BUILTIN, AND DEFINED BY STANDARD
-----------------------------------------------------------------------------
select count(distinct keyword)
from   v$reserved_words;


-----------------------------------------------------------------------------
-- SHADOW BUILTIN FUNCTION UPPER
-----------------------------------------------------------------------------
create or replace procedure test
  authid definer
is
  function upper(i_text varchar2) return varchar2
  is
  begin
    return lower(i_text);
  end upper;
begin
  dbms_output.put_line(upper('Hello, world!'));
end test;
/
exec test


-----------------------------------------------------------------------------
-- PL/SQL WARNING FLAGS UNDESIRABLE SHADOWING
-----------------------------------------------------------------------------
alter session set plsql_warnings='error:all';
alter procedure test compile;
column error format a120
show error
alter session set plsql_warnings='disable:all';
