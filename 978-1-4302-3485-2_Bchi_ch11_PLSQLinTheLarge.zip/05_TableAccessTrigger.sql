-----------------------------------------------------------------------------
--  Expert PL/SQL Practices, published by Apress, ISBN 978-1-4302-3485-2   --
--  Demo code for chapter 11, PL/SQL Programming in the Large              --
--  Not meant for production use.                                          --
--  Author: Martin B�chi                                                   --
-----------------------------------------------------------------------------


-----------------------------------------------------------------------------
-- Requires that 01_AbbreviationRegistry.sql was executed
-----------------------------------------------------------------------------


-----------------------------------------------------------------------------
-- CREATE TRIGGER TO BLOCK NOT ACCEPTED DML TO TABLE
-----------------------------------------------------------------------------
create or replace trigger abbr_reg#b
before update or insert or delete or merge
on abbr_reg
begin
  if dbms_utility.format_call_stack not like 
       '%package body% K.ABBR_REG#' || chr(10) /*UNIX EOL*/|| '%' then
    raise_application_error(-20999,'Table abbr_reg may only be modified by abbr_reg#.');
  end if;
end;
/


-----------------------------------------------------------------------------
-- DML THROUH PACKAGE ABBR_REG# OK
-----------------------------------------------------------------------------
exec abbr_reg#.ins_abbr('descn', 'description')


-----------------------------------------------------------------------------
-- DIRECT DML NOT OK
-----------------------------------------------------------------------------
insert into abbr_reg(abbr, text) values('reg', 'registry');
