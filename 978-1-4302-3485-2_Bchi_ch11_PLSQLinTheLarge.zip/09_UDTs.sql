-----------------------------------------------------------------------------
--  Expert PL/SQL Practices, published by Apress, ISBN 978-1-4302-3485-2   --
--  Demo code for chapter 11, PL/SQL Programming in the Large              --
--  Not meant for production use.                                          --
--  Author: Martin B�chi                                                   --
-----------------------------------------------------------------------------


-----------------------------------------------------------------------------
-- CLEANUP FROM PREVIOUS RUN
-----------------------------------------------------------------------------
declare
  l_cnt                      pls_integer;
begin
  select count(*)
  into   l_cnt
  from   user_object_tables
  where  table_name = 'BANK_TRX_OBJ';
  if l_cnt = 1 then
    execute immediate 'drop table bank_trx_obj';
  end if;

  select count(*)
  into   l_cnt
  from   user_types
  where  type_name = 'T_BANK_TRX_OBJ';
  if l_cnt = 1 then
    execute immediate 'drop type t_bank_trx_obj force';
  end if;
end;
/


-----------------------------------------------------------------------------
-- GENERATE PL/SCOPE IN SESSION
-----------------------------------------------------------------------------
alter session set plscope_settings="IDENTIFIERS:ALL";


-----------------------------------------------------------------------------
-- CREATE OBJECT TYPES
-----------------------------------------------------------------------------
create or replace type t_bank_trx_obj is object (
  s_id                  integer
 ,s_amount              number

  ------------------------------------------------------------------------------
  -- Returns the amount of the transaction.
  ------------------------------------------------------------------------------
 ,final member function p_amount return number

  ------------------------------------------------------------------------------
  -- Books the transaction.
  ------------------------------------------------------------------------------
 ,not instantiable member procedure book(
   i_text               varchar2
  )
) not instantiable not final;
/

create or replace type body t_bank_trx_obj is
  final member function p_amount return number
  is
  begin
    return s_amount;
  end p_amount;
end;
/

create or replace type t_pay_trx_obj under t_bank_trx_obj (
  ------------------------------------------------------------------------------
  -- Creates a payment transaction. Amount must be positive.
  ------------------------------------------------------------------------------
  constructor function t_pay_trx_obj(
   i_amount             number
  ) return self as result

 ,overriding member procedure book(
   i_text               varchar2
  )
);
/

create or replace type body t_pay_trx_obj is
  constructor function t_pay_trx_obj(
   i_amount             number
  ) return self as result
  is
  begin
    if nvl(i_amount, -1) < 0 then
      raise_application_error(-20000, 'Negative or null amount');
    end if;
    self.s_amount := i_amount;
    return;
  end t_pay_trx_obj;

  ------------------------------------------------------------------------------
  overriding member procedure book(
   i_text               varchar2
  )
  is
  begin
    dbms_output.put_line('Booking t_pay_trx_obj "' || i_text || '" with amount '
      || self.p_amount);
  end book;
end;
/


-----------------------------------------------------------------------------
-- TEST IMPLEMENTATION
-----------------------------------------------------------------------------
declare
  l_bank_trx_obj             t_bank_trx_obj;
begin
  l_bank_trx_obj := new t_pay_trx_obj(100);
  l_bank_trx_obj.book('payroll January');
end;
/


-----------------------------------------------------------------------------
-- NO INFORMATION HIDING. CAN MODIFY ATTRIBUTE S_AMOUNT DIRECTLY
-----------------------------------------------------------------------------
create or replace procedure access_internal
is
  l_bank_trx_obj             t_bank_trx_obj;
begin
  l_bank_trx_obj := new t_pay_trx_obj(100);
  l_bank_trx_obj.s_amount := 200;
  l_bank_trx_obj.book('cheating');
end;
/  
  

-----------------------------------------------------------------------------
-- PL/SCOPE SHOWS UNDESIRABLE ACCESS
-----------------------------------------------------------------------------
alter procedure access_internal compile;

column owner format a5
column name  format a8
column type  format a8
column object_name format a15
column object_type format a11
column usage format a10
column usage_id format 999
column line format 999
column col format 999
select us.name, us.type, us.object_name, us.object_type, us.usage, us.line
from   all_identifiers pm
      ,all_identifiers us
where  pm.object_type  = 'TYPE'
   and (
            pm.type = 'VARIABLE'
         or (pm.type in ('PROCEDURE', 'FUNCTION') and pm.name like 'P\_%' escape '\')
       )
   and pm.usage        = 'DECLARATION'
   and us.signature    = pm.signature
   and (us.owner, us.object_name) not in (
         select ty.owner, ty.type_name
         from   all_types ty
         start with ty.owner     = pm.owner
                and ty.type_name = pm.object_name
         connect by ty.supertype_owner = prior ty.owner
                and ty.supertype_name  = prior ty.type_name
       );  


-----------------------------------------------------------------------------
-- SAMPLE OBJECT TABLE
-----------------------------------------------------------------------------
create table bank_trx_obj of t_bank_trx_obj(s_id primary key)
object identifier is primary key;

insert into bank_trx_obj values(t_pay_trx_obj(1, 100));


-----------------------------------------------------------------------------
-- TURN OFF PL/SCOPE GENERATION IN SESSION
-----------------------------------------------------------------------------
alter session set plscope_settings="IDENTIFIERS:NONE";

