-----------------------------------------------------------------------------
--  Expert PL/SQL Practices, published by Apress, ISBN 978-1-4302-3485-2   --
--  Demo code for chapter 11, PL/SQL Programming in the Large              --
--  Not meant for production use.                                          --
--  Author: Martin B�chi                                                   --
-----------------------------------------------------------------------------

-----------------------------------------------------------------------------
-- Requires that 01_AbbreviationRegistry.sql was executed
-----------------------------------------------------------------------------

-----------------------------------------------------------------------------
-- CLEANUP FROM PREVIOUS RUN
-----------------------------------------------------------------------------
truncate table abbr_reg;
alter system flush shared_pool;


-----------------------------------------------------------------------------
-- RUN PROGRAM TO GENERATE SAMPLE DATA
-----------------------------------------------------------------------------
exec abbr_reg#.ins_abbr('ABBR', 'ABBREVIATION')


-----------------------------------------------------------------------------
-- SHOW ENTRY IN SHARED POOL
-----------------------------------------------------------------------------
column object_name   format a20
column program_line# format 999
set linesize 10000
select ob.object_name
      ,sq.program_line#
      ,sq.sql_text
from   v$sql       sq
      ,all_objects ob
where  sq.command_type in (2 /*insert*/, 6 /*update*/, 7 /*delete*/, 189 /*merge*/)
   and sq.program_id = ob.object_id (+)
   and upper(sq.sql_fulltext) like '%ABBR_REG%';
