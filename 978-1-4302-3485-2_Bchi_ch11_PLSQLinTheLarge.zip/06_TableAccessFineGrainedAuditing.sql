-----------------------------------------------------------------------------
--  Expert PL/SQL Practices, published by Apress, ISBN 978-1-4302-3485-2   --
--  Demo code for chapter 11, PL/SQL Programming in the Large              --
--  Not meant for production use.                                          --
--  Author: Martin B�chi                                                   --
-----------------------------------------------------------------------------


-----------------------------------------------------------------------------
-- Requires that 01_AbbreviationRegistry.sql was executed
-----------------------------------------------------------------------------


-----------------------------------------------------------------------------
-- CLEANUP FROM PREVIOUS RUN
-----------------------------------------------------------------------------
declare
  l_cnt                      pls_integer;
begin
  select count(*)
  into   l_cnt
  from   user_tables
  where  table_name = 'CALL_LOG';
  if l_cnt = 1 then
    execute immediate 'drop table call_log';
  end if;
  
  select count(*)
  into   l_cnt
  from   user_audit_policies
  where  policy_name = 'ABBR_REG#SELECT';
  if l_cnt = 1 then
    dbms_fga.drop_policy(
      object_name     => 'ABBR_REG'
     ,policy_name     => 'ABBR_REG#SELECT'
    );
  end if;
end;
/


-----------------------------------------------------------------------------
-- CREATE TABLE TO LOG CALLS
-----------------------------------------------------------------------------
create table call_log(
   object_schema             varchar2(30)
  ,object_name               varchar2(30)
  ,policy_name               varchar2(30)
  ,caller                    varchar2(200)
  ,sql_text                  varchar2(2000 byte)
  ,constraint call_log#p primary key(object_schema, object_name, policy_name
                                    ,caller, sql_text)
) organization index;


-----------------------------------------------------------------------------
-- CREATE PROCEDURE TO LOG CALLS
-----------------------------------------------------------------------------
create or replace procedure call_log_ins(
  i_object_schema            varchar2
 ,i_object_name              varchar2
 ,i_policy_name              varchar2
)
is
  pragma autonomous_transaction;
  l_caller                   call_log.caller%type;
  l_current_sql              call_log.sql_text%type;

  ------------------------------------------------------------------------------
  -- Returns the call stack below the trigger down to the first non-anonymous block.
  ------------------------------------------------------------------------------
  function caller(
    i_call_stack             varchar2
  ) return varchar2
  as
    c_lf            constant varchar2(1) := chr(10);  -- UNIX
    c_pfx_len       constant pls_integer := 8;
    c_head_line_cnt constant pls_integer := 5;
    l_sol                    pls_integer;
    l_eol                    pls_integer;
    l_res                    varchar2(32767);
    l_line                   varchar2(256);
  begin
    l_sol := instr(i_call_stack, c_lf, 1, c_head_line_cnt) + 1 + c_pfx_len;
    l_eol := instr(i_call_stack, c_lf, l_sol);
    l_line := substr(i_call_stack, l_sol, l_eol - l_sol);
    l_res := l_line;
    while instr(l_line, 'anonymous block') != 0 loop
      l_sol := l_eol + 1 + c_pfx_len;
      l_eol := instr(i_call_stack, c_lf, l_sol);
      l_line := substr(i_call_stack, l_sol, l_eol - l_sol);
      l_res := l_res || c_lf || l_line;  
    end loop;
    return l_res;
  end caller;

begin
  l_caller := nvl(substr(caller(dbms_utility.format_call_stack), 1, 200), 'external');
  l_current_sql := substrb(sys_context('userenv','current_sql'), 1, 2000);
  insert into call_log(
    object_schema
   ,object_name
   ,policy_name
   ,caller
   ,sql_text
  ) values (
    i_object_schema
   ,i_object_name
   ,i_policy_name
   ,l_caller
   ,l_current_sql
  );
  commit;
exception
  when dup_val_on_index then
    rollback;
end call_log_ins;
/


-----------------------------------------------------------------------------
-- ADD FINE-GRAINED AUDITING POLICY
-----------------------------------------------------------------------------
begin
  dbms_fga.add_policy(
    object_name     => 'ABBR_REG'
   ,policy_name     => 'ABBR_REG#SELECT'
   ,handler_module  => 'CALL_LOG_INS'
  );
end;
/


-----------------------------------------------------------------------------
-- RUN PROGRAM TO GENERATE SAMPLE DATA
-----------------------------------------------------------------------------
exec abbr_reg#.chk_abbr


-----------------------------------------------------------------------------
-- DISPLAY LOGGED DATA
-----------------------------------------------------------------------------
column object_name  format a11
column policy_name  format a15
column caller       format a36
set linesize 10000
select object_name, policy_name, caller, sql_text from call_log;
