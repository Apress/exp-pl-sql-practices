-----------------------------------------------------------------------------
--  Expert PL/SQL Practices, published by Apress, ISBN 978-1-4302-3485-2   --
--  Demo code for chapter 11, PL/SQL Programming in the Large              --
--  Not meant for production use.                                          --
--  Author: Martin B�chi                                                   --
-----------------------------------------------------------------------------


-----------------------------------------------------------------------------
-- CLEANUP FROM PREVIOUS RUN
-----------------------------------------------------------------------------
exec dbms_session.reset_package


-----------------------------------------------------------------------------
-- CREATE TEST PROCEDURE - INITIALLY INVALID
-----------------------------------------------------------------------------
create or replace procedure coll_mem_usage(
  i_step                     pls_integer := 1
 ,i_elem_cnt                 pls_integer := 1000000
)
is
  $IF $$COLL_TYPE = 0 $THEN
  type t_char_tab is table of varchar2($$string_len) index by pls_integer;
  $ELSIF $$COLL_TYPE = 1 $THEN
  type t_char_tab is table of varchar2($$string_len) index by varchar2(10);
  $ELSIF $$COLL_TYPE = 2 $THEN
  type t_char_tab is table of varchar2($$string_len);
  $ELSIF $$COLL_TYPE = 3 $THEN
  type t_char_tab is varray(2147483647) of varchar2($$string_len);
  $END
  c_string_len      constant pls_integer := $$string_len;
  l_str             constant varchar2($$string_len) := lpad('x', c_string_len, 'x');
  l_list                     t_char_tab;

  ------------------------------------------------------------------------------
  procedure print_plsql_used_session_mem(
    i_label                  varchar2
  )
  is
    l_used                   number;
  begin
    $IF DBMS_DB_VERSION.VERSION < 11 $THEN
    select pr.pga_used_mem
    $ELSE
    select pm.used
    $END
    into   l_used
    from   v$session        se
          ,v$process        pr
          ,v$process_memory pm
    where  se.sid      = sys_context('userenv', 'sid')
       and se.paddr    = pr.addr
       and pr.pid      = pm.pid
       and pm.category = 'PL/SQL';
    dbms_output.put_line(rpad(i_label, 18) || ' PL/SQL used '
                         || to_char(round(l_used / 1024), '999G999G999') || ' KB');
  end print_plsql_used_session_mem;
begin
  -- INIT --
  dbms_output.put_line(i_elem_cnt || ' elements of length ' || c_string_len || ' step '
                       || i_step || ' type ' || $$coll_type);
  print_plsql_used_session_mem('Init');

  -- ALLOCATE ELEMENTS --
  $IF $$COLL_TYPE = 2 OR $$COLL_TYPE = 3 $THEN /* NESTED TABLE, VARRAY */
  l_list := t_char_tab();
  l_list.extend(i_elem_cnt * i_step);
  $END
  for i in 1..i_elem_cnt loop
    l_list(i * i_step) := l_str;
  end loop;
  print_plsql_used_session_mem('Allocated');

  -- REMOVE ALL BUT 1 ELEMENT --
  for i in 2..i_elem_cnt loop
    $IF $$COLL_TYPE != 3 $THEN /* ASSOCIATIVE ARRAYS, NESTED TABLE */
    l_list.delete(i * i_step);
    $ELSE /* NO SINGLE ELEMENT DELETE IN VARRAY */
    l_list(i * i_step) := null;
    $END
  end loop;
  print_plsql_used_session_mem('1 element left');

  -- ADD ANOTHER c_element_cnt ELEMENTS --
  $IF $$COLL_TYPE = 2 OR $$COLL_TYPE = 3 $THEN /* NESTED TABLE, VARRAY */
  l_list.extend(i_elem_cnt * i_step);
  $END
  for i in (i_elem_cnt + 1)..(2 * i_elem_cnt) loop
    l_list(i * i_step) := l_str;
  end loop;
  print_plsql_used_session_mem('Allocated on top');

  -- DELETE ALL --
  l_list.delete;
  print_plsql_used_session_mem('All deleted');  
end coll_mem_usage;
/


-----------------------------------------------------------------------------
-- RUN TESTS
-----------------------------------------------------------------------------
set serveroutput on
set timing on
alter procedure coll_mem_usage compile plsql_ccflags='string_len:10,coll_type:0';
exec coll_mem_usage
exec coll_mem_usage(10)
exec coll_mem_usage(20)
exec coll_mem_usage(30)

alter procedure coll_mem_usage compile plsql_ccflags='string_len:100,coll_type:0';
exec coll_mem_usage

alter procedure coll_mem_usage compile plsql_ccflags='string_len:10,coll_type:1';
exec coll_mem_usage
exec coll_mem_usage(10)

alter procedure coll_mem_usage compile plsql_ccflags='string_len:100,coll_type:1';
exec coll_mem_usage

alter procedure coll_mem_usage compile plsql_ccflags='string_len:10,coll_type:2';
exec coll_mem_usage

alter procedure coll_mem_usage compile plsql_ccflags='string_len:10,coll_type:3';
exec coll_mem_usage