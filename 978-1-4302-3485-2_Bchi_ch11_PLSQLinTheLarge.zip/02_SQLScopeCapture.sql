-----------------------------------------------------------------------------
--  Expert PL/SQL Practices, published by Apress, ISBN 978-1-4302-3485-2   --
--  Demo code for chapter 11, PL/SQL Programming in the Large              --
--  Not meant for production use.                                          --
--  Author: Martin B�chi                                                   --
-----------------------------------------------------------------------------


-----------------------------------------------------------------------------
-- CLEANUP FROM PREVIOUS RUN
-----------------------------------------------------------------------------
declare
  l_cnt                      pls_integer;
begin
  select count(*)
  into   l_cnt
  from   user_tables
  where  table_name = 'EMP';
  if l_cnt = 1 then
    execute immediate 'drop table emp';
  end if;
end;
/


-----------------------------------------------------------------------------
-- CREATE SIMPLIFIED EMP TABLE
-----------------------------------------------------------------------------
create table emp(empno number(9), ename varchar2(30));


-----------------------------------------------------------------------------
-- CREATE ERRONEOUS TEST FUNCTION WITH SCOPE CAPTURE
-----------------------------------------------------------------------------
create or replace function emp#ename(empno emp.empno%type)
return emp.ename%type
is
  ename                      emp.ename%type;
begin
  select ename
  into   ename
  from   emp
  where  empno = empno;

  return ename;
end emp#ename;
/


-----------------------------------------------------------------------------
-- TEST AND SHOW THAT FUNCTION IS NOT CORRECT
-----------------------------------------------------------------------------
insert into emp(empno, ename) values (7369, 'SMITH');
select emp#ename(21) from dual;
insert into emp(empno, ename) values (7499, 'ALLEN');
select emp#ename(7369) from dual;