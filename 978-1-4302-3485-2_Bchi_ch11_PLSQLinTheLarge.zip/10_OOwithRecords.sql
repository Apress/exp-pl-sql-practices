-----------------------------------------------------------------------------
--  Expert PL/SQL Practices, published by Apress, ISBN 978-1-4302-3485-2   --
--  Demo code for chapter 11, PL/SQL Programming in the Large              --
--  Not meant for production use.                                          --
--  Author: Martin B�chi                                                   --
-----------------------------------------------------------------------------


-----------------------------------------------------------------------------
-- CLEANUP FROM PREVIOUS RUN
-----------------------------------------------------------------------------
declare
  procedure drop_table(
    i_table_name              varchar2
  )
  is
    l_cnt                      pls_integer;
  begin
    select count(*)
    into   l_cnt
    from   user_tables
    where  table_name = i_table_name;
    if l_cnt = 1 then
      execute immediate 'drop table ' || i_table_name;
    end if;
  end drop_table;
begin
  drop_table('BANK_TRX_DSP');
  drop_table('PAY_TRX');
  drop_table('BANK_TRX');
end;
/


-----------------------------------------------------------------------------
-- CREATE PACKAGES
-----------------------------------------------------------------------------
create or replace package bank_trx#
is
  ------------------------------------------------------------------------------
  -- Type for references to t_bank_trx and subtypes thereof.
  ------------------------------------------------------------------------------
  subtype t_bank_trx      is pls_integer;

  ------------------------------------------------------------------------------
  -- Type for subtypes of t_bank_trx.
  ------------------------------------------------------------------------------
  subtype t_bank_trx_type is pls_integer;

  ------------------------------------------------------------------------------
  -- Creates a banking transaction.
  ------------------------------------------------------------------------------
  function bank_trx#new(
    i_bank_trx_type_id       t_bank_trx_type
   ,i_amount                 number
  ) return t_bank_trx;
  
  ------------------------------------------------------------------------------
  -- Removes (deletes) the banking transaction.
  ------------------------------------------------------------------------------
  procedure bank_trx#remv(
    i_bank_trx               t_bank_trx
  );

  ------------------------------------------------------------------------------
  -- Returns the amount of the transaction.
  ------------------------------------------------------------------------------
  function bank_trx#amount(
    i_bank_trx               t_bank_trx
  ) return number;
    
  ------------------------------------------------------------------------------
  -- Books the transaction.
  ------------------------------------------------------------------------------
  procedure bank_trx#book(
    i_bank_trx               t_bank_trx
   ,i_text                   varchar2
  );
end bank_trx#;
/

create or replace package bank_trx_type#
is
  -- PACKAGE GENERATED FROM LIST OF SUBTYPES OF BANKING TRX. HAS NO BODY. --
  c_pay_trx        constant bank_trx#.t_bank_trx_type := 1;
end bank_trx_type#;
/

create or replace package pay_trx#
is
  function pay_trx#new(
    i_amount                 number
  ) return bank_trx#.t_bank_trx;
  
  ------------------------------------------------------------------------------
  -- Override
  ------------------------------------------------------------------------------
  procedure bank_trx#book(
    i_bank_trx               bank_trx#.t_bank_trx
   ,i_text                   varchar2
  );
end pay_trx#;
/

create or replace package body pay_trx#
is
  function pay_trx#new(
    i_amount                 number
  ) return bank_trx#.t_bank_trx
  is
  begin
    if nvl(i_amount, -1) < 0 then
      raise_application_error(-20000, 'Negative amount');
    end if;
    return bank_trx#.bank_trx#new(
      i_bank_trx_type_id => bank_trx_type#.c_pay_trx
     ,i_amount           => i_amount
    );
  end pay_trx#new;

  ------------------------------------------------------------------------------
  procedure bank_trx#book(
    i_bank_trx           bank_trx#.t_bank_trx
   ,i_text                   varchar2
  )
  is
  begin
    dbms_output.put_line('Booking t_pay_trx "' || i_text || '" with amount '
                          || bank_trx#.bank_trx#amount(i_bank_trx));
  end bank_trx#book;
end pay_trx#;
/


-----------------------------------------------------------------------------
-- DYNAMIC DISPATCH WITH DYNAMIC SQL
-----------------------------------------------------------------------------
create table bank_trx_dsp(
  method_name                varchar2(30)
 ,bank_trx_type_id           number(9)
 ,stmt                       varchar2(200)
 ,primary key(method_name, bank_trx_type_id)
) organization index;
begin
  insert into bank_trx_dsp(
    method_name
   ,bank_trx_type_id
   ,stmt
  ) values (
    'bank_trx#book'
   ,bank_trx_type#.c_pay_trx
   ,'begin pay_trx#.bank_trx#book(i_bank_trx => :1, i_text => :2); end;'
  );
  commit;
end;
/

create or replace package body bank_trx#
is
  type t_bank_trx_rec is record (
    bank_trx_type_id         t_bank_trx_type
   ,id                       integer
   ,amount                   number
  );
  type t_bank_trx_tab is table of t_bank_trx_rec index by t_bank_trx;
  b_bank_trx_list            t_bank_trx_tab;
  
  ------------------------------------------------------------------------------
  function bank_trx#new(
    i_bank_trx_type_id       t_bank_trx_type
   ,i_amount                 number
  ) return t_bank_trx
  is
    l_bank_trx               t_bank_trx;
  begin
    l_bank_trx := nvl(b_bank_trx_list.last, 0) + 1;
    b_bank_trx_list(l_bank_trx).bank_trx_type_id := i_bank_trx_type_id;
    b_bank_trx_list(l_bank_trx).amount := i_amount;
    return l_bank_trx;
  end bank_trx#new;
  
  ------------------------------------------------------------------------------
  procedure bank_trx#remv(
    i_bank_trx               t_bank_trx
  )
  is
  begin
    b_bank_trx_list.delete(i_bank_trx);
  end bank_trx#remv;

  ------------------------------------------------------------------------------
  function bank_trx#amount(
    i_bank_trx               t_bank_trx
  ) return number
  is
  begin
    return b_bank_trx_list(i_bank_trx).amount;
  end bank_trx#amount;

  ------------------------------------------------------------------------------
  procedure bank_trx#book(
    i_bank_trx               t_bank_trx
   ,i_text                   varchar2
  )
  is
    l_stmt                   bank_trx_dsp.stmt%type;
  begin
    select stmt
    into   l_stmt
    from   bank_trx_dsp
    where  method_name      = 'bank_trx#book'
       and bank_trx_type_id = b_bank_trx_list(i_bank_trx).bank_trx_type_id;
    execute immediate l_stmt
    using i_bank_trx, i_text;
  end bank_trx#book;
end bank_trx#;
/

declare
  l_my_payment               bank_trx#.t_bank_trx;
begin
  l_my_payment := pay_trx#.pay_trx#new(100);
  bank_trx#.bank_trx#book(l_my_payment, 'payroll');
end;
/


-----------------------------------------------------------------------------
-- DYNAMIC DISPATCH WITH GENERATED DISPATCHER
-----------------------------------------------------------------------------
create or replace package bank_trx_dsp#
is
  -- PACKAGE FOR DYNAMIC DISPATCH. HEADER CODED MANUALLY. BODY GENERATED.
  -- SEE BANK_TRX# FOR DESCRIPTION OF ROUTINES.
  procedure bank_trx#book(
    i_bank_trx               bank_trx#.t_bank_trx
   ,i_bank_trx_type_id       bank_trx#.t_bank_trx_type
   ,i_text                   varchar2
  );
end bank_trx_dsp#;
/

create or replace package body bank_trx#
is
  type t_bank_trx_rec is record (
    bank_trx_type_id         t_bank_trx_type
   ,id                       integer
   ,amount                   number
  );
  type t_bank_trx_tab is table of t_bank_trx_rec index by t_bank_trx;
  b_bank_trx_list            t_bank_trx_tab;
  
  ------------------------------------------------------------------------------
  function bank_trx#new(
    i_bank_trx_type_id       t_bank_trx_type
   ,i_amount                 number
  ) return t_bank_trx
  is
    l_bank_trx               t_bank_trx;
  begin
    l_bank_trx := nvl(b_bank_trx_list.last, 0) + 1;
    b_bank_trx_list(l_bank_trx).bank_trx_type_id := i_bank_trx_type_id;
    b_bank_trx_list(l_bank_trx).amount := i_amount;
    return l_bank_trx;
  end bank_trx#new;
  
  ------------------------------------------------------------------------------
  procedure bank_trx#remv(
    i_bank_trx               t_bank_trx
  )
  is
  begin
    b_bank_trx_list.delete(i_bank_trx);
  end bank_trx#remv;

  ------------------------------------------------------------------------------
  function bank_trx#amount(
    i_bank_trx               t_bank_trx
  ) return number
  is
  begin
    return b_bank_trx_list(i_bank_trx).amount;
  end bank_trx#amount;

  ------------------------------------------------------------------------------
  procedure bank_trx#book(
    i_bank_trx               t_bank_trx
   ,i_text                   varchar2
  )
  is
  begin
    bank_trx_dsp#.bank_trx#book(
      i_bank_trx         => i_bank_trx
     ,i_bank_trx_type_id => b_bank_trx_list(i_bank_trx).bank_trx_type_id
     ,i_text             => i_text
    );
  end bank_trx#book;
end bank_trx#;
/

create or replace package body bank_trx_dsp#
is
  -- GENERATED PACKAGE BODY --
  procedure bank_trx#book(
    i_bank_trx               bank_trx#.t_bank_trx
   ,i_bank_trx_type_id       bank_trx#.t_bank_trx_type
   ,i_text                   varchar2
  )
  is
  begin
    if i_bank_trx_type_id = bank_trx_type#.c_pay_trx then
      pay_trx#.bank_trx#book(
        i_bank_trx => i_bank_trx
       ,i_text         => i_text
      );
    else
      raise_application_error(-20000, 'Unknown bank_trx_type_id: ' || i_bank_trx_type_id);
    end if;
  end bank_trx#book;
end bank_trx_dsp#;
/

declare
  l_my_payment               bank_trx#.t_bank_trx;
begin
  l_my_payment := pay_trx#.pay_trx#new(100);
  bank_trx#.bank_trx#book(l_my_payment, 'payroll');
end;
/


-----------------------------------------------------------------------------
-- SUBTYPE WITH ADDITIONAL ATTRIBUTES
-----------------------------------------------------------------------------
create or replace package pay_trx#
is
  subtype t_settle_type is pls_integer;

  function pay_trx#new(
    i_amount                 number
   ,i_settle_type_id         t_settle_type
  ) return bank_trx#.t_bank_trx;
  
  ------------------------------------------------------------------------------
  -- Override
  ------------------------------------------------------------------------------
  procedure bank_trx#book(
    i_bank_trx           bank_trx#.t_bank_trx
   ,i_text                   varchar2
  );
end pay_trx#;
/

create or replace package body pay_trx#
is
  type t_pay_trx_rec is record (
    settle_type_id          t_settle_type
  );
  type t_pay_trx_tab is table of t_pay_trx_rec index by bank_trx#.t_bank_trx;
  b_pay_trx_list            t_pay_trx_tab;

  function pay_trx#new(
    i_amount                 number
   ,i_settle_type_id         t_settle_type
  ) return bank_trx#.t_bank_trx
  is
    l_idx                    bank_trx#.t_bank_trx;
  begin
    if nvl(i_amount, -1) < 0 then
      raise_application_error(-20000, 'Negative amount');
    end if;
    l_idx := bank_trx#.bank_trx#new(
      i_bank_trx_type_id => bank_trx_type#.c_pay_trx
     ,i_amount           => i_amount
    );
    b_pay_trx_list(l_idx).settle_type_id := i_settle_type_id;
    return l_idx;
  end pay_trx#new;

  ------------------------------------------------------------------------------
  procedure bank_trx#book(
    i_bank_trx           bank_trx#.t_bank_trx
   ,i_text                   varchar2
  )
  is
  begin
    dbms_output.put_line('Booking t_pay_trx "' || i_text || '" with amount '
                          || bank_trx#.bank_trx#amount(i_bank_trx));
  end bank_trx#book;
end pay_trx#;
/


-----------------------------------------------------------------------------
-- PERSISTENCE OF TRANSACTIONS
-----------------------------------------------------------------------------
create table bank_trx(
  id                          integer
 ,bank_trx_type_id            integer
 ,amount                      number
 ,constraint bank_trx#p primary key(id)
);

create table pay_trx(
  bank_trx_id                integer
 ,settle_type_id             integer
 ,constraint pay_trx#p primary key(bank_trx_id)
 ,constraint pay_trx#f#1 foreign key(bank_trx_id) references bank_trx(id)
);
