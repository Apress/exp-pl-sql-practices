-----------------------------------------------------------------------------
--  Expert PL/SQL Practices, published by Apress, ISBN 978-1-4302-3485-2   --
--  Demo code for chapter 11, PL/SQL Programming in the Large              --
--  Not meant for production use.                                          --
--  Author: Martin B�chi                                                   --
-----------------------------------------------------------------------------


-----------------------------------------------------------------------------
-- CLEANUP FROM PREVIOUS RUN
-----------------------------------------------------------------------------
declare
  procedure drop_user(
    i_username               varchar2
  )
  is
    l_cnt                    pls_integer;
  begin
    select count(*)
    into   l_cnt
    from   dba_users
    where  username = i_username;
    if l_cnt = 1 then
      execute immediate 'drop user ' || i_username || ' cascade';
    end if;
  end drop_user;
begin
  drop_user('DATA_ACCESS');
  drop_user('BUSINESS_LOGIC');
  drop_user('PRESENTATION');
end;
/


-----------------------------------------------------------------------------
-- CREATE USERS
-----------------------------------------------------------------------------
create user data_access identified by pwd account lock;
create user business_logic identified by pwd account lock;
create user presentation identified by pwd account lock;


-----------------------------------------------------------------------------
-- CREATE TABLE
-----------------------------------------------------------------------------
create table data_access.t(x number);


-----------------------------------------------------------------------------
-- CREATE PROCEDURE ACCESSING TABLE
-----------------------------------------------------------------------------
create or replace procedure data_access.d(
  i_x                        number
)
is
begin
  insert into t(x) values (abs(i_x));
end d;
/


-----------------------------------------------------------------------------
-- PROCEDURE IN OTHER SCHEMA CANNOT ACCESS WITHOUT OBJECT PRIVILEGE (GRANT)
-----------------------------------------------------------------------------
create or replace procedure business_logic.b(
  i_x                        number
)
is
begin
  data_access.d(trunc(i_x));
end b;
/
show error


-----------------------------------------------------------------------------
-- AFTER GRANTING OBJECT PRIVILEGE EVERYTHING WORKS
-----------------------------------------------------------------------------
grant execute on data_access.d to business_logic;
alter procedure data_access.d compile;

