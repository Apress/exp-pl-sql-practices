-- -----------------------------------------------------------------
--
-- Title:      Expert PL/SQL Practices (Apress)
-- ISBN:       978-1-4302-3485-2
-- Chapter:    9. PL/SQL from SQL
-- Author:     Adrian Billington
--             http://www.oracle-developer.net
--
-- Listing(s): 9-20
--
-- Notes:      1. Run in the supplied SH sample schema.
--
--             2. Called using run_listing.sql as follows:
--                SQL> @run_listing.sql 9_20
--             
-- -----------------------------------------------------------------

-- 9-20...
-- -----------------------------------------------------------------
CREATE FUNCTION get_customer_name (
                p_cust_id IN customers.cust_id%TYPE
                ) RETURN VARCHAR2 AS
   v_customer_name VARCHAR2(200);
BEGIN
   SELECT cust_first_name || ' ' || cust_last_name
   INTO   v_customer_name
   FROM   customers
   WHERE  cust_id = p_cust_id;
   RETURN v_customer_name;
END get_customer_name;
/

CREATE FUNCTION sleeper(
                p_secs IN NUMBER
                ) RETURN NUMBER IS
BEGIN
   DBMS_LOCK.SLEEP(p_secs);
   RETURN p_secs;
END sleeper;
/
