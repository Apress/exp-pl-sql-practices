-- -----------------------------------------------------------------
--
-- Title:      Expert PL/SQL Practices (Apress)
-- ISBN:       978-1-4302-3485-2
-- Chapter:    9. PL/SQL from SQL
-- Author:     Adrian Billington
--             http://www.oracle-developer.net
--
-- Listing(s): 9-22
--
-- Notes:      1. Run in the supplied SH sample schema.
--
--             2. Called using run_listing.sql as follows:
--                SQL> @run_listing.sql 9_22
--             
-- -----------------------------------------------------------------

-- 9-22...
-- -----------------------------------------------------------------
set time on

UPDATE customers
SET    cust_last_name = 'Smith'
WHERE  cust_id = 2;

COMMIT;
