exec dbms_result_cache.bypass(&1);
