-- -----------------------------------------------------------------
--
-- Title:      Expert PL/SQL Practices (Apress)
-- ISBN:       978-1-4302-3485-2
-- Chapter:    9. PL/SQL from SQL
-- Author:     Adrian Billington
--             http://www.oracle-developer.net
--
-- Listing(s): 9-17, 9-18
--
-- Notes:      1. Run in the supplied SH sample schema.
--
--             2. Called using run_listing.sql as follows:
--                SQL> @run_listing.sql 9_17_18
--             
-- -----------------------------------------------------------------

-- 9-17, 9-18...
-- -----------------------------------------------------------------
CREATE TABLE thousand_rows
AS
   SELECT ROWNUM           AS n1
   ,      RPAD('x',50,'x') AS v1
   FROM   dual
   CONNECT BY ROWNUM <= 1e3;

BEGIN
   DBMS_STATS.GATHER_TABLE_STATS(user, 'THOUSAND_ROWS');
END;
/

CREATE OR REPLACE FUNCTION plsql_function (
                           p_id IN INTEGER
                           ) RETURN INTEGER AS
BEGIN
   RETURN 0;
END plsql_function;
/

@cbo_trace_on "&__script"
@autoexp

SELECT *
FROM   thousand_rows
WHERE  plsql_function(n1) = 0;

@cbo_trace_off
@autooff
