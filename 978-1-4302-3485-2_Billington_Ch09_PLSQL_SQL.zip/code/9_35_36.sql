-- -----------------------------------------------------------------
--
-- Title:      Expert PL/SQL Practices (Apress)
-- ISBN:       978-1-4302-3485-2
-- Chapter:    9. PL/SQL from SQL
-- Author:     Adrian Billington
--             http://www.oracle-developer.net
--
-- Listing(s): 9-35, 9-36
--
-- Notes:      1. Run in the supplied SH sample schema.
--
--             2. Called using run_listing.sql as follows:
--                SQL> @run_listing.sql 9_35_36
--             
-- -----------------------------------------------------------------

-- 9-35...
-- -----------------------------------------------------------------
CREATE OR REPLACE FUNCTION format_customer_name (
                           p_first_name IN VARCHAR2,
                           p_last_name  IN VARCHAR2
                           ) RETURN VARCHAR2 AS
BEGIN
   counter.increment;
   RETURN p_first_name || ' ' || p_last_name;
END format_customer_name;
/

@autostat

SELECT /*+ NO_MERGE(@customers) */
       t.calendar_year
,      c.cust_name
,      SUM(s.quantity_sold) AS qty_sold
,      SUM(s.amount_sold)   AS amt_sold
FROM   sales     s
,     (
       SELECT /*+ QB_NAME(customers) */
              cust_id
       ,      format_customer_name (
                 cust_first_name, cust_last_name
                 ) AS cust_name
       FROM   customers
      )          c
,      times     t
WHERE  s.cust_id = c.cust_id
AND    s.time_id = t.time_id
GROUP  BY
       t.calendar_year
,      c.cust_name
;

exec counter.show('Function calls');

@autooff


-- 9-36...
-- -----------------------------------------------------------------
@autostat

SELECT /*+ NO_MERGE(@pregroup) */
       calendar_year
,      format_customer_name(
          cust_first_name, cust_last_name
          ) AS cust_name
,      qty_sold
,      amt_sold
FROM  (
         SELECT /*+ QB_NAME(pregroup) */
                t.calendar_year
         ,      c.cust_first_name
         ,      c.cust_last_name
         ,      SUM(s.quantity_sold) AS qty_sold
         ,      SUM(s.amount_sold)   AS amt_sold
         FROM   sales     s
         ,      customers c
         ,      times     t
         WHERE  s.cust_id = c.cust_id
         AND    s.time_id = t.time_id
         GROUP  BY
                t.calendar_year
         ,      c.cust_first_name
         ,      c.cust_last_name
      )
;

@autooff

exec counter.show('Function calls');
