-- -----------------------------------------------------------------
--
-- Title:      Expert PL/SQL Practices (Apress)
-- ISBN:       978-1-4302-3485-2
-- Chapter:    9. PL/SQL from SQL
-- Author:     Adrian Billington
--             http://www.oracle-developer.net
--
-- Listing(s): 9-11, 9-12, 9-13, 9-14, 9-15, 9-16
--
-- Notes:      1. Run in the supplied SH sample schema.
--
--             2. Called using run_listing.sql as follows:
--                SQL> @run_listing.sql 9_11_16
--             
-- -----------------------------------------------------------------

-- 9-11...
-- -----------------------------------------------------------------
CREATE TABLE rates
( base_ccy      VARCHAR2(3)
, target_ccy    VARCHAR2(3)
, rate_date     DATE
, exchange_rate NUMBER
, CONSTRAINT rates_pk
   PRIMARY KEY(base_ccy, target_ccy, rate_date)
)
ORGANIZATION INDEX
;

INSERT INTO rates
SELECT 'USD'
,      'GBP'
,      time_id
,      DBMS_RANDOM.VALUE(0.6, 0.7)
FROM  (
       SELECT DISTINCT time_id
       FROM   sales
      );

EXEC DBMS_STATS.GATHER_TABLE_STATS(user, 'RATES');

CREATE FUNCTION get_rate(
                p_rate_date IN rates.rate_date%TYPE,
                p_from_ccy  IN rates.base_ccy%TYPE,
                p_to_ccy    IN rates.target_ccy%TYPE
                ) RETURN rates.exchange_rate%TYPE AS
   v_rate rates.exchange_rate%TYPE;
BEGIN
   SELECT exchange_rate INTO v_rate
   FROM   rates
   WHERE  base_ccy   = p_from_ccy
   AND    target_ccy = p_to_ccy
   AND    rate_date  = p_rate_date;
   RETURN v_rate;
END get_rate;
/


-- 9-12, 9-13...
-- -----------------------------------------------------------------
@autostat

SELECT t.calendar_year
,      p.prod_name
,      SUM(s.amount_sold)                                     AS amt_sold_usd
,      SUM(s.amount_sold * get_rate(s.time_id, 'USD', 'GBP')) AS amt_sold_gbp
FROM   sales     s
,      products  p
,      times     t
WHERE  s.prod_id = p.prod_id
AND    s.time_id = t.time_id
GROUP  BY
       t.calendar_year
,      p.prod_name
;

@autooff


-- 9-14, 9-15...
-- -----------------------------------------------------------------
@autostat

SELECT t.calendar_year
,      p.prod_name
,      SUM(s.amount_sold)                 AS amt_sold_usd
,      SUM(s.amount_sold*r.exchange_rate) AS amt_sold_gbp
FROM   sales     s
,      times     t
,      products  p
,      rates     r
WHERE  s.time_id        = t.time_id
AND    s.prod_id        = p.prod_id
AND    r.rate_date  (+) = s.time_id
AND    r.base_ccy   (+) = 'USD'
AND    r.target_ccy (+) = 'GBP'
GROUP  BY
       t.calendar_year
,      p.prod_name
;

@autooff


-- 9-16...
-- -----------------------------------------------------------------
@autostat
@trace_on "&__script"

SELECT t.calendar_year
,      p.prod_name
,      SUM(s.amount_sold)                                     AS amt_sold_usd
,      SUM(s.amount_sold * get_rate(s.time_id, 'USD', 'GBP')) AS amt_sold_gbp
FROM   sales     s
,      products  p
,      times     t
WHERE  s.prod_id = p.prod_id
AND    s.time_id = t.time_id
GROUP  BY
       t.calendar_year
,      p.prod_name
;

@trace_off

@hprof_on "&__script"

SELECT t.calendar_year
,      p.prod_name
,      SUM(s.amount_sold)                                     AS amt_sold_usd
,      SUM(s.amount_sold * get_rate(s.time_id, 'USD', 'GBP')) AS amt_sold_gbp
FROM   sales     s
,      products  p
,      times     t
WHERE  s.prod_id = p.prod_id
AND    s.time_id = t.time_id
GROUP  BY
       t.calendar_year
,      p.prod_name
;

@autooff
@hprof_off "&__script"
