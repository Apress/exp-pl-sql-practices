-- -----------------------------------------------------------------
--
-- Title:      Expert PL/SQL Practices (Apress)
-- ISBN:       978-1-4302-3485-2
-- Chapter:    9. PL/SQL from SQL
-- Author:     Adrian Billington
--             http://www.oracle-developer.net
--
-- Listing(s): 9-46, 9-47, 9-48
--
-- Notes:      1. Run in the supplied SH sample schema.
--
--             2. Called using run_listing.sql as follows:
--                SQL> @run_listing.sql 9_46_48
--             
-- -----------------------------------------------------------------

-- 9-46...
-- -----------------------------------------------------------------
@autoon

SELECT t.calendar_year
,      format_customer_name(
          c.cust_first_name, c.cust_last_name
          )                 AS cust_name
,      SUM(s.quantity_sold) AS qty_sold
,      SUM(s.amount_sold)   AS amt_sold
FROM   sales     s
,      customers c
,      times     t
WHERE  s.cust_id = c.cust_id
AND    s.time_id = t.time_id
GROUP  BY
       t.calendar_year
,      format_customer_name(
          c.cust_first_name, c.cust_last_name
          );

@show "Function calls"

@autooff


-- 9-47...
-- -----------------------------------------------------------------
BEGIN
   DBMS_STATS.GATHER_TABLE_STATS(
      ownname    => USER,
      tabname    => 'CUSTOMERS',
      method_opt => 'FOR COLUMNS (format_customer_name(cust_first_name,cust_last_name)) SIZE AUTO'
      );
END;
/

@autoon

SELECT t.calendar_year
,      format_customer_name(
          c.cust_first_name, c.cust_last_name
          )                 AS cust_name
,      SUM(s.quantity_sold) AS qty_sold
,      SUM(s.amount_sold)   AS amt_sold
FROM   sales     s
,      customers c
,      times     t
WHERE  s.cust_id = c.cust_id
AND    s.time_id = t.time_id
GROUP  BY
       t.calendar_year
,      format_customer_name(
          c.cust_first_name, c.cust_last_name
          )    
;

@show "Extended stats"
@autooff


-- 9-48...
-- -----------------------------------------------------------------
@autoon

SELECT t.calendar_year
,      c.cust_name
,      SUM(s.quantity_sold) AS qty_sold
,      SUM(s.amount_sold)   AS amt_sold
FROM   sales     s
,     (
       SELECT cust_id
       ,      format_customer_name (
                 cust_first_name, cust_last_name
                 ) AS cust_name
       FROM   customers
      )          c
,      times     t
WHERE  s.cust_id = c.cust_id
AND    s.time_id = t.time_id
GROUP  BY
       t.calendar_year
,      c.cust_name
;

@show "Extended stats + inline view"
@autooff
