-- -----------------------------------------------------------------
--
-- Title:      Expert PL/SQL Practices (Apress)
-- ISBN:       978-1-4302-3485-2
-- Chapter:    9. PL/SQL from SQL
-- Author:     Adrian Billington
--             http://www.oracle-developer.net
--
-- Listing(s): 9-49, 9-50, 9-51
--
-- Notes:      1. Run in the supplied SH sample schema.
--
--             2. Called using run_listing.sql as follows:
--                SQL> @run_listing.sql 9_49_51
--             
-- -----------------------------------------------------------------

-- 9-49...
-- -----------------------------------------------------------------
ASSOCIATE STATISTICS WITH FUNCTIONS quick_function DEFAULT SELECTIVITY 0.1;

ASSOCIATE STATISTICS WITH FUNCTIONS slow_function DEFAULT SELECTIVITY 50;

@autoon

SELECT *
FROM   thousand_rows
WHERE  slow_function(n1) = 0
AND    quick_function(n1) = 0;

@autooff


-- 9-50...
-- -----------------------------------------------------------------
@flush "thousand_rows"
@cbo_trace_on "&__script"

SELECT *
FROM   thousand_rows
WHERE  slow_function(n1) = 0
AND    quick_function(n1) = 0;

@cbo_trace_off


-- 9-51...
-- -----------------------------------------------------------------
@rcbypass true
@hprof_on "&__script"
@autostat
SELECT get_rate(DATE '2001-12-18', 'USD', 'GBP') FROM dual;
@autooff
@hprof_off "&__script"
@rcbypass false

ASSOCIATE STATISTICS WITH FUNCTIONS get_rate DEFAULT COST (403416, 2, 0);

DISASSOCIATE STATISTICS FROM FUNCTIONS get_rate;
