-- -----------------------------------------------------------------
--
-- Title:      Expert PL/SQL Practices (Apress)
-- ISBN:       978-1-4302-3485-2
-- Chapter:    9. PL/SQL from SQL
-- Author:     Adrian Billington
--             http://www.oracle-developer.net
--
-- Listing(s): 9-7
--
-- Notes:      1. Run in the supplied SH sample schema.
--
--             2. Called using run_listing.sql as follows:
--                SQL> @run_listing.sql 9_07
--             
-- -----------------------------------------------------------------

-- Create required utility...
-- -----------------------------------------------------------------
@stragg


-- 9-7...
-- -----------------------------------------------------------------
@autostat

SELECT cust_first_name
,      cust_last_name
,      LISTAGG(cust_id) WITHIN GROUP (ORDER BY NULL)
FROM   customers
GROUP  BY
       cust_first_name
,      cust_last_name;

SELECT cust_first_name
,      cust_last_name
,      STRAGG(cust_id)
FROM   customers
GROUP  BY
       cust_first_name
,      cust_last_name;
       
@autooff
