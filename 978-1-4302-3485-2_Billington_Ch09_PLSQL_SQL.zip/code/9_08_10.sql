-- -----------------------------------------------------------------
--
-- Title:      Expert PL/SQL Practices (Apress)
-- ISBN:       978-1-4302-3485-2
-- Chapter:    9. PL/SQL from SQL
-- Author:     Adrian Billington
--             http://www.oracle-developer.net
--
-- Listing(s): 9-8, 9-9, 9-10
--
-- Notes:      1. Run in the supplied SH sample schema.
--
--             2. Called using run_listing.sql as follows:
--                SQL> @run_listing.sql 9_08_10
--             
-- -----------------------------------------------------------------

-- Create required utilities...
-- -----------------------------------------------------------------
@counter


-- 9-8...
-- -----------------------------------------------------------------
CREATE OR REPLACE FUNCTION format_customer_name (
                           p_first_name IN VARCHAR2,
                           p_last_name  IN VARCHAR2
                           ) RETURN VARCHAR2 AS
BEGIN
   counter.increment;
   RETURN p_first_name || ' ' || p_last_name;
END format_customer_name;
/

@autostat

SELECT t.calendar_year
,      c.cust_name
,      SUM(s.quantity_sold) AS qty_sold
,      SUM(s.amount_sold)   AS amt_sold
FROM   sales     s
,     (
       SELECT cust_id
       ,      format_customer_name (
                 cust_first_name, cust_last_name
                 ) AS cust_name
       FROM   customers
      )          c
,      times     t
WHERE  s.cust_id = c.cust_id
AND    s.time_id = t.time_id
GROUP  BY
       t.calendar_year
,      c.cust_name
;

@autooff


-- 9-9...
-- -----------------------------------------------------------------
exec counter.show('Function calls');
       

-- 9-10...
-- -----------------------------------------------------------------
EXPLAIN PLAN SET STATEMENT_ID = '&__script'
FOR
SELECT t.calendar_year
,      c.cust_name
,      SUM(s.quantity_sold) AS qty_sold
,      SUM(s.amount_sold)   AS amt_sold
FROM   sales     s
,     (
       SELECT cust_id
       ,      format_customer_name (
                 cust_first_name, cust_last_name
                 ) AS cust_name
       FROM   customers
      )          c
,      times     t
WHERE  s.cust_id = c.cust_id
AND    s.time_id = t.time_id
GROUP  BY
       t.calendar_year
,      c.cust_name
;

@xplan "&__script" "basic +projection"
