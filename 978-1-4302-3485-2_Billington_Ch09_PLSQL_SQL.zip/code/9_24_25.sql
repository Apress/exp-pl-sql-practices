-- -----------------------------------------------------------------
--
-- Title:      Expert PL/SQL Practices (Apress)
-- ISBN:       978-1-4302-3485-2
-- Chapter:    9. PL/SQL from SQL
-- Author:     Adrian Billington
--             http://www.oracle-developer.net
--
-- Listing(s): 9-24, 9-25
--
-- Notes:      1. Run in the supplied SH sample schema.
--
--             2. Called using run_listing.sql as follows:
--                SQL> @run_listing.sql 9_24_25
--
--             3. Uses an Oracle directory (set the name of this in
--                the run_listings.sql script).
--             
-- -----------------------------------------------------------------

-- Required utilities...
-- -----------------------------------------------------------------
@data_dump


-- 9-24...
-- -----------------------------------------------------------------
BEGIN
   data_dump( query_in => 'select prod_id
                           ,      cust_id
                           ,      time_id
                           ,      channel_id
                           ,      promo_id
                           ,      quantity_sold
                           ,      case mod(rownum,10000)
                                     when 0 
                                     then amount_sold || chr(65) 
                                     else to_char(amount_sold)
                                  end as amount_sold 
                           from   sales'
            , file_in => 'sales.csv'
            , directory_in => '&__ora_dir'
            , dump_code_in => true
            );
END;
/

CREATE TABLE external_table
( field_01  VARCHAR2(30)
, field_02  VARCHAR2(30)
, field_03  VARCHAR2(30)
, field_04  VARCHAR2(30)
, field_05  VARCHAR2(30)
, field_06  VARCHAR2(30)
, field_07  VARCHAR2(30)
)
ORGANIZATION EXTERNAL
(
   TYPE ORACLE_LOADER
   DEFAULT DIRECTORY &__ora_dir
   ACCESS PARAMETERS
   (
      RECORDS DELIMITED BY NEWLINE
      NOLOGFILE
      NOBADFILE
      NODISCARDFILE
      FIELDS TERMINATED BY ','
   )
   LOCATION ('sales.csv')
)
REJECT LIMIT 0
;

CREATE FUNCTION is_number (
                p_str IN VARCHAR2
                ) RETURN NUMBER IS
   n NUMBER;
BEGIN
   n := TO_NUMBER(p_str);
   RETURN 1;
EXCEPTION
   WHEN VALUE_ERROR THEN
      RETURN 0;
END;
/


-- 9-25...
-- -----------------------------------------------------------------
@autostat

SELECT *
FROM   external_table
WHERE  is_number(field_07) = 1;

SELECT *
FROM   external_table
WHERE  REGEXP_LIKE(
          field_07,
          '^( *)(\+|-)?((\d*[.]?\d+)|(d+[.]?\d*)){1}(e(\+|-)?\d+)?(f|d)?$',
          'i');

SELECT *
FROM   external_table
WHERE  is_number(field_07) = 0;

SELECT *
FROM   external_table
WHERE  NOT REGEXP_LIKE(
              field_07,
              '^( *)(\+|-)?((\d*[.]?\d+)|(d+[.]?\d*)){1}(e(\+|-)?\d+)?(f|d)?$',
              'i'); 

@autooff
