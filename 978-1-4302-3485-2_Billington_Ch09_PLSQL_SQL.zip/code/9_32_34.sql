-- -----------------------------------------------------------------
--
-- Title:      Expert PL/SQL Practices (Apress)
-- ISBN:       978-1-4302-3485-2
-- Chapter:    9. PL/SQL from SQL
-- Author:     Adrian Billington
--             http://www.oracle-developer.net
--
-- Listing(s): 9-32, 9-33, 9-34
--
-- Notes:      1. Run in the supplied SH sample schema.
--
--             2. Called using run_listing.sql as follows:
--                SQL> @run_listing.sql 9_32_34
--             
-- -----------------------------------------------------------------


-- 9-32...
-- -----------------------------------------------------------------
CREATE OR REPLACE FUNCTION format_customer_name (
                           p_first_name IN VARCHAR2,
                           p_last_name  IN VARCHAR2
                           ) RETURN VARCHAR2 DETERMINISTIC AS
BEGIN
   RETURN p_first_name || ' ' || p_last_name;
END format_customer_name;
/

ALTER TABLE customers ADD 
( cust_name VARCHAR2(100) GENERATED ALWAYS AS (cust_first_name || ' ' || cust_last_name)
);


-- 9-33...
-- -----------------------------------------------------------------
col column_name  format a30
col data_type    format a15
col data_default format a50
 
SELECT column_name
,      data_type
,      data_default
FROM   user_tab_columns
WHERE  table_name = 'CUSTOMERS'
ORDER  BY
       column_id;


-- 9-34...
-- -----------------------------------------------------------------
@autostat

SELECT t.calendar_year
,      c.cust_name
,      SUM(s.quantity_sold) AS qty_sold
,      SUM(s.amount_sold)   AS amt_sold
FROM   sales     s
,      customers c
,      times     t
WHERE  s.cust_id = c.cust_id
AND    s.time_id = t.time_id
GROUP  BY
       t.calendar_year
,      c.cust_name
;

@autooff
