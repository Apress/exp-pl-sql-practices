-- -----------------------------------------------------------------
--
-- Title:      Expert PL/SQL Practices (Apress)
-- ISBN:       978-1-4302-3485-2
-- Chapter:    9. PL/SQL from SQL
-- Author:     Adrian Billington
--             http://www.oracle-developer.net
--
-- Listing(s): 9-1, 9-2, 9-3, 9-4
--
-- Notes:      1. Run in the supplied SH sample schema.
--
--             2. Called using run_listing.sql as follows:
--                SQL> @run_listing.sql 9_01_04
--             
-- -----------------------------------------------------------------

-- 9-1...
-- -----------------------------------------------------------------
@autostat

SELECT ROWNUM AS r 
FROM   dual 
CONNECT BY ROWNUM <= 1e6;

@autooff


-- 9-2...
-- -----------------------------------------------------------------
CREATE FUNCTION plsql_function(
                p_number IN NUMBER
                ) RETURN NUMBER AS
BEGIN
   RETURN p_number;
END plsql_function;
/

@autostat

SELECT plsql_function(ROWNUM) AS r
FROM   dual 
CONNECT BY ROWNUM <= 1e6;

@autooff


-- 9-3...
-- -----------------------------------------------------------------
@autostat
@hprof_on "&__script"

SELECT plsql_function(ROWNUM) AS r
FROM   dual 
CONNECT BY ROWNUM <= 1e6;

@autooff
@hprof_off "&__script"


-- 9-4...
-- -----------------------------------------------------------------
@autostat
@trace_on "&__script"

SELECT ROWNUM AS r 
FROM   dual 
CONNECT BY ROWNUM <= 1e6;

SELECT plsql_function(ROWNUM) AS r
FROM   dual 
CONNECT BY ROWNUM <= 1e6;

@autooff
@trace_off
