-- -----------------------------------------------------------------
--
-- Title:      Expert PL/SQL Practices (Apress)
-- ISBN:       978-1-4302-3485-2
-- Chapter:    9. PL/SQL from SQL
-- Author:     Adrian Billington
--             http://www.oracle-developer.net
--
-- Listing(s): 9-21, 9-23
--
-- Notes:      1. Run in the supplied SH sample schema.
--
--             2. Called using run_listing.sql as follows:
--                SQL> @run_listing.sql 9_21_23
--             
-- -----------------------------------------------------------------

-- 9-21, 9-23...
-- -----------------------------------------------------------------
col cust_name format a30

set time on

SELECT s.cust_id
,      get_customer_name(s.cust_id) AS cust_name
,      sleeper(1)                   AS sleep_time
FROM   sales s
WHERE  ROWNUM <= 10
;


-- Cleanup...
-- -----------------------------------------------------------------
UPDATE customers
SET    cust_last_name = 'Koch'
WHERE  cust_id = 2;

COMMIT;
