-- -----------------------------------------------------------------
--
-- Title:      Expert PL/SQL Practices (Apress)
-- ISBN:       978-1-4302-3485-2
-- Chapter:    9. PL/SQL from SQL
-- Author:     Adrian Billington
--             http://www.oracle-developer.net
--
-- Listing(s): 9-43
--
-- Notes:      1. Run in the supplied SH sample schema.
--
--             2. Called using run_listing.sql as follows:
--                SQL> @run_listing.sql 9_43
--             
-- -----------------------------------------------------------------

-- 9-43...
-- -----------------------------------------------------------------
CREATE OR REPLACE FUNCTION format_customer_name (
                           p_first_name IN VARCHAR2,
                           p_last_name  IN VARCHAR2
                           ) RETURN VARCHAR2 DETERMINISTIC AS
BEGIN
   counter.increment;
   RETURN p_first_name || ' ' || p_last_name;
END format_customer_name;
/

@autostat

SELECT t.calendar_year
,      format_customer_name(
          c.cust_first_name, c.cust_last_name
          )                 AS cust_name
,      SUM(s.quantity_sold) AS qty_sold
,      SUM(s.amount_sold)   AS amt_sold
FROM   sales     s
,      customers c
,      times     t
WHERE  s.cust_id = c.cust_id
AND    s.time_id = t.time_id
GROUP  BY
       t.calendar_year
,      format_customer_name(
          c.cust_first_name, c.cust_last_name
          );

@show "Deterministic function calls"

@autooff

@autostat

SELECT /*+ NO_MERGE(@inner) */
       calendar_year
,      format_customer_name(
          cust_first_name, cust_last_name
          )                                AS cust_name
,      SUM(quantity_sold)                  AS qty_sold
,      SUM(amount_sold)                    AS amt_sold
FROM  (
       SELECT /*+ 
                  QB_NAME(inner) 
                  NO_ELIMINATE_OBY
               */
              t.calendar_year
       ,      c.cust_first_name
       ,      c.cust_last_name
       ,      s.quantity_sold
       ,      s.amount_sold
       FROM   sales     s
       ,      customers c
       ,      times     t
       WHERE  s.cust_id = c.cust_id
       AND    s.time_id = t.time_id
       ORDER  BY
              c.cust_first_name
       ,      c.cust_last_name
      )
GROUP  BY
       calendar_year
,      format_customer_name(
          cust_first_name, cust_last_name
          )    
;

@show "Deterministic function calls"

@autooff

@autostat

SELECT /*+ NO_MERGE(@inner) */
       format_customer_name(
          cust_first_name, cust_last_name
          )                                AS cust_name
FROM  (
       SELECT /*+ 
                  QB_NAME(inner) 
                  NO_ELIMINATE_OBY
               */
              c.cust_first_name
       ,      c.cust_last_name
       FROM   sales     s
       ,      customers c
       WHERE  s.cust_id = c.cust_id
       ORDER  BY
              c.cust_first_name
       ,      c.cust_last_name
      )
;

@show "Deterministic function calls"

@autooff
