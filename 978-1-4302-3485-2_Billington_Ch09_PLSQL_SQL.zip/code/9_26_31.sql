-- -----------------------------------------------------------------
--
-- Title:      Expert PL/SQL Practices (Apress)
-- ISBN:       978-1-4302-3485-2
-- Chapter:    9. PL/SQL from SQL
-- Author:     Adrian Billington
--             http://www.oracle-developer.net
--
-- Listing(s): 9-26, 9-27, 9-28, 9-29, 9-30, 9-31
--
-- Notes:      1. Run in the supplied SH sample schema.
--
--             2. Called using run_listing.sql as follows:
--                SQL> @run_listing.sql 9_26_31
--             
-- -----------------------------------------------------------------

-- 9-26...
-- -----------------------------------------------------------------
CREATE VIEW sales_rates_view
AS
   SELECT s.*
   ,      s.amount_sold * (SELECT r.exchange_rate
                           FROM   rates r
                           WHERE  r.base_ccy   = 'USD'
                           AND    r.target_ccy = 'GBP'
                           AND    r.rate_date  = s.time_id) AS amount_sold_gbp
   FROM   sales     s
;


-- 9-27...
-- -----------------------------------------------------------------
@autoon

SELECT t.calendar_year
,      p.prod_name
,      SUM(s.quantity_sold)   AS qty_sold
,      SUM(s.amount_sold)     AS amt_sold_usd
,      SUM(s.amount_sold_gbp) AS amt_sold_gbp
FROM   sales_rates_view s
,      times            t
,      products         p
WHERE  s.time_id    = t.time_id
AND    s.prod_id    = p.prod_id
GROUP  BY
       t.calendar_year
,      p.prod_name
;

@autooff


-- 9-28...
-- -----------------------------------------------------------------
@autostat

SELECT t.calendar_year
,      p.prod_name
,      SUM(s.quantity_sold)   AS qty_sold
,      SUM(s.amount_sold)     AS amt_sold_usd
FROM   sales_rates_view s
,      times            t
,      products         p
WHERE  s.time_id    = t.time_id
AND    s.prod_id    = p.prod_id
GROUP  BY
       t.calendar_year
,      p.prod_name
;

@autooff


-- 9-29...
-- -----------------------------------------------------------------
EXPLAIN PLAN SET STATEMENT_ID = '&__script'
FOR
SELECT t.calendar_year
,      p.prod_name
,      SUM(s.quantity_sold)   AS qty_sold
,      SUM(s.amount_sold)     AS amt_sold_usd
FROM   sales_rates_view s
,      times            t
,      products         p
WHERE  s.time_id    = t.time_id
AND    s.prod_id    = p.prod_id
GROUP  BY
       t.calendar_year
,      p.prod_name
;

@xplan "&__script" "basic +projection"


-- 9-30...
-- -----------------------------------------------------------------
RENAME sales TO sales_t;

CREATE VIEW sales
AS
   SELECT s.*
   ,      s.amount_sold * (SELECT r.exchange_rate
                           FROM   rates r
                           WHERE  r.base_ccy   = 'USD'
                           AND    r.target_ccy = 'GBP'
                           AND    r.rate_date  = s.time_id) AS amount_sold_gbp
   FROM   sales_t  s
;

INSERT INTO sales
   ( prod_id, cust_id, time_id, channel_id, promo_id, 
     quantity_sold, amount_sold )
VALUES
   ( 13, 987, DATE '1998-01-10', 3, 999, 1, 1232.16 );

UPDATE sales
SET    amount_sold = 10000
WHERE  ROWNUM = 1;

DELETE
FROM   sales
WHERE  amount_sold = 10000;

ROLLBACK;


-- 9-31...
-- -----------------------------------------------------------------
INSERT INTO sales
   ( prod_id, cust_id, time_id, channel_id, promo_id, 
     quantity_sold, amount_sold, amount_sold_gbp )
VALUES
   ( 13, 987, DATE '1998-01-10', 3, 999, 1, 1232.16, 1000 );


-- Cleanup...
-- -----------------------------------------------------------------
DROP VIEW sales;
RENAME sales_t TO sales;
