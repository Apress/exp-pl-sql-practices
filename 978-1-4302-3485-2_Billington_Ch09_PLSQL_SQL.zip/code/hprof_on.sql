exec DBMS_HPROF.START_PROFILING('&__ora_dir','&1..hprof.trc');
