-- -----------------------------------------------------------------
--
-- Title:      Expert PL/SQL Practices (Apress)
-- ISBN:       978-1-4302-3485-2
-- Chapter:    9. PL/SQL from SQL
-- Author:     Adrian Billington
--             http://www.oracle-developer.net
--
-- Listing(s): 9-39, 9-40, 9-41, 9-42
--
-- Notes:      1. Run in the supplied SH sample schema.
--
--             2. Called using run_listing.sql as follows:
--                SQL> @run_listing.sql 9_39_42
--             
-- -----------------------------------------------------------------

-- 9-39...
-- -----------------------------------------------------------------
CREATE OR REPLACE FUNCTION get_rate(
                           p_rate_date IN rates.rate_date%TYPE,
                           p_from_ccy  IN rates.base_ccy%TYPE,
                           p_to_ccy    IN rates.target_ccy%TYPE
                           ) RETURN rates.exchange_rate%TYPE
                             RESULT_CACHE RELIES_ON (rates) AS
   v_rate rates.exchange_rate%TYPE;
BEGIN
   SELECT exchange_rate INTO v_rate
   FROM   rates
   WHERE  base_ccy   = p_from_ccy
   AND    target_ccy = p_to_ccy
   AND    rate_date  = p_rate_date;
   RETURN v_rate;
END get_rate;
/


-- 9-40...
-- -----------------------------------------------------------------
@rcflush
@autostat

SELECT t.calendar_year
,      p.prod_name
,      SUM(s.amount_sold)                     AS amt_sold_usd
,      SUM(s.amount_sold *
           get_rate(s.time_id, 'USD', 'GBP')) AS amt_sold_gbp
FROM   sales     s
,      products  p
,      times     t
WHERE  s.prod_id = p.prod_id
AND    s.time_id = t.time_id
GROUP  BY
       t.calendar_year
,      p.prod_name
;

@autooff


-- 9-41...
-- -----------------------------------------------------------------
@rcflush
@autostat
@hprof_on "&__script"

SELECT t.calendar_year
,      p.prod_name
,      SUM(s.amount_sold)                     AS amt_sold_usd
,      SUM(s.amount_sold *
           get_rate(s.time_id, 'USD', 'GBP')) AS amt_sold_gbp
FROM   sales     s
,      products  p
,      times     t
WHERE  s.prod_id = p.prod_id
AND    s.time_id = t.time_id
GROUP  BY
       t.calendar_year
,      p.prod_name
;

@autooff
@hprof_off "&__script"


-- 9-42...
-- -----------------------------------------------------------------
col name  format a23
col value format a10

SELECT name, value
FROM   v$result_cache_statistics
WHERE  name IN ('Find Count','Create Count Success');
