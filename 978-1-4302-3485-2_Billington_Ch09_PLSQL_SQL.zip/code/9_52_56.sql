-- -----------------------------------------------------------------
--
-- Title:      Expert PL/SQL Practices (Apress)
-- ISBN:       978-1-4302-3485-2
-- Chapter:    9. PL/SQL from SQL
-- Author:     Adrian Billington
--             http://www.oracle-developer.net
--
-- Listing(s): 9-52, 9-53, 9-54, 9-55, 9-56
--
-- Notes:      1. Run in the supplied SH sample schema.
--
--             2. Called using run_listing.sql as follows:
--                SQL> @run_listing.sql 9_52_56
--             
-- -----------------------------------------------------------------

-- 9-52...
-- -----------------------------------------------------------------
CREATE FUNCTION format_prod_category(
                p_prod_category IN VARCHAR2
                ) RETURN VARCHAR2 DETERMINISTIC IS
BEGIN
   RETURN UPPER(p_prod_category);
END format_prod_category;
/

@autoexp

SELECT *
FROM   products
WHERE  format_prod_category(prod_category) = 'SOFTWARE/OTHER';

@autooff


-- 9-53...
-- -----------------------------------------------------------------
SELECT prod_category
,      num_rows
,      ROUND(RATIO_TO_REPORT(num_rows) OVER () * 100, 1) AS selectivity
FROM  (
       SELECT prod_category 
       ,      COUNT(*) AS num_rows
       FROM   products
       GROUP  BY
              prod_category
      )
ORDER  BY
       num_rows;


-- 9-54...
-- -----------------------------------------------------------------
CREATE TYPE prod_stats_ot AS OBJECT (

   dummy_attribute NUMBER,

   STATIC FUNCTION ODCIGetInterfaces (
                   p_interfaces OUT SYS.ODCIObjectList
                   ) RETURN NUMBER,

   STATIC FUNCTION ODCIStatsSelectivity (
                   p_pred_info      IN  SYS.ODCIPredInfo,
                   p_selectivity    OUT NUMBER,
                   p_args           IN  SYS.ODCIArgDescList,
                   p_start          IN  VARCHAR2,
                   p_stop           IN  VARCHAR2,
                   p_prod_category  IN  VARCHAR2,
                   p_env            IN  SYS.ODCIEnv
                   ) RETURN NUMBER,

   STATIC FUNCTION ODCIStatsFunctionCost (
                   p_func_info      IN  SYS.ODCIFuncInfo,
                   p_cost           OUT SYS.ODCICost,
                   p_args           IN  SYS.ODCIArgDescList,
                   p_prod_category  IN  VARCHAR2,
                   p_env            IN  SYS.ODCIEnv
                   ) RETURN NUMBER
);
/


-- 9-55...
-- -----------------------------------------------------------------
CREATE TYPE BODY prod_stats_ot AS

   STATIC FUNCTION ODCIGetInterfaces (
                   p_interfaces OUT SYS.ODCIObjectList
                   ) RETURN NUMBER IS
   BEGIN
      p_interfaces := SYS.ODCIObjectList(
                         SYS.ODCIObject ('SYS', 'ODCISTATS2')
                         );
      RETURN ODCIConst.success;
   END ODCIGetInterfaces;

   STATIC FUNCTION ODCIStatsSelectivity (
                   p_pred_info        IN  SYS.ODCIPredInfo,
                   p_selectivity      OUT NUMBER,
                   p_args             IN  SYS.ODCIArgDescList,
                   p_start            IN  VARCHAR2,
                   p_stop             IN  VARCHAR2,
                   p_prod_category    IN  VARCHAR2,
                   p_env              IN  SYS.ODCIEnv
                   ) RETURN NUMBER IS
   BEGIN

      /* Calculate selectivity of predicate... */
      SELECT (COUNT(CASE
                       WHEN UPPER(prod_category) = p_start 
                       THEN 0
                    END) / COUNT(*)) * 100 AS selectivity
      INTO   p_selectivity
      FROM   products;

      RETURN ODCIConst.success;
   END ODCIStatsSelectivity;

   STATIC FUNCTION ODCIStatsFunctionCost (
                   p_func_info      IN  SYS.ODCIFuncInfo,
                   p_cost           OUT SYS.ODCICost,
                   p_args           IN  SYS.ODCIArgDescList,
                   p_prod_category  IN  VARCHAR2,
                   p_env            IN  SYS.ODCIEnv
                   ) RETURN NUMBER IS

      aa_io   DBMS_SQL.NUMBER_TABLE;
      aa_ela  DBMS_SQL.NUMBER_TABLE;
      v_dummy VARCHAR2(100);

      FUNCTION snap_io RETURN NUMBER IS
         v_io NUMBER;
      BEGIN
         SELECT SUM(ss.value) INTO v_io
         FROM   v$sesstat ss
         ,      v$statname sn
         WHERE  ss.statistic# = sn.statistic#
         AND    sn.name IN ('db block gets','consistent gets');
         RETURN v_io;
      END snap_io;

   BEGIN
      p_cost := SYS.ODCICost(NULL, NULL, NULL, NULL);

      /* Snap a sample execution of the function... */
      aa_io(1) := snap_io;
      aa_ela(1) := DBMS_UTILITY.GET_TIME;
      v_dummy := format_prod_category(p_prod_category);
      aa_ela(2) := DBMS_UTILITY.GET_TIME;
      aa_io(2) := snap_io;

      /* Calculate costs from snaps... */
      p_cost.CPUCost := 1000 * DBMS_ODCI.ESTIMATE_CPU_UNITS(
                                  (aa_ela(2) - aa_ela(1)) / 100);
      p_cost.IOCost := aa_io(2) - aa_io(1);
      p_cost.NetworkCost := 0;

      RETURN ODCIConst.success;
   END ODCIStatsFunctionCost;

END;
/


-- 9-56...
-- -----------------------------------------------------------------
ASSOCIATE STATISTICS WITH FUNCTIONS format_prod_category USING prod_stats_ot;

@flush "products"
@autoexp

SELECT *
FROM   products
WHERE  format_prod_category(prod_category) = 'SOFTWARE/OTHER';

SELECT *
FROM   products
WHERE  format_prod_category(prod_category) = 'HARDWARE';

@flush "products"
VAR p_category VARCHAR2(30)

exec :p_category := 'ELECTRONICS';

SELECT *
FROM   products
WHERE  format_prod_category(prod_category) = :p_category;

@autooff
