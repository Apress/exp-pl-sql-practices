-- -----------------------------------------------------------------
--
-- Title:      Expert PL/SQL Practices (Apress)
-- ISBN:       978-1-4302-3485-2
-- Chapter:    9. PL/SQL from SQL
-- Author:     Adrian Billington
--             http://www.oracle-developer.net
--
-- Listing(s): 9-19
--
-- Notes:      1. Run in the supplied SH sample schema.
--
--             2. Called using run_listing.sql as follows:
--                SQL> @run_listing.sql 9_19
--             
-- -----------------------------------------------------------------

-- 9-19...
-- -----------------------------------------------------------------
CREATE FUNCTION quick_function (
                p_id IN INTEGER
                ) RETURN INTEGER AS
BEGIN
   RETURN MOD(p_id, 1000);
END quick_function;
/

CREATE FUNCTION slow_function (
                p_id IN INTEGER
                ) RETURN INTEGER AS
BEGIN
   DBMS_LOCK.SLEEP(0.005);
   RETURN MOD(p_id, 2);
END slow_function;
/

@autoon

SELECT *
FROM   thousand_rows
WHERE  quick_function(n1) = 0
AND    slow_function(n1) = 0;

SELECT *
FROM   thousand_rows
WHERE  slow_function(n1) = 0
AND    quick_function(n1) = 0;

@autooff
