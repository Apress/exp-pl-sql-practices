var n number;

DECLARE
   n NUMBER;
BEGIN
   DBMS_HPROF.STOP_PROFILING;
   :n := DBMS_HPROF.ANALYZE('&__ora_dir','&1..hprof.trc');
   DBMS_OUTPUT.PUT_LINE('Runid = ' || :n);
END;
/

col function format a50

SELECT CASE
          WHEN module != function
          THEN module || '.' || function 
          ELSE function
       END                          AS function
,      line#
,      calls
,      subtree_elapsed_time         AS sub_ela_us
,      function_elapsed_time        AS func_ela_us
,      subtree_elapsed_time/1e6     AS sub_ela_s
,      function_elapsed_time/1e6    AS func_ela_s
FROM   dbmshp_function_info
WHERE  runid = :n
ORDER  BY
       subtree_elapsed_time DESC
;
