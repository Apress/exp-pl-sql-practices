-- -----------------------------------------------------------------
--
-- Title:      Expert PL/SQL Practices (Apress)
-- ISBN:       978-1-4302-3485-2
-- Chapter:    9. PL/SQL from SQL
-- Author:     Adrian Billington
--             http://www.oracle-developer.net
--
-- Listing(s): 9-44, 9-45
--
-- Notes:      1. Run in the supplied SH sample schema.
--
--             2. Called using run_listing.sql as follows:
--                SQL> @run_listing.sql 9_44_45
--             
-- -----------------------------------------------------------------

-- 9-44...
-- -----------------------------------------------------------------
CREATE FUNCTION promo_function(
                p_promo_category IN VARCHAR2
                ) RETURN VARCHAR2 DETERMINISTIC IS
BEGIN
   RETURN UPPER(p_promo_category);
END promo_function;
/

@autoon

SELECT *
FROM   sales       s
,      promotions  p
,      times       t
WHERE  s.promo_id = p.promo_id
AND    s.time_id  = t.time_id
AND    t.time_id BETWEEN DATE '2000-01-01' AND DATE '2000-03-31'
AND    promo_function(p.promo_category) = 'AD NEWS';

@autooff


-- 9-45...
-- -----------------------------------------------------------------
CREATE INDEX promotions_fbi
   ON promotions (promo_function(promo_category))
   COMPUTE STATISTICS;

@autoexp

SELECT *
FROM   sales       s
,      promotions  p
,      times       t
WHERE  s.promo_id = p.promo_id
AND    s.time_id  = t.time_id
AND    t.time_id BETWEEN DATE '2000-01-01' AND DATE '2000-03-31'
AND    promo_function(p.promo_category) = 'AD NEWS';

@autooff
