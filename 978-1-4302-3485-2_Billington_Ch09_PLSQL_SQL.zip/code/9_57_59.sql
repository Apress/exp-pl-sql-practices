-- -----------------------------------------------------------------
--
-- Title:      Expert PL/SQL Practices (Apress)
-- ISBN:       978-1-4302-3485-2
-- Chapter:    9. PL/SQL from SQL
-- Author:     Adrian Billington
--             http://www.oracle-developer.net
--
-- Listing(s): 9-57, 9-58, 9-59
--
-- Notes:      1. Run in the supplied SH sample schema.
--
--             2. Called using run_listing.sql as follows:
--                SQL> @run_listing.sql 9_57_59
--             
-- -----------------------------------------------------------------

-- 9-57...
-- -----------------------------------------------------------------
CREATE PACKAGE rates_pkg AS 
   FUNCTION get_rate (
            p_rate_date IN rates.rate_date%TYPE,
            p_from_ccy  IN rates.base_ccy%TYPE,
            p_to_ccy    IN rates.target_ccy%TYPE
            ) RETURN rates.exchange_rate%TYPE;
END rates_pkg;
/

CREATE OR REPLACE PACKAGE BODY rates_pkg AS

   /* Index subtype for cache... */
   SUBTYPE key_st IS VARCHAR2(128);

   /* Rates cache... */
   TYPE rates_aat IS TABLE OF rates.exchange_rate%TYPE 
      INDEX BY key_st;
   rates_cache rates_aat;

   /* Cache-enabled function... */
   FUNCTION get_rate (
            p_rate_date IN rates.rate_date%TYPE,
            p_from_ccy  IN rates.base_ccy%TYPE,
            p_to_ccy    IN rates.target_ccy%TYPE
            ) RETURN rates.exchange_rate%TYPE IS

      v_rate rates.exchange_rate%TYPE;
      v_key  key_st := TO_CHAR(p_rate_date, 'YYYYMMDD')
                       || '~' || p_from_ccy || '~' || p_to_ccy;

   BEGIN

      IF rates_cache.EXISTS(v_key) THEN

         /* Cache hit... */
         v_rate := rates_cache(v_key);

      ELSE

         /* Cache miss. Fetch and cache... */
         SELECT exchange_rate INTO v_rate
         FROM   rates
         WHERE  rate_date  = p_rate_date
         AND    base_ccy   = p_from_ccy
         AND    target_ccy = p_to_ccy;
         rates_cache(v_key) := v_rate;

      END IF;

      RETURN v_rate;

   END get_rate;

END rates_pkg;
/


-- 9-58...
-- -----------------------------------------------------------------
exec dbms_session.reset_package;
set serveroutput on

@autostat

SELECT t.calendar_year
,      p.prod_name
,      SUM(s.amount_sold)                               AS amt_sold_usd
,      SUM(s.amount_sold * 
           rates_pkg.get_rate(s.time_id, 'USD', 'GBP')) AS amt_sold_gbp
FROM   sales     s
,      products  p
,      times     t
WHERE  s.prod_id = p.prod_id
AND    s.time_id = t.time_id
GROUP  BY
       t.calendar_year
,      p.prod_name
;

@autooff


-- 9-59...
-- -----------------------------------------------------------------
exec dbms_session.reset_package;
set serveroutput on

@hprof_on "&__script"
@autostat

SELECT t.calendar_year
,      p.prod_name
,      SUM(s.amount_sold)                               AS amt_sold_usd
,      SUM(s.amount_sold * 
           rates_pkg.get_rate(s.time_id, 'USD', 'GBP')) AS amt_sold_gbp
FROM   sales     s
,      products  p
,      times     t
WHERE  s.prod_id = p.prod_id
AND    s.time_id = t.time_id
GROUP  BY
       t.calendar_year
,      p.prod_name
;

@autooff
@hprof_off "&__script"
