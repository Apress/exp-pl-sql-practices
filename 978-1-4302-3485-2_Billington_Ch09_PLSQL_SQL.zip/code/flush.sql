declare
   v_comments   varchar2(4000);
   v_table_name varchar2(30) := upper('&1');
begin
   select comments into v_comments
   from   user_tab_comments
   where  table_name = v_table_name;
   execute immediate 'comment on table ' || v_table_name || ' is ''' || v_comments || '''';
end;
/
