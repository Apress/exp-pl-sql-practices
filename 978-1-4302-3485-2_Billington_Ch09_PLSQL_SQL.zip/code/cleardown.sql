-- -----------------------------------------------------------------
--
-- Title:      Expert PL/SQL Practices (Apress)
-- ISBN:       978-1-4302-3485-2
-- Chapter:    9. PL/SQL from SQL
-- Author:     Adrian Billington
--             http://www.oracle-developer.net
--
-- Utility:    cleardown.sql
--
-- Notes:      1. Run in the supplied SH sample schema.
--
--             2. Use to cleardown all objects created and reverse
--                any modifications made by the SQL listings.
--             
-- -----------------------------------------------------------------

DROP INDEX promotions_fbi;
ALTER TABLE customers DROP COLUMN cust_name;
DROP TABLE external_table;
DROP TABLE rates;
DROP TABLE thousand_rows;
DROP FUNCTION format_customer_name;
DROP FUNCTION format_prod_category;
DROP FUNCTION get_customer_name;
DROP FUNCTION get_rate;
DROP FUNCTION is_number;
DROP FUNCTION plsql_function;
DROP FUNCTION promo_function;
DROP FUNCTION quick_function;
DROP FUNCTION sleeper;
DROP FUNCTION slow_function;
DROP FUNCTION stragg;
DROP PROCEDURE data_dump;
DROP PACKAGE counter;
DROP PACKAGE rates_pkg;
DROP TYPE string_agg_type;
DROP TYPE prod_stats_ot;
DROP VIEW sales_rates_view;
