-- -----------------------------------------------------------------
--
-- Title:      Expert PL/SQL Practices (Apress)
-- ISBN:       978-1-4302-3485-2
-- Chapter:    9. PL/SQL from SQL
-- Author:     Adrian Billington
--             http://www.oracle-developer.net
--
-- Listing(s): 9-37, 9-38
--
-- Notes:      1. Run in the supplied SH sample schema.
--
--             2. Called using run_listing.sql as follows:
--                SQL> @run_listing.sql 9_37_38
--             
-- -----------------------------------------------------------------

-- 9-37...
-- -----------------------------------------------------------------
CREATE OR REPLACE FUNCTION get_rate(
                           p_rate_date IN rates.rate_date%TYPE,
                           p_from_ccy  IN rates.base_ccy%TYPE,
                           p_to_ccy    IN rates.target_ccy%TYPE
                           ) RETURN rates.exchange_rate%TYPE AS
   v_rate rates.exchange_rate%TYPE;
BEGIN
   counter.increment;
   SELECT exchange_rate INTO v_rate
   FROM   rates
   WHERE  base_ccy   = p_from_ccy
   AND    target_ccy = p_to_ccy
   AND    rate_date  = p_rate_date;
   RETURN v_rate;
END get_rate;
/

@autostat

SELECT t.calendar_year
,      p.prod_name
,      SUM(s.amount_sold)                                            AS amt_sold_usd
,      SUM(s.amount_sold * (SELECT get_rate(s.time_id, 'USD', 'GBP') 
                            FROM   dual))                            AS amt_sold_gbp
FROM   sales     s
,      products  p
,      times     t
WHERE  s.prod_id = p.prod_id
AND    s.time_id = t.time_id
GROUP  BY
       t.calendar_year
,      p.prod_name
;

exec counter.show('Function calls');

@autooff


-- 9-38...
-- -----------------------------------------------------------------
@autostat

SELECT /*+ NO_MERGE(@inner) */
       calendar_year
,      prod_name
,      SUM(amount_sold)                                          AS amt_sold_usd
,      SUM(amount_sold * (SELECT get_rate(time_id, 'USD', 'GBP') 
                          FROM   dual))                          AS amt_sold_gbp
FROM  (
       SELECT /*+ QB_NAME(inner) NO_ELIMINATE_OBY */ 
              t.calendar_year
       ,      s.time_id
       ,      p.prod_name
       ,      s.amount_sold
       FROM   sales     s
       ,      products  p
       ,      times     t
       WHERE  s.prod_id = p.prod_id
       AND    s.time_id = t.time_id
       ORDER  BY
              s.time_id
      )
GROUP  BY
       calendar_year
,      prod_name
;

exec counter.show('Function calls: ordered inputs');

@autooff
