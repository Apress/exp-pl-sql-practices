-- -----------------------------------------------------------------
--
-- Title:      Expert PL/SQL Practices (Apress)
-- ISBN:       978-1-4302-3485-2
-- Chapter:    9. PL/SQL from SQL
-- Author:     Adrian Billington
--             http://www.oracle-developer.net
--
-- File:       README.txt
--
-- Purpose:    Some general setup and usage instructions for the
--             listings for Chapter 9.
--
-- -----------------------------------------------------------------

1. LISTINGS
===========
- Examples are provided for all of the listings in Chapter 9.

- A number of small utility scripts used by the listings are also provided.
  - For example, turning trace on and off, autotrace on and off and so on.
  - Some required utilities from oracle-developer.net and asktom.oracle.com
    are also included.

- Listings are named according to the range of examples they cover.
  For example, 9_1_4.sql covers listings 1 through to 4.


2. RUNNING
==========
- All examples are designed to be run in the supplied SH sample schema. 
  - In most cases the examples use pre-existing SH tables.
  - Some new objects are created.

- A "run_listing.sql" script is provided to execute each named listing script.
  - See the header in run_listing.sql for details.
  - The run_listing.sql sets up the environment for the named listing and 
    spools its output to file.

- A "cleardown.sql" is provided to remove all objects created by the listings.
  - This excludes the tables used by DBMS_HPROF (see pre-requisites below).


3. PRE-REQUISITES
=================
- Some examples require privileges beyond those granted to the SH schema.

- To run all of the examples as-is, the required privileges and setup are:

  - the supplied SH sample schema

  - ALTER SESSION (to enable/disable 10046 and 10053 events)

  - EXECUTE on DBMS_RESULT_CACHE

  - EXECUTE on DBMS_HPROF

  - PL/SQL Hierarchical Profiler tables in the SH schema
    - tables are created by ?/rdbms/admin/dbmshptab.sql

  - READ/WRITE on an Oracle DIRECTORY object
    - the name of the directory needs to be set in run_listing.sql

  - access to the following V$ views:
    - V$RESULT_CACHE_STATISTICS
    - V$SESSTAT
    - V$STATNAME 
    - grant explicit SELECT on each or use the SELECT ANY DICTIONARY
      system privilege
