--------------------------------------------------------
--  Expert PL/SQL Practices Published by Apress
--  Demo Code
--  Not mmeant for production use
--  Author: Lewis R Cunningham 
--    
--  Compilation: Intended to be compiled in the HR
--               demo Schema provided by Oracle
--               Login as HR and run @hr_orcl2.sql
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Type CODE_INFO
--------------------------------------------------------

CREATE OR REPLACE TYPE "HR"."CODE_INFO" as object (
  object_owner VARCHAR2(30),
  object_name VARCHAR2(30),
  object_subname VARCHAR2(30),
  object_type VARCHAR2(30),
  object_usage VARCHAR2(30),
  line# NUMBER,
  column# NUMBER);
/

--------------------------------------------------------
--  DDL for Type CODE_INFOS
--------------------------------------------------------

CREATE OR REPLACE TYPE "HR"."CODE_INFOS" as table of code_info;
/

--------------------------------------------------------
--  DDL for Type DEMO_TYPE
--------------------------------------------------------

CREATE OR REPLACE TYPE "HR"."DEMO_TYPE" AS OBJECT (
  just_an_attribute VARCHAR2(30),
  MEMBER PROCEDURE overload_proc(p_value IN VARCHAR2),
  MEMBER PROCEDURE overload_proc(p_value IN NUMBER),
  MEMBER FUNCTION func(p_value IN VARCHAR2) RETURN NUMBER
  );
/
CREATE OR REPLACE TYPE BODY "HR"."DEMO_TYPE" AS
  MEMBER PROCEDURE overload_proc(p_value IN VARCHAR2)
  AS BEGIN NULL; END;
  MEMBER PROCEDURE overload_proc(p_value IN NUMBER)
  AS BEGIN NULL; END;
  MEMBER FUNCTION func(p_value IN VARCHAR2) RETURN NUMBER
  AS BEGIN RETURN 0; END;
END;

/

--------------------------------------------------------
--  DDL for Function TEST_CALLS_FNC
--------------------------------------------------------

CREATE OR REPLACE FUNCTION "HR"."TEST_CALLS_FNC" 
  RETURN BOOLEAN
AS 
BEGIN
  RETURN JOBS_API.VALIDATE_JOB('a', 'b');
END TEST_CALLS_FNC;

/

--------------------------------------------------------
--  DDL for Package DEPARTMENTS_API
--------------------------------------------------------

CREATE OR REPLACE PACKAGE "HR"."DEPARTMENTS_API" AS 

  FUNCTION department_exists(
   p_department_name IN departments.department_name%TYPE )
  RETURN departments.department_id%TYPE ;
  
  FUNCTION department_manager_id(
   p_department_name IN departments.department_name%TYPE )
  RETURN departments.manager_id%TYPE ;
  
  FUNCTION department_manager_id(
   p_department_id IN departments.department_id%TYPE )
  RETURN departments.manager_id%TYPE ;
  
END DEPARTMENTS_API;

/

--------------------------------------------------------
--  DDL for Package EMPLOYEE_API
--------------------------------------------------------

CREATE OR REPLACE PACKAGE "HR"."EMPLOYEE_API" AS 

  FUNCTION create_employee(
   p_first_name IN employees.first_name%TYPE,
   p_last_name IN employees.last_name%TYPE,
   p_email IN employees.email%TYPE,
   p_phone_number IN employees.phone_number%TYPE,
   p_job_title IN jobs.job_title%TYPE,
   p_department_name IN departments.department_name%TYPE,
   p_salary IN employees.salary%TYPE,
   p_commission_pct IN employees.commission_pct%TYPE )
  RETURN employees.employee_id%TYPE;
   
  PROCEDURE assign_salary(
    p_employee_id IN employees.manager_id%TYPE,
    p_salary IN employees.salary%TYPE,
    p_commission_pct IN employees.commission_pct%TYPE );

END EMPLOYEE_API;

/

--------------------------------------------------------
--  DDL for Package JOBS_API
--------------------------------------------------------

CREATE OR REPLACE PACKAGE "HR"."JOBS_API" AS 

  FUNCTION job_exists( 
    p_job_title  IN jobs.job_title%TYPE )
  RETURN jobs.job_id%TYPE;
  
  FUNCTION validate_job(
   p_job_title IN jobs.job_title%TYPE,
   p_department_name IN departments.department_name%TYPE )
  RETURN BOOLEAN;

  FUNCTION validate_salary(
   p_job_title IN jobs.job_title%TYPE,
   p_salary IN employees.salary%TYPE,
   p_commission_pct IN employees.commission_pct%TYPE )
  RETURN BOOLEAN;

END JOBS_API;

/

--------------------------------------------------------
--  DDL for Package PLSCOPE_SUPPORT_PKG
--------------------------------------------------------

CREATE OR REPLACE PACKAGE "HR"."PLSCOPE_SUPPORT_PKG" AS 
  
  FUNCTION source_lookup( p_string IN VARCHAR2 )
  RETURN code_infos;
  
  FUNCTION source_lookup( 
      p_owner IN VARCHAR2,
      p_object IN VARCHAR2,
      p_type IN VARCHAR2,
      p_line IN NUMBER )
  RETURN VARCHAR2;
  
  FUNCTION get_impact_info( 
      p_owner IN VARCHAR2,
      p_object IN VARCHAR2,
      p_unit IN VARCHAR2 )
  RETURN code_infos;
  
  PROCEDURE print_impacts( 
      p_owner IN VARCHAR2,
      p_object IN VARCHAR2,
      p_unit IN VARCHAR2,
      p_print_related_text IN BOOLEAN DEFAULT FALSE );
  
  PROCEDURE print_impacts(
      p_code_infos IN code_infos,
      p_print_related_text IN BOOLEAN );

END PLSCOPE_SUPPORT_PKG;

/

--------------------------------------------------------
--  DDL for Package SCOPE_PKG
--------------------------------------------------------

CREATE OR REPLACE PACKAGE "HR"."SCOPE_PKG" AS 
  i CONSTANT NUMBER := 0;  
  g_global_variable NUMBER := 10;

  PROCEDURE proc1 ;  
END SCOPE_PKG;

/

--------------------------------------------------------
--  DDL for Package VARIABLES_PKG
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HR"."VARIABLES_PKG" AS 

  PROCEDURE only_proc(
    p_keynum IN PLS_INTEGER,
    p_date IN OUT DATE,
    p_lob OUT CLOB);

END VARIABLES_PKG;

/

--------------------------------------------------------
--  DDL for Package Body DEPARTMENTS_API
--------------------------------------------------------

CREATE OR REPLACE PACKAGE BODY "HR"."DEPARTMENTS_API" AS

  FUNCTION department_exists(
   p_department_name IN departments.department_name%TYPE )
  RETURN departments.department_id%TYPE 
  AS
    v_department_id departments.department_id%TYPE;
  BEGIN
    SELECT department_id
      INTO v_department_id
      FROM DEPARTMENTS
      WHERE upper(department_name) = upper(p_department_name);
        
      RETURN v_department_id;
  EXCEPTION
    WHEN NO_DATA_FOUND
    THEN 
      RETURN v_department_id;
  END department_exists;
  
  FUNCTION department_manager_id(
   p_department_name IN departments.department_name%TYPE )
  RETURN departments.manager_id%TYPE 
  AS
  BEGIN
    RETURN department_manager_id( department_exists( p_department_name ) );
  END;
  
  FUNCTION department_manager_id(
   p_department_id IN departments.department_id%TYPE )
  RETURN departments.manager_id%TYPE 
  AS
    v_manager_id departments.manager_id%TYPE;
  BEGIN
    SELECT manager_id
      INTO v_manager_id
      FROM departments
      WHERE department_id = p_department_id;

    RETURN v_manager_id;
  EXCEPTION
      WHEN NO_DATA_FOUND
      THEN 
        RETURN v_manager_id;
  END;      

END DEPARTMENTS_API;

/

--------------------------------------------------------
--  DDL for Package Body EMPLOYEE_API
--------------------------------------------------------

CREATE OR REPLACE PACKAGE BODY "HR"."EMPLOYEE_API" AS

  FUNCTION create_employee(
   p_first_name IN employees.first_name%TYPE,
   p_last_name IN employees.last_name%TYPE,
   p_email IN employees.email%TYPE,
   p_phone_number IN employees.phone_number%TYPE,
   p_job_title IN jobs.job_title%TYPE,
   p_department_name IN departments.department_name%TYPE,
   p_salary IN employees.salary%TYPE,
   p_commission_pct IN employees.commission_pct%TYPE  )
  RETURN employees.employee_id%TYPE 
  AS
    v_department_id departments.department_id%TYPE;
    v_job_id jobs.job_id%TYPE;
    v_manager_id employees.manager_id%TYPE;
    v_employee_id employees.employee_id%TYPE;
    v_hire_date employees.hire_date%TYPE;
    
    v_exception BOOLEAN := FALSE;
    v_exception_message CHAR(2048) := 'Exception: ';
  BEGIN
  
    v_department_id := departments_api.department_exists(p_department_name);
    IF v_department_id IS NULL
    THEN
      v_exception := TRUE;
      v_exception_message := v_exception_message || chr(10) || 
                 'Department ' || p_department_name || ' not found.';
    END IF;

    v_job_id := jobs_api.job_exists(p_job_title);
    IF v_job_id IS NULL
    THEN
      v_exception := TRUE;
      v_exception_message := v_exception_message || chr(10) || 
                 'Job ' || p_job_title || ' not found.';
    END IF;

    IF NOT jobs_api.validate_job(p_job_title, p_department_name)
    THEN
      v_exception := TRUE;
      v_exception_message := v_exception_message || chr(10) || 
                 'Job ' || p_job_title || ' is not valid for department ' || p_department_name;
    END IF;
    
    IF p_commission_pct != 0
    AND
      NOT jobs_api.validate_salary(p_job_title, p_salary, p_commission_pct )
    THEN
      v_exception := TRUE;
      v_exception_message := v_exception_message || chr(10) || 
                 'Salary and/or commission is not correct for job ' || p_job_title;
    END IF;
    
    IF v_exception
    THEN
      RAISE_APPLICATION_ERROR(-20001, 'EMPLOYEE_API.create_employee: ' || v_exception_message);
    END IF;  
      
    v_manager_id := departments_api.department_manager_id(v_department_id);
    v_employee_id := EMPLOYEES_SEQ.nextval;
    
    INSERT INTO EMPLOYEES
      (employee_id, first_name, last_name, email, phone_number, hire_date, job_id, department_id, manager_id)
      VALUES
      (v_employee_id, p_first_name, p_last_name, p_email, p_phone_number, trunc(sysdate), v_job_id, v_department_id, v_manager_id);
      
    assign_salary( v_employee_id, p_salary, p_commission_pct);
    
    RETURN v_employee_id;
  END create_employee;

  PROCEDURE assign_salary(
    p_employee_id IN employees.manager_id%TYPE,
    p_salary IN employees.salary%TYPE,
    p_commission_pct IN employees.commission_pct%TYPE  )
  AS
  BEGIN
    UPDATE employees
      SET salary = p_salary,
          commission_pct = p_commission_pct
      WHERE employee_id = employee_id;
  END;    


END EMPLOYEE_API;

/

--------------------------------------------------------
--  DDL for Package Body JOBS_API
--------------------------------------------------------

CREATE OR REPLACE PACKAGE BODY "HR"."JOBS_API" AS

  FUNCTION job_exists( 
    job_title  IN jobs.job_title%TYPE )
  RETURN jobs.job_id%TYPE AS
    v_job_id jobs.job_id%TYPE;
  BEGIN
    SELECT job_id
      INTO v_job_id
      FROM jobs
      WHERE UPPER(job_title) = upper(job_title);
      
    RETURN v_job_id;
    
  EXCEPTION  
    WHEN NO_DATA_FOUND
    THEN
      RETURN v_job_id;
  END job_exists;

  FUNCTION validate_job(
   p_job_title IN jobs.job_title%TYPE,
   p_department_name IN departments.department_name%TYPE )
  RETURN BOOLEAN AS
  BEGIN
    IF p_job_title = 'President'
    AND
      p_department_name != 'Executive'
    THEN
      RETURN FALSE;
    ELSE
      RETURN TRUE;
    END IF;
  END validate_job;

  FUNCTION validate_salary(
   p_job_title IN jobs.job_title%TYPE,
   p_salary IN employees.salary%TYPE,
   p_commission_pct IN employees.commission_pct%TYPE )
  RETURN BOOLEAN AS
   v_job_id jobs.job_id%TYPE;
  BEGIN
    IF p_job_title NOT LIKE 'Sales%'
    AND
      p_commission_pct > 0
    THEN
      RETURN FALSE;
    END IF;
    
    SELECT job_id
      INTO v_job_id      
      FROM jobs
      WHERE UPPER(job_title) = p_job_title
        AND p_salary BETWEEN min_salary AND max_salary;
    
    RETURN TRUE;
  EXCEPTION
  WHEN NO_DATA_FOUND
  THEN
    RETURN FALSE;
  END validate_salary;

END JOBS_API;

/

--------------------------------------------------------
--  DDL for Package Body PLSCOPE_SUPPORT_PKG
--------------------------------------------------------

CREATE OR REPLACE PACKAGE BODY "HR"."PLSCOPE_SUPPORT_PKG" AS

  FUNCTION source_lookup( p_string IN VARCHAR2 )
  RETURN code_infos
  AS
    v_string VARCHAR2(32767) := UPPER(p_string);
    v_code_infos code_infos := code_infos();
  BEGIN
    FOR code_values IN (
      SELECT code_info(
             owner, name, to_char(NULL), type, 'SOURCE', line, instr(v_string, p_string) ) code_value
        FROM all_source 
        WHERE UPPER(text) LIKE '%'||UPPER(p_string)||'%' 
                       )
    LOOP    
      
      v_code_infos.extend;
      v_code_infos(v_code_infos.last) := code_values.code_value;
      
    END LOOP;  
    
    RETURN v_code_infos;
    
  END;

  FUNCTION source_lookup( 
      p_owner IN VARCHAR2,
      p_object IN VARCHAR2,
      p_type IN VARCHAR2,
      p_line IN NUMBER )
  RETURN VARCHAR2
  AS
    v_output VARCHAR2(32767);
  BEGIN
    SELECT text
      INTO v_output
      FROM all_source 
      WHERE owner = p_owner
        AND name = p_object
        AND type = p_type
         AND line = p_line;
    RETURN v_output;
  END;
  
  FUNCTION get_impact_info( 
      p_owner IN VARCHAR2,
      p_object IN VARCHAR2,
      p_unit IN VARCHAR2 )
  RETURN code_infos
  AS
    v_code_infos code_infos := code_infos();
  BEGIN
    FOR code_values IN (
      SELECT code_info( ai.owner, 
                        prior_object_name,
                        CASE
                        WHEN ai.object_type IN ('PROCEDURE', 'FUNCTION')
                        THEN NULL 
                        ELSE
                          ai.name
                        END,
                        ai.object_type, 
                        'CALL', 
                        cnctby_vw.line, 
                        cnctby_vw.p_col ) code_value
        FROM all_identifiers ai, (
                 SELECT usage, level, usage_id, usage_context_id, PRIOR usage_id p_usage_id, 
                    PRIOR usage_context_id prior_usagectx_id, 
                    object_name, name, object_type, type, line, PRIOR col p_col, 
                    PRIOR object_name prior_object_name, PRIOR name p_name, 
                    PRIOR object_type prior_object_type
               FROM all_identifiers
               WHERE OWNER = p_owner
                 AND OBJECT_TYPE IN ('PACKAGE BODY', 'PROCEDURE', 'FUNCTION', 'TRIGGER', 'TYPE BODY')
                 AND USAGE NOT IN ('DECLARATION', 'ASSIGNMENT', 'DEFINITION')
                 AND type IN ('PACKAGE BODY', 'FUNCTION', 'PROCEDURE', 'TYPE', 'TYPE BODY')
               CONNECT BY PRIOR usage_id = usage_context_id 
                   AND PRIOR name = p_object
                   AND name = p_unit
                   AND prior usage_context_id != 0 )  cnctby_vw
        WHERE ai.usage_id = cnctby_vw.prior_usagectx_id
          AND ai.object_name = cnctby_vw.prior_object_name
          AND ai.object_type = cnctby_vw.prior_object_type  )
    LOOP

      v_code_infos.extend;
      v_code_infos(v_code_infos.last) := code_values.code_value;
      
    END LOOP;  
    
    RETURN v_code_infos;
    
  END;

  PROCEDURE chunk_output(
      p_string IN VARCHAR2,
      p_space IN VARCHAR2)
  AS
  BEGIN
    FOR i IN 1..length(p_string) / 40
    LOOP
      DBMS_OUTPUT.PUT_LINE(lpad(' ', p_space) || SUBSTR(p_string, i + ((i-1) * 40), 40));
    END LOOP;
  END;
      
  PROCEDURE print_impacts(
    p_code_infos IN code_infos,
    p_print_related_text IN BOOLEAN )
  AS
    v_index PLS_INTEGER;
    v_output VARCHAR2(32767);
  BEGIN

    v_index := p_code_infos.FIRST;
 
    LOOP
      EXIT WHEN v_index IS NULL;
      
      DBMS_OUTPUT.PUT_LINE(
                 'Impact to ' || p_code_infos(v_index).object_type || ' ' ||
                  p_code_infos(v_index).object_owner || '.' ||
                  p_code_infos(v_index).object_name || 
                        case when p_code_infos(v_index).object_subname is not null then '.' else null end ||
                  p_code_infos(v_index).object_subname || 
                  ' at line ' || p_code_infos(v_index).line# || 
                  ' and column ' || p_code_infos(v_index).column# );
      IF p_print_related_text
      THEN
        DBMS_OUTPUT.PUT_LINE( '    TEXT: ' );
        v_output := source_lookup( 
                        p_code_infos(v_index).object_owner,
                        p_code_infos(v_index).object_name,
                        p_code_infos(v_index).object_type,
                        p_code_infos(v_index).line# );
        chunk_output(v_output, 10);
       END IF;    
                  
       v_index := p_code_infos.NEXT(v_index);
       
    END LOOP;
  END;

  PROCEDURE print_impacts( 
      p_owner IN VARCHAR2,
      p_object IN VARCHAR2,
      p_unit VARCHAR2,
      p_print_related_text IN BOOLEAN DEFAULT FALSE  )
  AS
  BEGIN
    print_impacts( get_impact_info( p_owner, p_object, p_unit ), p_print_related_text );
  END;
  
END PLSCOPE_SUPPORT_PKG;

/

--------------------------------------------------------
--  DDL for Package Body SCOPE_PKG
--------------------------------------------------------

CREATE OR REPLACE PACKAGE BODY "HR"."SCOPE_PKG" AS
 
  PROCEDURE proc1  
  AS
    i PLS_INTEGER := 30;
  BEGIN
  
    FOR i IN 1..10
    LOOP
      DBMS_OUTPUT.PUT_LINE(i);
    END LOOP;

    DBMS_OUTPUT.PUT_LINE(i);
  END;

END SCOPE_PKG;

/

--------------------------------------------------------
--  DDL for Package Body VARIABLES_PKG
--------------------------------------------------------

CREATE OR REPLACE PACKAGE BODY "HR"."VARIABLES_PKG" AS

  g_protected_variable_used PLS_INTEGER;
  g_protected_variable_unused PLS_INTEGER := 1;
  
  PROCEDURE only_proc(
    p_keynum IN PLS_INTEGER,
    p_date IN OUT DATE,
    p_lob OUT CLOB)
  AS
    v_used_variable NUMBER;
    v_unused_variable DATE;
  BEGIN
    v_used_variable := p_keynum;
    g_protected_variable_used := 9;
    p_lob := to_char(v_used_variable + g_protected_variable_used);
    DBMS_OUTPUT.PUT_LINE('Value: ' || p_lob);
  END only_proc;

END VARIABLES_PKG;

/

--------------------------------------------------------
--  DDL for Procedure BAD_DATA_TYPES_PRC
--------------------------------------------------------
set define off;

CREATE OR REPLACE PROCEDURE "HR"."BAD_DATA_TYPES_PRC" (
  p_data_in IN CHAR,
  p_data_out OUT LONG )
AS 
  v_char CHAR(1);
  v_varchar VARCHAR(32767);
  v_long LONG;
BEGIN
  NULL;
END BAD_DATA_TYPES_PRC;

/

--------------------------------------------------------
--  DDL for Procedure FOR_LOOP_TRACE_PRC
--------------------------------------------------------
set define off;

CREATE OR REPLACE PROCEDURE "HR"."FOR_LOOP_TRACE_PRC" AS 
BEGIN
  FOR i IN 1..100
  LOOP
    test_calls_prc;
    test_plscope;
  END LOOP;
END FOR_LOOP_TRACE_PRC;

/

--------------------------------------------------------
--  DDL for Procedure TEST_CALLS_PRC
--------------------------------------------------------
set define off;

CREATE OR REPLACE PROCEDURE "HR"."TEST_CALLS_PRC" 
AS 
BEGIN
  IF JOBS_API.VALIDATE_JOB('a', 'b') 
  THEN 
    DBMS_OUTPUT.PUT_LINE('Just testing my call');
    -- Just wanted to call it twice so here goes
    IF JOBS_API.VALIDATE_JOB('a', 'b') 
    THEN 
      DBMS_OUTPUT.PUT_LINE('Just testing my call');
    END IF;    
  END IF;
END TEST_CALLS_PRC;

/

--------------------------------------------------------
--  DDL for Procedure TEST_PLSCOPE
--------------------------------------------------------
CREATE OR REPLACE PROCEDURE "HR"."TEST_PLSCOPE" AS 
BEGIN
  IF 1=1
  THEN 
    execute immediate 'declare v1 number; begin select 1 into v1 from dual; end;';
  END IF;
END TEST_PLSCOPE;

/

