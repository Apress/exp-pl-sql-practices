--------------------------------------------------------
--  Expert PL/SQL Practices 
--  Published by Apress
--
--  Chapter 13 - Profiling for Performance
--  by Ron Crisco
--    
--  All code is for demonstration purposes only and 
--  is not intended for production use.
--
--  ILO examples require ILO Version 2.5 installed.
--  http://sourceforge.net/projects/ilo/
--
--------------------------------------------------------

--------------------------------------------------------
--  Example logon trigger using SET_IDENTIFIER 
--------------------------------------------------------
CREATE OR REPLACE TRIGGER LOGON_TRIGGER
AFTER LOGON ON DATABASE
DECLARE
  l_identifier VARCHAR2(64);
BEGIN
  L_identifier := SYS_CONTEXT('USERENV', 'OS_USER') || ':' ||
                  SYS_CONTEXT('USERENV', 'IP_ADDRESS');
  DBMS_SESSION.SET_IDENTIFIER(l_identifier);
END;
/

--------------------------------------------------------
--  Example using SET_SESSION_LONGOPS
--------------------------------------------------------
DECLARE
  l_rindex      BINARY_INTEGER;
  l_slno        BINARY_INTEGER; -- Oracle internal use
  l_op_name     VARCHAR2(64)    := 'Month end posting';
  l_target      BINARY_INTEGER; -- Object ID being worked on
  l_target_desc VARCHAR2(32);   -- Description of target
  l_context     BINARY_INTEGER; -- A number relevant to task, amount processed, etc.
  l_sofar       NUMBER(6,2);    -- The amount of work done so far
  l_totalwork   NUMBER := 100;  -- An estimate of the amount of work to be done
  l_units       VARCHAR2(32)    := 'records'; 
BEGIN
  -- rindex is used to identify the row in V$SESSION_LONGOPS
  -- the _nohint call will create a new row and rindex for us to use
  l_rindex := DBMS_APPLICATION_INFO.SET_SESSION_LONGOPS_NOHINT;

  FOR i IN 1 .. l_totalwork LOOP
    
    -- In practice, this would be a more complex calculation.
    -- This simple example assumes uniform processing time for each sub task
    l_sofar := i; 

    DBMS_APPLICATION_INFO.SET_SESSION_LONGOPS(rindex      => l_rindex, 
                                              slno        => l_slno, 
                                              op_name     => l_op_name, 
                                              target      => l_target, 
                                              target_desc => l_target_desc, 
                                              context     => l_context, 
                                              sofar       => l_sofar, 
                                              totalwork   => l_totalwork, 
                                              units       => l_units);

    -- processing occurs here

    COMMIT;
  END LOOP;
END;
/

--------------------------------------------------------
--  Example calling ILO
--------------------------------------------------------
DECLARE
  l_sqlcode NUMBER;
  l_sqlerrm VARCHAR2(512);
BEGIN
   ilo_task.begin_task(module  => 'Load Transaction Tables',
                       action  => 'Begin overall load',
                       comment => 'Execution of procedure all_trx_table_loads');
   
   ... code for your task goes here
   
   ilo_task.end_task;
EXCEPTION
   WHEN ex_insert_problem THEN
      l_sqlcode := SQLCODE;
      l_sqlerrm := SQLERRM; 
      ilo_task.end_task(error_num => l_sqlcode);
      ... handle the exception
   WHEN others THEN
      l_sqlcode := SQLCODE;
      l_sqlerrm := SQLERRM; 
      ilo_task.end_task(error_num => l_sqlcode);
      ... handle the exception
END;
/

--------------------------------------------------------
--  Example calling ILO from trigger
--------------------------------------------------------
CREATE OR REPLACE TRIGGER insert_or_update_example
    INSTEAD OF INSERT OR UPDATE ON table_abc 
DECLARE
  v_storage_value VARCHAR2(32000);
  l_sqlcode       NUMBER;
BEGIN
  IF INSERTING THEN
    ilo_task.begin_task(module => 'Table_ABC',
                        action => 'Instead of insert',
                        comment => 'Insert or Update Trigger on Table_ABC');
    example_package.create_value
    (p_value_name     => :NEW.value_name
     ,p_value         => :NEW.value
     ,p_description   => :NEW.description
     ,p_storage_value => v_storage_value
    );
    example_package.setup_something_else
    (p_storage_value => v_storage_value
    );        
  ELSIF UPDATING THEN
    example_package.update_value
    (p_value_name     => :NEW.value_name
     ,p_value         => :NEW.value
     ,p_description   => :NEW.description
     ,p_storage_value => v_storage_value
    );        
  ENDIF; 
  ilo_task.end_task;
EXCEPTION WHEN OTHERS THEN
  l_sqlcode := SQLCODE;
  ilo_task.end_task(error_num => l_sqlcode);
  ... handle the exception
END;
/

--------------------------------------------------------
--  Queries used in ILO example
--------------------------------------------------------
SELECT
  ilo_module,
  ilo_action,
  SUM(elapsed_seconds)                                    total_duration,
  AVG(elapsed_seconds)                                    avg_duration,
  COUNT(*)                                                cnt
FROM ilo_run_vw
GROUP by ilo_module,
         ilo_action
ORDER BY SUM(elapsed_seconds) DESC;

SELECT
  ilo_module,
  ilo_action,
  VARIANCE(elapsed_seconds)                               variance,
  STDDEV(elapsed_seconds)                                 standard_deviation,
  ROUND(VARIANCE(elapsed_seconds)/AVG(elapsed_seconds),3) variance_to_mean_ratio,
  ROUND(STDDEV(elapsed_seconds)/AVG(elapsed_seconds),3)   coefficient_of_variation
FROM ilo_run_vw
GROUP by ilo_module,
         ilo_action
ORDER BY ROUND(VARIANCE(elapsed_seconds)/AVG(elapsed_seconds),3), VARIANCE(elapsed_seconds) DESC;

--------------------------------------------------------
--  Profiling example
--------------------------------------------------------
CREATE OR REPLACE PROCEDURE q AS
  l_sqlcode NUMBER;
  l_sqlerrm VARCHAR2(512);
BEGIN
  ilo_task.begin_task(module => 'Procedure P',
                      action => 'q');
  FOR rec IN (SELECT * FROM V$SESSION) LOOP
    NULL;
  END LOOP;
  ilo_task.end_task;
EXCEPTION WHEN OTHERS THEN
  l_sqlcode := SQLCODE;
  l_sqlerrm := SQLERRM; 
  ilo_task.end_task(error_num => l_sqlcode);
  -- handle exceptions here
END;
/

CREATE OR REPLACE PROCEDURE r AS
  l_sqlcode NUMBER;
  l_sqlerrm VARCHAR2(512);
BEGIN
  ilo_task.begin_task(module => 'Procedure P',
                      action => 'r');
  FOR rec IN (SELECT * FROM ALL_OBJECTS) LOOP
    NULL;
  END LOOP;
  ilo_task.end_task;
EXCEPTION WHEN OTHERS THEN
  l_sqlcode := SQLCODE;
  l_sqlerrm := SQLERRM; 
  ilo_task.end_task(error_num => l_sqlcode);
  -- handle exceptions here
END;
/

CREATE OR REPLACE PROCEDURE s AS
  l_sqlcode NUMBER;
  l_sqlerrm VARCHAR2(512);
BEGIN
  ilo_task.begin_task(module => 'Procedure P',
                      action => 's');
  FOR rec IN (SELECT * FROM USER_TABLES) LOOP
    NULL;
  END LOOP;
  ilo_task.end_task;
EXCEPTION WHEN OTHERS THEN
  l_sqlcode := SQLCODE;
  l_sqlerrm := SQLERRM; 
  ilo_task.end_task(error_num => l_sqlcode);
  -- handle exceptions here
END;
/

CREATE OR REPLACE PROCEDURE p AS
  l_sqlcode NUMBER;
  l_sqlerrm VARCHAR2(512);
BEGIN
  ilo_task.begin_task(module => 'Month End Posting',
                      action => 'p');
  q;
  r;
  s;
  ilo_task.end_task;
EXCEPTION WHEN OTHERS THEN
  l_sqlcode := SQLCODE;
  l_sqlerrm := SQLERRM; 
  ilo_task.end_task(error_num => l_sqlcode);
  -- handle exceptions here
  raise;
END;
/

DELETE FROM ilo_run WHERE ilo_module IN ('Month End Posting', 'Procedure P');

EXEC ilo_timer.set_mark_all_tasks_interesting(true,true);

EXEC p;

EXEC ilo_timer.flush_ilo_runs;

set pages 1000
COLUMN ILO_MODULE FORMAT A20
COLUMN ILO_ACTION FORMAT A10
SELECT ILO_MODULE, ILO_ACTION, ELAPSED_SECONDS 
FROM ilo_run_vw WHERE ilo_module IN ('Month End Posting', 'Procedure P') ORDER BY 3 DESC;

--------------------------------------------------------
-- End of examples 
--------------------------------------------------------
